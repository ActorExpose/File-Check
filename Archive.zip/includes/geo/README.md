GeoIP package for YOURLS
========================

What the hell?
--------------

The DB file from this package (GeoLite2-Country.mmdb) is provided free by
MaxMind. Accuracy is 99.5% so don't sweat it if you get unrealistic results.

If unsure, you can always get the latest version of the GeoIP2 database
from the following URL: http://dev.maxmind.com/geoip/geoip2/geolite2/
(look for a link pointing to a file named "GeoLite2-Country.tar.gz")

Flag files from this package come from various sources. Feel free to copy and
redistribute them just as I'm doing :)


Copyright and License
---------------------

Database and Contents Copyright (c) 2017 MaxMind, Inc. This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/.

This database incorporates GeoNames [http://www.geonames.org] geographical data, which is made available under the Creative Commons Attribution 3.0 License. To view a copy of this license, visit http://www.creativecommons.org/licenses/by/3.0/us/.
