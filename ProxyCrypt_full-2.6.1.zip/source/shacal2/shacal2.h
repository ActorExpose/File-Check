#include <intrin.h>

typedef struct {
	__m128i subkeys[64];
} shacal2_key;

void shacal2_init(shacal2_key *key, void *key_init);
void shacal2_encrypt(shacal2_key *key, void *buffer);
void shacal2_decrypt(shacal2_key *key, void *buffer);
