#include <intrin.h>
#include "shacal2.h"
#include "..\config.h"

static unsigned long K[64] = {
	0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
	0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
	0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
	0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
	0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
	0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
	0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
	0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

#define R(a, b, c, d, e, f, g, h, k) \
	h = _mm_add_epi32(h, (_mm_srli_epi32(e, 6) | _mm_slli_epi32(e, 32 - 6)) ^ (_mm_srli_epi32(e, 11) | _mm_slli_epi32(e, 32 - 11)) ^ (_mm_srli_epi32(e, 25) | _mm_slli_epi32(e, 32 - 25))); \
	h = _mm_add_epi32(h, g ^ (e & (f ^ g))); \
	h = _mm_add_epi32(h, *k++); \
	d = _mm_add_epi32(d, h); \
	h = _mm_add_epi32(h, (_mm_srli_epi32(a, 2) | _mm_slli_epi32(a, 32 - 2)) ^ (_mm_srli_epi32(a, 13) | _mm_slli_epi32(a, 32 - 13)) ^ (_mm_srli_epi32(a, 22) | _mm_slli_epi32(a, 32 - 22))); \
	h = _mm_add_epi32(h, (a & b) | (c & (a | b)))

#define P(a, b, c, d, e, f, g, h, k) \
	h = _mm_sub_epi32(h, (_mm_srli_epi32(a, 2) | _mm_slli_epi32(a, 32 - 2)) ^ (_mm_srli_epi32(a, 13) | _mm_slli_epi32(a, 32 - 13)) ^ (_mm_srli_epi32(a, 22) | _mm_slli_epi32(a, 32 - 22))); \
	h = _mm_sub_epi32(h, (a & b) | (c & (a | b))); \
	d = _mm_sub_epi32(d, h); \
	h = _mm_sub_epi32(h, (_mm_srli_epi32(e, 6) | _mm_slli_epi32(e, 32 - 6)) ^ (_mm_srli_epi32(e, 11) | _mm_slli_epi32(e, 32 - 11)) ^ (_mm_srli_epi32(e, 25) | _mm_slli_epi32(e, 32 - 25))); \
	h = _mm_sub_epi32(h, g ^ (e & (f ^ g))); \
	h = _mm_sub_epi32(h, *--k)

void shacal2_init(shacal2_key *key, void *key_init)
{
	unsigned long rk[64];
	unsigned int i;

	memcpy(rk, key_init, 64);
	for (i = 0; i < 48; i++)
		rk[i + 16] = rk[i] + (_rotr(rk[i + 1], 7) ^ _rotr(rk[i + 1], 18) ^ (rk[i + 1] >> 3)) + rk[i + 9] + (_rotr(rk[i + 14], 17) ^ _rotr(rk[i + 14], 19) ^ (rk[i + 14] >> 10));
	for (i = 0; i < 64; i++)
		key->subkeys[i] = _mm_set1_epi32(rk[i] + K[i]);
	__stosb((unsigned char*)rk, 0, sizeof rk);
}

__attribute__((optimize(SHACAL2_ENC_OPTI)))
void shacal2_encrypt(shacal2_key *key, void *buffer)
{
	__m128i a, b, c, d, e, f, g, h;
	__m128i y0, y1, y2, y3, t1, t2;
	__m128i *rk = key->subkeys;
	unsigned char i;

	y0 = ((__m128i*)buffer)[0]; 
	y1 = ((__m128i*)buffer)[2];
	y2 = ((__m128i*)buffer)[4];
	y3 = ((__m128i*)buffer)[6];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	a = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	b = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	c = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	d = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	y0 = ((__m128i*)buffer)[1]; 
	y1 = ((__m128i*)buffer)[3];
	y2 = ((__m128i*)buffer)[5];
	y3 = ((__m128i*)buffer)[7];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	e = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	f = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	g = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	h = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));

	for (i = 0; i < 8; i++) {
		R(a, b, c, d, e, f, g, h, rk);
		R(h, a, b, c, d, e, f, g, rk);
		R(g, h, a, b, c, d, e, f, rk);
		R(f, g, h, a, b, c, d, e, rk);
		R(e, f, g, h, a, b, c, d, rk);
		R(d, e, f, g, h, a, b, c, rk);
		R(c, d, e, f, g, h, a, b, rk);
		R(b, c, d, e, f, g, h, a, rk);
	}

	t1 = _mm_unpacklo_epi32(a, b);
	t2 = _mm_unpacklo_epi32(c, d);
	((__m128*)buffer)[0] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[2] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(a, b);
	t2 = _mm_unpackhi_epi32(c, d);
	((__m128*)buffer)[4] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[6] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpacklo_epi32(e, f);
	t2 = _mm_unpacklo_epi32(g, h);
	((__m128*)buffer)[1] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[3] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(e, f);
	t2 = _mm_unpackhi_epi32(g, h);
	((__m128*)buffer)[5] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[7] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
}

__attribute__((optimize(SHACAL2_DEC_OPTI)))
void shacal2_decrypt(shacal2_key *key, void *buffer)
{
	__m128i a, b, c, d, e, f, g, h;
	__m128i y0, y1, y2, y3, t1, t2;
	__m128i *rk = &key->subkeys[64];
	unsigned char i;

	y0 = ((__m128i*)buffer)[0]; 
	y1 = ((__m128i*)buffer)[2];
	y2 = ((__m128i*)buffer)[4];
	y3 = ((__m128i*)buffer)[6];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	a = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	b = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	c = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	d = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	y0 = ((__m128i*)buffer)[1]; 
	y1 = ((__m128i*)buffer)[3];
	y2 = ((__m128i*)buffer)[5];
	y3 = ((__m128i*)buffer)[7];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	e = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	f = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	g = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	h = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));

	for (i = 0; i < 8; i++) {
		P(b, c, d, e, f, g, h, a, rk);
		P(c, d, e, f, g, h, a, b, rk);
		P(d, e, f, g, h, a, b, c, rk);
		P(e, f, g, h, a, b, c, d, rk);
		P(f, g, h, a, b, c, d, e, rk);
		P(g, h, a, b, c, d, e, f, rk);
		P(h, a, b, c, d, e, f, g, rk);
		P(a, b, c, d, e, f, g, h, rk);
	}

	t1 = _mm_unpacklo_epi32(a, b);
	t2 = _mm_unpacklo_epi32(c, d);
	((__m128*)buffer)[0] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[2] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(a, b);
	t2 = _mm_unpackhi_epi32(c, d);
	((__m128*)buffer)[4] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[6] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpacklo_epi32(e, f);
	t2 = _mm_unpacklo_epi32(g, h);
	((__m128*)buffer)[1] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[3] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(e, f);
	t2 = _mm_unpackhi_epi32(g, h);
	((__m128*)buffer)[5] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[7] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
}
