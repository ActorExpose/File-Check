#define SHA256_DIGESTSIZE 32
#define SHA256_BLOCKSIZE 64

void sha256(void *in, unsigned long inlen, void *out, _Bool init, _Bool finalize);
