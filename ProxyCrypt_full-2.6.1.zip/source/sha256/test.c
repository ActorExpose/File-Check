#include <stdio.h>
#include "sha256.h"

static unsigned char hash[64];

void display()
{
	int i;

	printf("Hash:     ");
	for (i = 0; i < 32; i++)
		printf("%02X", hash[i]);
}

int main()
{
	printf("-test 1-\n");
	sha256(NULL, 0, hash, 1, 1);
	display();
	printf("\nExpected: E3B0C44298FC1C149AFBF4C8996FB92427AE41E4649B934CA495991B7852B855\n\n");

	printf("-test 2-\n");
	sha256("abc", 3, hash, 1, 1);
	display();
	printf("\nExpected: BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD\n\n");

	printf("-test 3-\n");
	sha256("12345678901234567890123456789012345678901234567890123456789012345678901234567890", 80, hash, 1, 1);
	display();
	printf("\nExpected: F371BC4A311F2B009EEF952DD83CA80E2B60026C8E935592D0F9C308453C813E\n\n");

	return 0;
}
