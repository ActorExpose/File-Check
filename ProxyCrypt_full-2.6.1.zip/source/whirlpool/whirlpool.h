#define WHIRLPOOL_DIGESTSIZE 64
#define WHIRLPOOL_BLOCKSIZE 64

void whirlpool_ini();
void whirlpool(void *in, unsigned long inlen, void *out, _Bool init, _Bool finalize);
