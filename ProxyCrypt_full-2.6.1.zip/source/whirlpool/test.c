#include <stdio.h>
#include <string.h>
#include <intrin.h>
#include "whirlpool.h"

static unsigned char hash[64], data[1000000];

void display()
{
	int i;

	printf("The hash-code is the following 512-bit string.\n\n");
	for (i = 0; i < 64; i++) {
		if (i % 32 == 0) printf("\n");
		if (i % 8 == 0) printf(" ");
		printf("%02X", (unsigned char)hash[i]);
	}
	printf("\n\n");
}

int main()
{
	__int64 time;

	whirlpool_ini();

	memset(data, 0, sizeof(data));

	printf("1. In this example the data-string is the empty string, i.e. the string of length zero.\n\n");
	whirlpool(data, 0, hash, 1, 1);
	display();

	printf("2. In this example the data-string consists of a single byte, namely the ASCII-coded version of the letter 'a'.\n\n");
	whirlpool("a", 1, hash, 1, 1);
	display();

	printf("3. In this example the data-string is the three-byte string consisting of the ASCII-coded version of 'abc'.\n\n");
    whirlpool("abc", 3, hash, 1, 1);
	display();

	printf("4. In this example the data-string is the 14-byte string consisting of the ASCII-coded version of 'message digest'.\n\n");
    whirlpool("message digest", 14, hash, 1, 1);
	display();

	printf("5. In this example the data-string is the 26-byte string consisting of the ASCII-coded version of 'abcdefghijklmnopqrstuvwxyz'.\n\n");
    whirlpool("abcdefghijklmnopqrstuvwxyz", 26, hash, 1, 1);
	display();

	printf("6. In this example the data-string is the 62-byte string consisting of the ASCII-coded version of 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'.\n\n");
    whirlpool("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", 62, hash, 1, 1);
	display();

	printf("7. In this example the data-string is the 80-byte string consisting of the ASCII-coded version of eight repetitions of '1234567890'.\n\n");
    whirlpool("12345678901234567890123456789012345678901234567890123456789012345678901234567890", 80, hash, 1, 1);
	display();

	printf("8. In this example the data-string is the 32-byte string consisting of the ASCII-coded version of 'abcdbcdecdefdefgefghfghighijhijk'.\n\n");
    whirlpool("abcdbcdecdefdefgefghfghighijhijk", 32, hash, 1, 1);
	display();

	memset(data, 'a', 1000000);
	printf("9. In this example the data-string is the 1000000-byte string consisting of the ASCII-coded version of 'a' repeated 10^6 times.\n\n");
	time = _rdtsc();
    whirlpool(data, 1000000, hash, 1, 1);
	time = _rdtsc() - time;
	display();
	printf("time: %I64u\n", time);

	return 0;
}
