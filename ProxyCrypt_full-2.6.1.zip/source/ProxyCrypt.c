#pragma GCC optimize "O3"
#include <windows.h>
#include <winternl.h>
#include <ntstatus.h>
#include <stdio.h>
#include <errno.h>
#include <intrin.h>
#include "whirlpool\whirlpool.h"
#include "keccak\keccak.h"
#include "xts\xts.h"
#include "scrypt\scrypt.h"
#include "misc\misc.h"
#include "inc\imdisk.h"
#include "inc\imdproxy.h"
#pragma GCC diagnostic ignored "-Wunknown-pragmas"
#include "inc\common.h"

#define RtlGenRandom SystemFunction036
__declspec(dllimport) BOOLEAN __stdcall RtlGenRandom(PVOID RandomBuffer, ULONG RandomBufferLength);
typedef struct {int newmode;} _startupinfo;
__declspec(dllimport) int __cdecl __wgetmainargs(int *_Argc, wchar_t ***_Argv, wchar_t ***_Env, int _DoWildCard, _startupinfo *_StartInfo);
NTSYSCALLAPI NTSTATUS NTAPI NtWriteFile(IN HANDLE FileHandle, IN HANDLE Event OPTIONAL, IN PIO_APC_ROUTINE ApcRoutine OPTIONAL, IN PVOID ApcContext OPTIONAL, OUT PIO_STATUS_BLOCK IoStatusBlock,
										IN PVOID Buffer, IN ULONG Length, IN PLARGE_INTEGER ByteOffset OPTIONAL, IN PULONG Key OPTIONAL);
NTSYSCALLAPI NTSTATUS NTAPI NtReadFile(IN HANDLE FileHandle, IN HANDLE Event OPTIONAL, IN PIO_APC_ROUTINE ApcRoutine OPTIONAL, IN PVOID ApcContext OPTIONAL, OUT PIO_STATUS_BLOCK IoStatusBlock,
									   OUT PVOID Buffer, IN ULONG Length, IN PLARGE_INTEGER ByteOffset OPTIONAL, IN PULONG Key OPTIONAL);
#define FILE_OPENED 0x00000001
NTSYSCALLAPI NTSTATUS NTAPI NtSetEvent(HANDLE EventHandle, PLONG PreviousState);
typedef enum _OBJECT_WAIT_TYPE {WaitAllObjects, WaitAnyObject} OBJECT_WAIT_TYPE, *POBJECT_WAIT_TYPE;
NTSYSCALLAPI NTSTATUS NTAPI NtWaitForMultipleObjects(IN ULONG ObjectCount, IN PHANDLE ObjectsArray, IN OBJECT_WAIT_TYPE WaitType, IN BOOLEAN Alertable, IN PLARGE_INTEGER TimeOut OPTIONAL);
NTSYSCALLAPI NTSTATUS NTAPI NtSignalAndWaitForSingleObject(IN  HANDLE SignalHandle, IN  HANDLE WaitHandle, IN  BOOLEAN Alertable, IN  PLARGE_INTEGER Timeout OPTIONAL);
NTSYSCALLAPI NTSTATUS NTAPI NtQueryPerformanceCounter(_Out_ PLARGE_INTEGER PerformanceCounter, _Out_opt_ PLARGE_INTEGER PerformanceFrequency);
__declspec(dllimport) BOOL __stdcall SetConsoleFont(HANDLE hConsoleOutput, DWORD nFont);


#define DEF_BUFFER_SIZE (1 << 20)
#define AIM_BUFFER_SIZE (2 << 20)
#define MAX_THREAD 63

_Bool show_pass, pass_alternate;
void (*aes_encrypt)(aes_key *key, void *buffer);
void (*aes_decrypt)(aes_key *key, void *buffer);
int n_cipher;
precomp_key *keys;
static unsigned int buffer_size = DEF_BUFFER_SIZE;
static __int64 global_offset = 0;
static int sector_size = 512;
static WCHAR comm_device[18];
static ULONG aim_device = IMSCSI_AUTO_DEVICE_NUMBER;
static IMDPROXY_INFO_RESP proxy_info = {};
static WCHAR file_name[32768 + 200] = {};
static UNICODE_STRING uni_str = {0, 65535, file_name};
static OBJECT_ATTRIBUTES oa;
static WCHAR *mount_point = NULL, *format_param = L"", *run_command = NULL;
static LARGE_INTEGER *ad_timeout = NULL;
static PROCESS_INFORMATION pi_mount;
static int verbose = 1;
static char global_str[80] = {};
static WCHAR *password;
static unsigned int pass_size;
static void *kf_buf;
static DWORD kf_size;
static struct {unsigned char whirlpool[6 * 64], keccak[6 * 64];} thread_header_key;
static unsigned char salt_whirlpool[64 + 4], salt_keccak[64 + 4];
static unsigned int scrypt_r = 16, scrypt_p = 16;
static _Bool detach_console = FALSE;
static unsigned long enc_cipher = 0, dec_cipher = 0;
static HANDLE encrypt_event[MAX_THREAD], decrypt_event[MAX_THREAD];
static HANDLE io_crypt_done[MAX_THREAD + 2]; // read-crypt-write
static int write_item;
static SYSTEM_INFO sys;
static void *volatile thread_buffer;
static volatile unsigned int request_size;
static volatile __int64 thread_offset;
static ULONG open_flags = FILE_WRITE_THROUGH | FILE_NO_INTERMEDIATE_BUFFERING;
static IO_STATUS_BLOCK read_iosb = {}, write_iosb = {};
static LARGE_INTEGER read_offset, write_offset;
static unsigned char *write_buf;
static unsigned int expected_write = 0;
static _Bool close_window = FALSE, suspend_close = FALSE, force_aim = FALSE, use_imdisk;
static HANDLE h, h_aimapi, exit_event, clean_ok;
static BOOL aim_mount_ok;
static HWND console_hwnd;
static DWORD last_err = 0;
static WCHAR err_msg[160] = {};

static char *cipher_name[] = {"", "AES", "Serpent", "SHACAL-2"};

#pragma pack(push, 1)
typedef struct {
	unsigned char salt[64]; short version;
	unsigned char hash[WHIRLPOOL_DIGESTSIZE]; unsigned char master_key[6 * 64];
	__int64 volume_offset; __int64 volume_size;
} HEADER_STRUCT;

typedef struct {
	unsigned char salt[64]; short version;
	unsigned char hash[WHIRLPOOL_DIGESTSIZE]; unsigned char master_key[6][32];
	__int64 volume_offset; __int64 volume_size;
} HEADER_STRUCT_v1;
#pragma pack(pop)

static void out(char *format, ...);
static void disp_err(char *txt);
static HANDLE create_event();
static BYTE start_process(WCHAR *cmd, DWORD flag, _Bool global_pi);
static DWORD __stdcall thread_command(LPVOID lpParam);
static DWORD __stdcall aim_mount(LPVOID lpParam);
static DWORD __stdcall device_dismount(LPVOID lpParam);


/*void disp(void *buf, int size)
{
	int i;
	for (i = 0; i < size; i++) printf("%02X", ((unsigned char*)buf)[i]);
	printf("\n");
}*/


__declspec(noreturn) static DWORD __stdcall encrypt_thread(LPVOID lpParam)
{
	unsigned int request_sectors, remaining_sectors, number_of_sectors, sectors_to_skip;
	_Bool thread_with_extra_sector;

	NtWaitForSingleObject(encrypt_event[(int)(size_t)lpParam], FALSE, NULL);
	for (;;) {
		request_sectors = request_size >> 9;
		remaining_sectors = request_sectors % sys.dwNumberOfProcessors;
		thread_with_extra_sector = (unsigned int)(size_t)lpParam < remaining_sectors;
		number_of_sectors = request_sectors / sys.dwNumberOfProcessors + thread_with_extra_sector;
		sectors_to_skip = thread_with_extra_sector ? number_of_sectors * (unsigned int)(size_t)lpParam : number_of_sectors * (unsigned int)(size_t)lpParam + remaining_sectors;

		XTS_EncryptSector(enc_cipher, (thread_offset >> 9) + sectors_to_skip, number_of_sectors, thread_buffer + (sectors_to_skip << 9));
		NtSignalAndWaitForSingleObject(io_crypt_done[(int)(size_t)lpParam + 1], encrypt_event[(int)(size_t)lpParam], FALSE, NULL);
	}
}

__declspec(noreturn) static DWORD __stdcall decrypt_thread(LPVOID lpParam)
{
	unsigned int request_sectors, remaining_sectors, number_of_sectors, sectors_to_skip;
	_Bool thread_with_extra_sector;

	NtWaitForSingleObject(decrypt_event[(int)(size_t)lpParam], FALSE, NULL);
	for (;;) {
		request_sectors = request_size >> 9;
		remaining_sectors = request_sectors % sys.dwNumberOfProcessors;
		thread_with_extra_sector = (unsigned int)(size_t)lpParam < remaining_sectors;
		number_of_sectors = request_sectors / sys.dwNumberOfProcessors + thread_with_extra_sector;
		sectors_to_skip = thread_with_extra_sector ? number_of_sectors * (unsigned int)(size_t)lpParam : number_of_sectors * (unsigned int)(size_t)lpParam + remaining_sectors;

		XTS_DecryptSector(dec_cipher, (thread_offset >> 9) + sectors_to_skip, number_of_sectors, thread_buffer + (sectors_to_skip << 9));
		NtSignalAndWaitForSingleObject(io_crypt_done[(int)(size_t)lpParam + 1], decrypt_event[(int)(size_t)lpParam], FALSE, NULL);
	}
}


static unsigned char physical_read(void *buf, unsigned int size, __int64 offset)
{
	unsigned int i, current_size, next_size, size_done;
	unsigned char err = 0;

	read_offset.QuadPart = offset;
	next_size = min(size, 32768);
	NtReadFile(h, io_crypt_done[0], NULL, NULL, &read_iosb, buf, next_size, &read_offset, NULL);
	size_done = 0;

	if (verbose >= 2) out(" ? Read: %u bytes at offset %I64d\n", size, offset);

	NtWaitForSingleObject(io_crypt_done[0], FALSE, NULL);
	do {
		current_size = next_size;
		next_size = min(size - (size_done + current_size), 65536);

		if ((ULONG)read_iosb.Information != current_size) {
read_error:
			_snwprintf(err_msg, _countof(err_msg) - 1, L"Read error: %u / %u bytes at offset %I64d. (0x%08X)\n\n'Abort' will report the error to the driver.",
					   (unsigned int)read_iosb.Information, current_size, read_offset.QuadPart, (unsigned int)write_iosb.Status);
			switch (MessageBox(NULL, err_msg, mount_point, MB_ABORTRETRYIGNORE | MB_ICONERROR | MB_DEFBUTTON2 | MB_SYSTEMMODAL)) {
				case IDABORT: err = EIO; break;
				case IDRETRY:
					NtReadFile(h, io_crypt_done[0], NULL, NULL, &read_iosb, buf, current_size, &read_offset, NULL);
					NtWaitForSingleObject(io_crypt_done[0], FALSE, NULL);
					if ((ULONG)read_iosb.Information != current_size) goto read_error;
			}
		}
		if (next_size) {
			read_offset.QuadPart = offset + current_size;
			NtReadFile(h, io_crypt_done[0], NULL, NULL, &read_iosb, buf + current_size, next_size, &read_offset, NULL);
			size_done += current_size;
		}
		thread_buffer = buf;
		request_size = current_size;
		thread_offset = offset;
		i = 0; do NtSetEvent(decrypt_event[i], NULL); while (++i < sys.dwNumberOfProcessors);
		buf += current_size;
		offset += current_size;
		NtWaitForMultipleObjects(sys.dwNumberOfProcessors + !!next_size, &io_crypt_done[!next_size], WaitAllObjects, FALSE, NULL);
	} while (next_size);

	return err;
}

static unsigned char physical_write(void *buf, unsigned int size, __int64 offset)
{
	unsigned int i;
	unsigned char err = 0;

	thread_buffer = buf;
	request_size = size;
	thread_offset = offset;
	i = 0; do NtSetEvent(encrypt_event[i], NULL); while (++i < sys.dwNumberOfProcessors);

	NtWaitForMultipleObjects(write_item, &io_crypt_done[1], WaitAllObjects, FALSE, NULL);
	if ((ULONG)write_iosb.Information != expected_write) {
write_error:
		_snwprintf(err_msg, _countof(err_msg) - 1, L"Write error: %u / %u bytes at offset %I64d. (0x%08X)\n\n'Abort' will report the error to the driver.",
				   (unsigned int)write_iosb.Information, expected_write, write_offset.QuadPart, (unsigned int)write_iosb.Status);
		switch (MessageBox(NULL, err_msg, mount_point, MB_ABORTRETRYIGNORE | MB_ICONERROR | MB_DEFBUTTON2 | MB_SYSTEMMODAL)) {
			case IDABORT: err = EIO; break;
			case IDRETRY:
				NtWriteFile(h, io_crypt_done[write_item], NULL, NULL, &write_iosb, write_buf, expected_write, &write_offset, NULL);
				NtWaitForSingleObject(io_crypt_done[write_item], FALSE, NULL);
				if ((ULONG)write_iosb.Information != expected_write) goto write_error;
		}
	}
	memcpy(write_buf, buf, size);
	write_offset.QuadPart = offset;
	NtWriteFile(h, io_crypt_done[write_item], NULL, NULL, &write_iosb, write_buf, size, &write_offset, NULL);
	expected_write = size;

	if (verbose >= 2) out(" ! Write: %u bytes at offset %I64d\n", size, offset);

	return err;
}


static void do_comm()
{
	HANDLE shm_request_event, shm_response_event;
	void *shm_view, *main_buf;
	struct {unsigned char request_code, pad[7]; ULONGLONG offset; ULONGLONG length;} *req_block;
	struct {unsigned char errorno, pad[7]; ULONGLONG length;} *resp_block;
	HANDLE hFileMap;
	ULARGE_INTEGER map_size;
	char objname[40], *index;
	LARGE_INTEGER t;
	DWORD wait_result;

	_snwprintf(comm_device, _countof(comm_device), L"%I64x", _rdtsc());
	index = objname + sprintf(objname, "Global\\%S", comm_device);

	map_size.QuadPart = buffer_size + IMDPROXY_HEADER_SIZE;

	if (!(hFileMap = CreateFileMappingA(INVALID_HANDLE_VALUE, NULL, PAGE_READWRITE | SEC_COMMIT, map_size.HighPart, map_size.LowPart, objname))) {
		disp_err("CreateFileMapping() failed.\nAdministrative privileges required.");
		return;
	}
	if (!(shm_view = MapViewOfFile(hFileMap, FILE_MAP_WRITE, 0, 0, 0))) {
		disp_err("MapViewOfFile() failed.");
		return;
	}

	lock_large_buf(shm_view, map_size.LowPart, 0);

	req_block = shm_view;
	resp_block = shm_view;
	main_buf = shm_view + IMDPROXY_HEADER_SIZE;

	strcpy(index, "_Request");
	if (!(shm_request_event = CreateEventA(NULL, FALSE, FALSE, objname)) || GetLastError() == ERROR_ALREADY_EXISTS) {
		disp_err("CreateEvent() failed.");
		return;
	}
	strcpy(index, "_Response");
	if (!(shm_response_event = CreateEventA(NULL, FALSE, FALSE, objname)) || GetLastError() == ERROR_ALREADY_EXISTS) {
		disp_err("CreateEvent() failed.");
		return;
	}

	if (use_imdisk) {
		_snwprintf(file_name, _countof(file_name) - 1, L"imdisk -a -t proxy -o shm -x 1 -y 1 -m \"%s\" -f %s -S %d%S%s%S", mount_point, comm_device, sector_size,
				   format_param[0] ? " -p \"" : "", format_param, format_param[0] ? "\"" : "");
		start_process(file_name, verbose ? 0 : CREATE_NO_WINDOW, TRUE);
	} else {
		pi_mount.hProcess = create_event();
		CreateThread(NULL, 0, aim_mount, NULL, 0, NULL);
	}

	t.QuadPart = -100000000;
	if (NtWaitForSingleObject(shm_request_event, FALSE, &t) != STATUS_SUCCESS) {
		disp_err("NtWaitForSingleObject() failed.");
		last_err = 1;
		return;
	}
	if (req_block->request_code != IMDPROXY_REQ_INFO) {
		disp_err("Incorrect first request.");
		last_err = 1;
		return;
	}

	out("Connection on object %S.\n", comm_device);
	CreateThread(NULL, 0, thread_command, NULL, 0, NULL);
	memcpy(shm_view, &proxy_info, sizeof proxy_info);

	for (;;) {
		NtSetEvent(shm_response_event, NULL);
		while ((wait_result = NtWaitForSingleObject(shm_request_event, FALSE, ad_timeout)) != STATUS_SUCCESS)
			if (wait_result == WAIT_TIMEOUT) {
				out("Inactivity period elapsed.\n");
				CreateThread(NULL, 0, device_dismount, (void*)IMDISK_API_FORCE_DISMOUNT, 0, NULL);
			}
		if (req_block->request_code == IMDPROXY_REQ_READ)
			resp_block->errorno = physical_read(main_buf, req_block->length, global_offset + req_block->offset);
		else if (req_block->request_code == IMDPROXY_REQ_WRITE) {
			if (req_block->offset >= proxy_info.file_size || req_block->length > buffer_size || req_block->offset + req_block->length > proxy_info.file_size) {
				_snwprintf(err_msg, _countof(err_msg) - 1, L"Error: invalid write request (volume offset=%I64d size=%I64u)\n\nClick OK to report the error to the driver, Cancel to ignore it.",
						   req_block->offset, req_block->length);
				resp_block->errorno = MessageBox(NULL, err_msg, mount_point, MB_OKCANCEL | MB_ICONERROR | MB_SYSTEMMODAL) == IDOK ? EINVAL : 0;
			} else resp_block->errorno = physical_write(main_buf, req_block->length, global_offset + req_block->offset);
		} else {
			out("Connection closed.\n");
			SecureZeroMemory(main_buf, buffer_size);
			return;
		}
		resp_block->length = req_block->length;
	}
}

#pragma GCC optimize "Os"

static void out(char *format, ...)
{
	if (!verbose) return;
	va_list args;
	va_start(args, format);
	AttachConsole(ATTACH_PARENT_PROCESS);
	vprintf(format, args);
	if (detach_console) FreeConsole();
	va_end(args);
}

__declspec(noinline) static void disp_err(char *txt)
{
	last_err = GetLastError();
	fputs(txt, stderr);
}

__declspec(noinline) static HANDLE create_event()
{
	return CreateEventA(NULL, FALSE, FALSE, NULL);
}

static DWORD __stdcall derive_pass_keccak(LPVOID lpParam)
{
	return scrypt(PRF_KECCAK, password, pass_size, salt_keccak, 64, 32768, scrypt_r, scrypt_p, thread_header_key.keccak, sizeof thread_header_key.keccak);
}

__declspec(noinline) static BYTE start_process(WCHAR *cmd, DWORD flag, _Bool global_pi)
{
	STARTUPINFO si = {sizeof si};
	PROCESS_INFORMATION pi;
	BYTE result;

	result = CreateProcess(NULL, cmd, NULL, NULL, FALSE, flag, NULL, NULL, &si, global_pi ? &pi_mount : &pi);
	if (result && !global_pi) {
		NtClose(pi.hProcess);
		NtClose(pi.hThread);
	}
	return result;
}

static DWORD __stdcall thread_command(LPVOID lpParam)
{
	DWORD exit_code;
	int i;

	if (run_command) {
		NtWaitForSingleObject(pi_mount.hProcess, FALSE, NULL);
		start_process(run_command, 0, FALSE);
		VirtualFree(run_command, 0, MEM_RELEASE);
	}
	FreeConsole();
	detach_console = TRUE;
	if (close_window) {
		NtWaitForSingleObject(pi_mount.hProcess, FALSE, NULL);
		if (use_imdisk ? !GetExitCodeProcess(pi_mount.hProcess, &exit_code) || exit_code : !aim_mount_ok) return 0;
		i = 0; do {
			SendMessage(console_hwnd, WM_CLOSE, 0, 0);
			Sleep(50);
		} while (++i < 100 && IsWindow(console_hwnd));
	}
	return 0;
}

static DWORD __stdcall aim_mount(LPVOID lpParam)
{
	DWORD flags = IMSCSI_DEVICE_TYPE_HD | IMSCSI_TYPE_PROXY | IMSCSI_PROXY_TYPE_SHM;

#ifdef _WIN64
	aim_mount_ok = GetProcAddress(h_aimapi, "ImScsiCreateDevice")(NULL, INVALID_HANDLE_VALUE, &aim_device, NULL, &sector_size, NULL, &flags, comm_device, FALSE, NULL, FALSE);
#else
	aim_mount_ok = GetProcAddress(h_aimapi, "_ImScsiCreateDevice@44")(NULL, INVALID_HANDLE_VALUE, &aim_device, NULL, &sector_size, NULL, &flags, comm_device, FALSE, NULL, FALSE);
#endif
	if (aim_mount_ok)
		out("SCSI device ID: %06x\n", aim_device);
	else
		disp_err("ImScsiCreateDevice() failed.");
	NtSetEvent(pi_mount.hProcess, NULL);
	return 0;
}

static DWORD __stdcall device_dismount(LPVOID lpParam)
{
	HANDLE h_cpl, h_vol, h_scsi;
	DWORD PortNumber = 0, DiskNumber;
	FARPROC ImScsiVolumeUsesDisk;
	IO_STATUS_BLOCK iosb;
	LARGE_INTEGER t;

	ResetEvent(exit_event);
	if (use_imdisk) {
		if ((h_cpl = LoadLibraryA("imdisk.cpl"))) {
			GetProcAddress(h_cpl, "ImDiskSetAPIFlags")((ULONGLONG)(size_t)lpParam);
			GetProcAddress(h_cpl, "ImDiskRemoveDevice")(NULL, 0, mount_point);
		}
	} else {
#ifdef _WIN64
		h_scsi = (HANDLE)GetProcAddress(h_aimapi, "ImScsiOpenScsiAdapter")(&PortNumber);
		NtClose((HANDLE)GetProcAddress(h_aimapi, "ImScsiOpenDiskByDeviceNumber")(aim_device, PortNumber, &DiskNumber));
		ImScsiVolumeUsesDisk = GetProcAddress(h_aimapi, "ImScsiVolumeUsesDisk");
#else
		h_scsi = (HANDLE)GetProcAddress(h_aimapi, "_ImScsiOpenScsiAdapter@4")(&PortNumber);
		NtClose((HANDLE)GetProcAddress(h_aimapi, "_ImScsiOpenDiskByDeviceNumber@12")(aim_device, PortNumber, &DiskNumber));
		ImScsiVolumeUsesDisk = GetProcAddress(h_aimapi, "_ImScsiVolumeUsesDisk@8");
#endif
		wcscpy(file_name, L"\\??\\A:");
		uni_str.Length = 12;
		do {
			if (NtOpenFile(&h_vol, GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_SYNCHRONOUS_IO_NONALERT) != STATUS_SUCCESS) continue;
			if (ImScsiVolumeUsesDisk(h_vol, DiskNumber)) FlushFileBuffers(h_vol);
			NtClose(h_vol);
		} while (++file_name[4] <= 'Z');
#ifdef _WIN64
		GetProcAddress(h_aimapi, "ImScsiRemoveDeviceByNumber")(NULL, h_scsi, aim_device);
#else
		GetProcAddress(h_aimapi, "_ImScsiRemoveDeviceByNumber@12")(NULL, h_scsi, aim_device);
#endif
	}
	t.QuadPart = -20000000;
	NtSignalAndWaitForSingleObject(exit_event, clean_ok, FALSE, &t);

	return 0;
}

__declspec(noinline) static void raw_physical_read(void *buf, unsigned int size, __int64 offset)
{
	read_offset.QuadPart = offset;
	NtReadFile(h, io_crypt_done[0], NULL, NULL, &read_iosb, buf, size, &read_offset, NULL);
	if (verbose >= 2) out(" ? Read: %u bytes at offset %I64d\n", size, offset);
	NtWaitForSingleObject(io_crypt_done[0], FALSE, NULL);
	if ((ULONG)read_iosb.Information != size)
		fprintf(stderr, "%%Read error: %u / %u bytes at offset %I64d. (0x%08X)\n", (unsigned int)read_iosb.Information, size, read_offset.QuadPart, (unsigned int)write_iosb.Status);
}

__declspec(noinline) static void raw_physical_write(void *buf, unsigned int size, __int64 offset)
{
	NtWaitForSingleObject(io_crypt_done[write_item], FALSE, NULL);
	if ((ULONG)write_iosb.Information != expected_write)
		fprintf(stderr, "%%Write error: %u / %u bytes at offset %I64d. (0x%08X)\n", (unsigned int)write_iosb.Information, expected_write, write_offset.QuadPart, (unsigned int)write_iosb.Status);
	memcpy(write_buf, buf, size);
	write_offset.QuadPart = offset;
	NtWriteFile(h, io_crypt_done[write_item], NULL, NULL, &write_iosb, write_buf, size, &write_offset, NULL);
	expected_write = size;
	if (verbose >= 2) out(" ! Write: %u bytes at offset %I64d\n", size, offset);
}

static LRESULT __stdcall WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	if (Msg == WM_ENDSESSION || (Msg == WM_POWERBROADCAST && wParam == PBT_APMSUSPEND && suspend_close)) {
		device_dismount((void*)(IMDISK_API_FORCE_DISMOUNT | IMDISK_API_NO_BROADCAST_NOTIFY));
		return 0;
	} else
		return DefWindowProc(hWnd, Msg, wParam, lParam);
}

__declspec(noreturn) static DWORD __stdcall msg_window(LPVOID lpParam)
{
	MSG msg;
	WNDCLASSA wc = {};

	wc.lpfnWndProc = WndProc;
	wc.lpszClassName = "/";
	RegisterClassA(&wc);
	CreateWindowExA(0, "/", NULL, WS_POPUP, 0, 0, 0, 0, NULL, NULL, NULL, NULL);

	for (;;) {
		GetMessage(&msg, NULL, 0, 0);
		DispatchMessage(&msg);
	}
}

static void init_key(unsigned char *key_ptr)
{
	unsigned long c = dec_cipher;
	DWORD dw;

	VirtualProtect(keys, sizeof(precomp_key) * 6, PAGE_READWRITE, &dw);
	n_cipher = 0;
	do {
		if ((unsigned char)c == CIPHER_AES) {
			aes_init(&keys[n_cipher].aes, key_ptr);
			aes_init(&keys[n_cipher + 1].aes, key_ptr + 32);
			key_ptr += 64;
		} else if ((unsigned char)c == CIPHER_SERPENT) {
			serpent_init(&keys[n_cipher].serpent, key_ptr);
			serpent_init(&keys[n_cipher + 1].serpent, key_ptr + 32);
			key_ptr += 64;
		} else {
			shacal2_init(&keys[n_cipher].shacal2, key_ptr);
			shacal2_init(&keys[n_cipher + 1].shacal2, key_ptr + 64);
			key_ptr += 128;
		}
		n_cipher += 2;
	} while (c >>= 8);
	VirtualProtect(keys, sizeof(precomp_key) * 6, PAGE_READONLY, &dw);
}

__declspec(noinline) static void build_file_name(WCHAR *name)
{
	wcscpy(file_name, L"\\??\\");
	uni_str.Length = (GetFullPathName(name, _countof(file_name) - 4, &file_name[4], NULL) + 4) * sizeof(WCHAR);
}

static BYTE load_key_file(WCHAR *name)
{
	HANDLE h_keyfile;
	BYTE kf_date_ok;
	FILE_BASIC_INFORMATION kf_fbi;
	IO_STATUS_BLOCK iosb;

	build_file_name(name);
	if ((last_err = NtOpenFile(&h_keyfile, GENERIC_READ | SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ, FILE_SYNCHRONOUS_IO_NONALERT)) != STATUS_SUCCESS) {
		fwprintf(stderr, L"\nCannot open %s.\n", file_name);
		return 1;
	}
	kf_date_ok = NtQueryInformationFile(h_keyfile, &iosb, &kf_fbi, sizeof kf_fbi, FileBasicInformation) == STATUS_SUCCESS;
	if (NtReadFile(h_keyfile, NULL, NULL, NULL, &iosb, kf_buf, 4096, NULL, NULL) != STATUS_SUCCESS || (kf_size = (DWORD)iosb.Information) < 64) {
		disp_err("\nError while reading key file.");
		return 1;
	}
	NtClose(h_keyfile);
	out("%d bytes read.\n", kf_size);
	if (kf_date_ok) {
		NtOpenFile(&h_keyfile, FILE_WRITE_ATTRIBUTES | SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ, FILE_WRITE_THROUGH | FILE_SYNCHRONOUS_IO_NONALERT);
		NtSetInformationFile(h_keyfile, &iosb, &kf_fbi, sizeof kf_fbi, FileBasicInformation);
		NtClose(h_keyfile);
	}
	return 0;
}

__declspec(noinline) static char *group_digit(unsigned __int64 n)
{
	int size = sprintf(global_str, "%I64u", n);

	while (size > 3) {
		size -= 3;
		memmove(global_str + size + 1, global_str + size, 24);
		global_str[size] = ' ';
	}
	return global_str;
}

__declspec(noinline) static void process_suffix(__int64 *size, WCHAR suffix)
{
	switch (suffix & ~0x20) {
		case 'T': *size <<= 10;
		case 'G': *size <<= 10;
		case 'M': *size <<= 10;
		case 'K': *size <<= 10;
	}
}

__declspec(noinline) static void format_size(__int64 size, int drive_number, __int64 offset, VOLUME_DISK_EXTENTS *vde)
{
	__int64 size_disp = size;
	char *suffix = " KMGTP";
	ULONG *global_str_ptr = (ULONG*)&global_str[11];
	int i;

	while (size_disp > 9999) size_disp >>= 10, suffix++;
	sprintf(global_str, "%6I64d %cB              ", size_disp, *suffix);

	if (offset >= 0) {
		for (i = 0; i < 26; i++)
			if (vde[i].Extents[0].DiskNumber == drive_number && vde[i].Extents[0].StartingOffset.QuadPart == offset)
				*global_str_ptr = '(' + (('A' + i) << 8) + (':' << 16) + (')' << 24);
		sprintf(&global_str[17], "[%I64d - %I64d]", offset, offset + size - 1);
	} else
		sprintf(&global_str[23], "[0 - %I64d]", size - 1);
}

static int get_max_drive()
{
	int max_drive = 0;
	size_t buf_size;
	WCHAR *buf, *dev_ptr;
	int i;

	for (buf_size = 256 * 1024;; buf_size <<= 1) {
		dev_ptr = buf = VirtualAlloc(NULL, buf_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		if (QueryDosDevice(NULL, buf, buf_size)) break; // QueryDosDeviceA does not work on XP
		if (GetLastError() != ERROR_INSUFFICIENT_BUFFER) return -1;
		VirtualFree(buf, 0, MEM_RELEASE);
	}
	do {
		if (!memcmp(dev_ptr, L"PhysicalDrive", 13 * sizeof(WCHAR))) {
			i = _wtoi(dev_ptr + 13);
			if (i > max_drive) max_drive = i;
		}
		dev_ptr += wcslen(dev_ptr) + 1;
	} while (*dev_ptr);
	VirtualFree(buf, 0, MEM_RELEASE);

	return max_drive;
}

static void display_drives()
{
	int drive_number, max_drive, partition_number, ext_number;
	int sector_size, entry_size, sig_size, i;
	unsigned char *mbr, partition_type;
	unsigned char dge_buff[sizeof(DISK_GEOMETRY) + sizeof(LARGE_INTEGER) + sizeof(DISK_PARTITION_INFO) + sizeof(DISK_DETECTION_INFO)];
	DISK_GEOMETRY_EX *dge = (DISK_GEOMETRY_EX*)dge_buff;
	DISK_PARTITION_INFO *dpi = (DISK_PARTITION_INFO*)dge->Data;
	char *sig_str;
	DWORD n_bytes;
	__int64 offset, partition_size, offset_ext;
	IO_STATUS_BLOCK iosb;
	VOLUME_DISK_EXTENTS vde[26];

	wcscpy(file_name, L"\\??\\A:");
	uni_str.Length = 12;
	for (i = 0; i < 26; i++, file_name[4]++) {
		if (NtOpenFile(&h, SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_SYNCHRONOUS_IO_NONALERT) != STATUS_SUCCESS) continue;
		if (!DeviceIoControl(h, IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS, NULL, 0, &vde[i], sizeof(VOLUME_DISK_EXTENTS), &n_bytes, NULL))
			vde[i].Extents[0].DiskNumber = -1;
		NtClose(h);
	}

	mbr = VirtualAlloc(NULL, 34 * 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	max_drive = get_max_drive();

	for (drive_number = 0; drive_number <= max_drive; drive_number++) {
		uni_str.Length = _snwprintf(file_name, 29, L"\\??\\PhysicalDrive%d", drive_number) * sizeof(WCHAR);
		if (NtOpenFile(&h, GENERIC_READ | SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_SYNCHRONOUS_IO_NONALERT) != STATUS_SUCCESS) continue;
		if (!DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, dge, sizeof dge_buff, &n_bytes, NULL)) {
			NtClose(h);
			continue;
		}
		sector_size = dge->Geometry.BytesPerSector;
		if (sector_size > 4096) continue;
		sig_str = "", sig_size = 0;
		if (dpi->PartitionStyle == PARTITION_STYLE_MBR) sig_str = " MBR: #", sig_size = 1;
		if (dpi->PartitionStyle == PARTITION_STYLE_GPT) sig_str = " GPT: #", sig_size = 4;
		format_size(dge->DiskSize.QuadPart, drive_number, -1, vde);
		printf("Drive %d:%s\n%s", drive_number, global_str, sig_str);
		if (sig_size) {
			for (i = 0; i < sig_size; i++)
				printf("%08X", ((unsigned int*)&dpi->Mbr.Signature)[i]);
			puts("");
		}
		raw_physical_read(mbr, 2 * 4096, 0);
		if (mbr[0x01BE + 4] == 0xEE && !memcmp(mbr + sector_size, "EFI PART\0\0\1", 12)) {
			entry_size = *(int*)(mbr + sector_size + 84);
			raw_physical_read(mbr, 34 * sector_size, 0);
			for (partition_number = 0; partition_number < 128; partition_number++) {
				i = ((partition_number >> 2) + 2) * sector_size + (partition_number & 3) * entry_size;
				if (!(*(__int64*)(mbr + i) | *(__int64*)(mbr + i + 8))) break;
				offset = *(__int64*)(mbr + i + 32) * sector_size;
				partition_size = (*(__int64*)(mbr + i + 40) + 1) * sector_size - offset;
				format_size(partition_size, drive_number, offset, vde);
				printf(" -partition %d:%s\n", partition_number + 1, global_str);
			}
		}
		else if (*(USHORT*)(mbr + 0x01FE) == 0xAA55 && !((mbr[0x01BE] | mbr[0x01CE] | mbr[0x01DE] | mbr[0x01EE]) & 0x7F)) {
			for (partition_number = 1; partition_number <= 4; partition_number++) {
				partition_size = (__int64)(*(UINT*)(mbr + 0x01AE + partition_number * 16 + 12)) * sector_size;
				if (!partition_size) break;
				format_size(partition_size, drive_number, (__int64)(*(UINT*)(mbr + 0x01AE + partition_number * 16 + 8)) * sector_size, vde);
				printf(" -partition %d:%s\n", partition_number, global_str);
				partition_type = mbr[0x01AE + partition_number * 16 + 4];
				if (partition_type == 0x05 || partition_type == 0x0F) {
					offset_ext = offset = (__int64)(*(UINT*)(mbr + 0x01AE + partition_number * 16 + 8)) * sector_size;
					ext_number = 5;
					do {
						raw_physical_read(mbr, 4096, offset);
						partition_size = (__int64)(*(UINT*)(mbr + 0x01BE + 12)) * sector_size;
						format_size(partition_size, drive_number, offset + (__int64)(*(UINT*)(mbr + 0x01BE + 8)) * sector_size, vde);
						printf(" --partition %d:%s\n", ext_number++, global_str);
						offset = offset_ext + (__int64)(*(UINT*)(mbr + 0x01CE + 8)) * sector_size;
					} while (offset != offset_ext);
				}
			}
		}
		NtClose(h);
		puts("");
	}
}

static int create_keyfile(WCHAR *file)
{
	HANDLE h_keyfile;
	__m128i *buf, *buf2;
	IO_STATUS_BLOCK iosb;
	int i;

	build_file_name(file);
	if ((i = NtCreateFile(&h_keyfile, GENERIC_WRITE | SYNCHRONIZE, &oa, &iosb, NULL, FILE_ATTRIBUTE_NORMAL, 0, FILE_CREATE, FILE_WRITE_THROUGH | FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0)) != STATUS_SUCCESS) {
		disp_err("Error: file cannot be created.");
		return i;
	}
	buf = VirtualAlloc(NULL, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	if (!VirtualLock(buf, 1024))
		disp_err("Warning: cannot lock data into physical memory.\n");
	buf2 = buf + 512 / sizeof(__m128i);
	puts("Creating random data...");
	if (scrypt_p > 1) scrypt_p >>= 1;
	if ((i = rand_gen((unsigned char*)buf, 512, PRF_WHIRLPOOL, scrypt_r, scrypt_p)) || (i = rand_gen((unsigned char*)buf2, 512, PRF_KECCAK, scrypt_r, scrypt_p))) return i;
	for (i = 0; i < 512 / sizeof(__m128i); i++, buf++, buf2++)
		*buf ^= *buf2;
	i = NtWriteFile(h_keyfile, NULL, NULL, NULL, &iosb, buf, 512, NULL, NULL);
	NtClose(h_keyfile);
	SecureZeroMemory(buf, 1024);
	if (i != STATUS_SUCCESS)
		disp_err("Write error.");
	else
		printf("Done.\n");

	return i;
}

static void benchmark(unsigned long cipher)
{
	__int64 freq, init_time, enc_time, dec_time, test_time;
	int i, j, n_enc, n_dec;
	unsigned long cipher_list[] = {1, 2, 3, 0x0301, 0x0102, 0x0302, 0x030102};
	char cipher_str[32];

	thread_buffer = VirtualAlloc(NULL, DEF_BUFFER_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	request_size = DEF_BUFFER_SIZE;
	RtlGenRandom(thread_buffer, DEF_BUFFER_SIZE);
	puts("The following tests are made in RAM in XTS mode.\n\nCIPHER\t\t       ENCRYPT\t DECRYPT   AVERAGE (MB/s)\n");
	SetPriorityClass(GetCurrentProcess(), ABOVE_NORMAL_PRIORITY_CLASS);
	NtQueryPerformanceCounter((LARGE_INTEGER*)&init_time, (LARGE_INTEGER*)&freq);
	do NtQueryPerformanceCounter((LARGE_INTEGER*)&enc_time, NULL); while (enc_time - init_time < freq >> 3); // ensure that CPU is at correct frequency
	test_time = freq >> 1;
	for (j = 0; j < _countof(cipher_list); j++) {
		dec_cipher = cipher ? cipher : cipher_list[j];
		enc_cipher = _bswap(dec_cipher);
		do enc_cipher >>= 8; while (!(enc_cipher & 0xff));
		init_key((void*)thread_buffer);
		n_enc = n_dec = 0;
		NtQueryPerformanceCounter((LARGE_INTEGER*)&init_time, NULL);
		do {
			i = 0; do NtSetEvent(encrypt_event[i], NULL); while (++i < sys.dwNumberOfProcessors);
			NtWaitForMultipleObjects(sys.dwNumberOfProcessors, &io_crypt_done[1], WaitAllObjects, FALSE, NULL);
			NtQueryPerformanceCounter((LARGE_INTEGER*)&enc_time, NULL);
			n_enc++;
		} while (enc_time - init_time < test_time);
		do {
			i = 0; do NtSetEvent(decrypt_event[i], NULL); while (++i < sys.dwNumberOfProcessors);
			NtWaitForMultipleObjects(sys.dwNumberOfProcessors, &io_crypt_done[1], WaitAllObjects, FALSE, NULL);
			NtQueryPerformanceCounter((LARGE_INTEGER*)&dec_time, NULL);
			n_dec++;
		} while (dec_time - enc_time < test_time);
		sprintf(cipher_str, "%s%s%s%s%s", cipher_name[dec_cipher & 0xff], dec_cipher & 0xff00 ? "/" : "", cipher_name[(dec_cipher >> 8) & 0xff], dec_cipher & 0xff0000 ? "/" : "", cipher_name[dec_cipher >> 16]);
		printf("%-23s%7.0f%10.0f%10.0f\n", cipher_str,
			   (double)n_enc * (DEF_BUFFER_SIZE >> 20) * freq / (enc_time - init_time),
			   (double)n_dec * (DEF_BUFFER_SIZE >> 20) * freq / (dec_time - enc_time),
			   (double)(n_enc + n_dec) * (DEF_BUFFER_SIZE >> 20) * freq / (dec_time - init_time));
		if (cipher) break;
	}
}


__attribute__((__target__("sse2")))
int wmain()
{
	int CPUInfo[4];
	__cpuid(CPUInfo, 1);
#ifdef __AVX__
	if (!(CPUInfo[2] & 0x10000000)) {
		disp_err("AVX not supported by hardware.");
		ExitProcess(619); // ERROR_INVALID_HW_PROFILE = 619
	}
	if (!(CPUInfo[2] & 0x8000000) || ((unsigned char)_xgetbv(0) & 6) != 6) {
		disp_err("AVX not supported by operating system.");
		ExitProcess(619);
	}
#elif !defined _WIN64
	if (!(CPUInfo[3] & 0x4000000)) {
		disp_err("SSE2 instructions required.");
		ExitProcess(619);
	}
#endif

	int argc;
	WCHAR **argv, **env;
	_startupinfo _si = {};
	int drive_number = -1, partition_number = 1;
	unsigned int sig[4] = {};
	BYTE force_partition = FALSE, date_ok = FALSE;
	int entry_size, rest;
	unsigned char *mbr, *buf;
	__int64 offset_ext, extra_offset = 0, volume_offset;
	_Bool use_sig = FALSE, new_volume = FALSE, change_pass = FALSE, bench = FALSE, create_kf = FALSE;
	_Bool use_prompt = TRUE, pass_req = TRUE, new_pass_req = TRUE, no_aesni = FALSE;
	WCHAR rand_init;
	WCHAR *key_file = NULL, *new_key_file = NULL;
	unsigned int new_scrypt_r = 0, new_scrypt_p = 16;
	DWORD dw, pass_index;
	int header_size, n_hash = 0;
	__int64 new_file_size = 0;
	__int64 max_volume_size, size_new_volume = 0;
	__int64 a, b, n, total_size, t, timeout;
	struct {DWORD ReparseTag; WORD ReparseDataLength; WORD Reserved;} reparse_buf;
	FILE_BASIC_INFORMATION fbi;
	IO_STATUS_BLOCK iosb;
	unsigned char dge_buff[sizeof(DISK_GEOMETRY) + sizeof(LARGE_INTEGER) + sizeof(DISK_PARTITION_INFO) + sizeof(DISK_DETECTION_INFO)];
	DISK_GEOMETRY_EX *dge = (DISK_GEOMETRY_EX*)dge_buff;
	DISK_PARTITION_INFO *dpi = (DISK_PARTITION_INFO*)dge->Data;
	WCHAR *tok, suffix, *opt, *prompt_buf, *p1, *p2 = NULL, *p3 = NULL;
	WCHAR *file_name_ptr = L"", *backup_file = NULL;
	_Bool backup_file_exist = FALSE, mount = FALSE, arg_mount = TRUE;
	WCHAR drive_letter[] = L" :";
	HEADER_STRUCT *header;
	union {unsigned char ch[512 + 64]; HEADER_STRUCT header; HEADER_STRUCT_v1 header_v1; __m128i i128;} tmp_header;
	union {struct {__int64 i; POINT curs_pos;} data; __m128i i128;} ent;
	__m128i *ptr128;
	void *header_key = thread_header_key.whirlpool;
	HANDLE h_cpl, h_reparse, h_backup = NULL, thread_handle = NULL, h_console;
	unsigned long imdisk_version;
	SC_HANDLE h_scman, h_svc;
	CONSOLE_FONT_INFOEX cfi;
	CONSOLE_SCREEN_BUFFER_INFOEX csbi;
	HMODULE hDLL;
	FARPROC GetCurrentConsoleFontEx;
	int i, j;

	__wgetmainargs(&argc, &argv, &env, 0, &_si);

	if (argc < 2) {
		file_name_ptr = p1 = argv[0];
		do if (*p1++ == '\\') file_name_ptr = p1; while (*p1);
		p2 = p1;
		while (p1 != file_name_ptr) if (*--p1 == '.') {*p1 = 0; p2 = p1; break;}
		memset(global_str, ' ', min(p2 - file_name_ptr, 17));
		printf("version 2.6.1\n\n"
			"-= Syntax =-\n"
			"%S [mount_point] -f file | -d [#]drive_number[,[partition]] [-r]\n"
			"%s [-c|-cr [size]] [-p partition] [-o offset] [-cp] [-sp] [-pa]\n"
			"%s [-k|-ko file] [-kn|-kon file] [-sc mem[,cpu]] [-scn mem[,cpu]]\n"
			"%s [-nm] [-ad time] [-ads] [-b backup_file] [-run \"exe\" \"arg\"]\n"
			"%s [-cw] [-pp ...] [-fp \"arguments\"] [-t threads] [-bio]\n"
			"%s [-v verbose] [-aim] [-font ...]\n"
			"%S -l\n"
			"%S -ck file [-sc mem[,cpu]]\n"
			"%S -bm [cipher[,cipher[,cipher]]] [-t threads]\n\n"
			" mount_point\n"
			"\tSpecifies a drive letter (followed by a colon) or an empty directory\n"
			"\tlocated on a NTFS volume. If omitted, a drive letter is selected\n"
			"\tautomatically.\n\n"
			" -f\tImage File of the encrypted volume.\n\n"
			" -d\tNumber of physical Drive where the encrypted volume is located.\n"
			"\tDefault partition is 1. If a comma is added without partition number,\n"
			"\tthe partition table is ignored.\n"
			"\tUse # to replace the number by the signature. Use -l to retrieve it.\n\n"
			" -r\tMount a volume as Read-only.\n       __\n"
			" -c\tCreate a new encrypted volume. If a size and a file name are specified,\n"
			"\tan image file of this size will be created. Use k, m, g or t as suffix\n"
			"\tto specify KB, MB, GB or TB.\n\n"
			" -cr\tSame as -c but the content of the created volume (or file, if any) is\n"
			"\tfilled with Random data.\n\n"
			" -p\tNumber of Partition (default: 1). Use 0 to ignore the partition table\n"
			"\t(if any) and to use the whole disk or image.\n\n"
			" -o\tOffset to the encrypted volume inside the file/drive/partition.\n"
			"\tUse k, m, g, or t as suffix to specify KB, MB, GB or TB.\n\n"
			" -cp\tChange Password.\n\n"
			" -sp\tShow Password by default (can still be hidden with the Tab key).\n\n"
			" -pa\tUse the Password Alternate input method.\n       __\n"
			" -k\tKey file. Must be at least 64 bytes. Up to 4 KB is read.\n\n"
			" -ko\tKey file Only. Same as -k but password is not required.\n\n"
			" -kn\tNew Key file. Change or assign a key file on an existing volume.\n"
			"\tTo remove key file assignment, use NUL as file name.\n\n"
			" -kon\tNew Key file Only. Same as -kn but without password needed for the new\n"
			"\tkey file.\n\n"
			" -sc\tSCrypt parameters. The first value adjusts the RAM and CPU required for\n"
			"\tthe key derivation function, from 1 to 128 (default: 16). The second\n"
			"\tvalue only affects the CPU load, from 1 to 999 (default: 16).\n\n"
			" -scn\tSCrypt New parameters. Same as -sc, but the volume header is rewritten\n"
			"\twith these new values.\n       __\n"
			" -nm\tNo Mount. Allow operations such as password change without altering the\n"
			"\tvolume.\n\n"
			" -ad\tAuto-Dismount after a period of inactivity, in minutes.\n\n"
			" -ads\tAuto-Dismount when system enters a Suspended state.\n\n"
			" -b\tIf backup_file does not exist, it will be created with the content of\n"
			"\tthe volume header, encrypted with a new salt.\n"
			"\tIf backup_file exists, the volume header will be overwritten with the\n"
			"\tfirst 576 bytes of backup_file.\n\n"
			" -run\tRun an executable after the volume is mounted. If no argument is\n"
			"\trequired, use an empty quoted string.\n       __\n"
			" -cw\tClose the console Window after mounting if no error occurred.\n\n"
			" -pp\tParameters entered at the Prompts can be put here. Use 3 parameters for\n"
			"\tvolume creation, 1 otherwise, in same format and order than in the\n"
			"\tprompts. -cp, -kn and -kon must be put before this switch.\n\n"
			" -fp\tFormat Parameters. \"arguments\" is a quoted string passed to the format\n"
			"\tcommand. Ignored with Arsenal Image Mounter.\n\n"
			" -t\tNumber of Threads used for decryption and encryption, from 1 to 63\n"
			"\t(the default value is the number of logical processors).\n\n"
			" -bio\tUse Buffered I/O. Can fix compatibility issues with some hardwares.\n       __\n"
			" -v\tVerbosity level, from 0 to 2 (default: 1).\n\n"
			" -aim\tForce the use of Arsenal Image Mounter, in case of the ImDisk Virtual\n"
			"\tDisk Driver, which is used by default, is also installed.\n"
			"\tIf Arsenal Image Mounter is used, mount_point is ignored.\n\n"
			" -font\tChange the current console font, its size and colors. Use \"d\" as\n"
			"\targument to display current values and extra informations.\n       __\n"
			" -l\tDisplay a List of current physical drives and partitions, with location\n"
			"\tof first and last bytes.\n\n"
			" -ck\tCreate a new 512-byte Key file, filled with random data.\n\n"
			" -bm\tBenchmark of available ciphers.\n"
			"\tA cipher number can be specified, with 1=AES, 2=Serpent and 3=SHACAL-2.\n"
			"\tUse 2 or 3 numbers, separated by commas, for cascaded ciphers.\n\n\n"
			"-= Password editor usage =-\n"
			" Esc:\tQuit without volume mounting.\n\n"
			" Tab:\tShow/hide password.\n\n"
			" Enter:\tUsed with an empty password, it disables low level access to the\n"
			"\tkeyboard. This improves compatibility with some Input Method Editors\n"
			"\tbut removes protection against keyloggers.\n",
			file_name_ptr, global_str, global_str, global_str, global_str, global_str, file_name_ptr, file_name_ptr, file_name_ptr);
		ExitProcess(0);
	}

	GetSystemInfo(&sys);

	oa.Length = sizeof(oa);
	oa.ObjectName = &uni_str;
	show_pass = pass_alternate = FALSE;
	argc--;
	do {
		argv++;
		if (argv[0][0] == '-') {
			opt = argv[0] + 1;
			if (!_wcsicmp(opt, L"l")) {
				display_drives();
				ExitProcess(0);
			}
			if (!_wcsicmp(opt, L"ck")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				key_file = argv[0];
				create_kf = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"bm")) {
				bench = TRUE;
				i = j = 0;
				if (argc > 1 && swscanf(argv[1], L"%d,%d,%d", &dec_cipher, &i, &j)) {
					if (dec_cipher < 1 || dec_cipher > 3) dec_cipher = 1;
					if ((unsigned int)i > 3) i = 0;
					if ((unsigned int)j > 3) j = 0;
					dec_cipher += (i << 8) + (j << 16);
					argc--;
					argv++;
				}
				continue;
			}
			if (!_wcsicmp(opt, L"f")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				file_name_ptr = argv[0];
				continue;
			}
			if (!_wcsicmp(opt, L"d")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				partition_number = 0;
				if (argv[0][0] == L'#') {
					use_sig = TRUE;
					if (!swscanf(++argv[0], L"%8x%8x%8x%8x", &sig[0], &sig[1], &sig[2], &sig[3])) goto syntax_error;
					while (argv[0][1] && argv[0][1] != L',') argv[0]++;
					argv[0][0] = '0';
				}
				force_partition = swscanf(argv[0], L"%u%c%u", &drive_number, &suffix, &partition_number) >= 2;
				continue;
			}
			if (!_wcsicmp(opt, L"r")) {
				proxy_info.flags = IMDPROXY_FLAG_RO;
				continue;
			}
			if (!_wcsicmp(opt, L"c") || !_wcsicmp(opt, L"cr")) {
				rand_init = opt[1];
				new_volume = TRUE;
				if (argc > 1) {
					suffix = 0;
					if (swscanf(argv[1], L"%I64d%c", &new_file_size, &suffix)) {
						process_suffix(&new_file_size, suffix);
						if (new_file_size < 69 * 1024) {
							disp_err("New file size must be at least 69 KB.");
							ExitProcess(1);
						}
						argc--;
						argv++;
					}
				}
				continue;
			}
			if (!_wcsicmp(opt, L"p")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				swscanf(argv[0], L"%u", &partition_number);
				force_partition = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"o")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				suffix = 0;
				swscanf(argv[0], L"%I64d%c", &extra_offset, &suffix);
				process_suffix(&extra_offset, suffix);
				continue;
			}
			if (!_wcsicmp(opt, L"cp")) {
				change_pass = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"sp")) {
				show_pass = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"pa")) {
				pass_alternate = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"k")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				key_file = argv[0];
				continue;
			}
			if (!_wcsicmp(opt, L"ko")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				key_file = argv[0];
				pass_req = FALSE;
				continue;
			}
			if (!_wcsicmp(opt, L"kn")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				new_key_file = argv[0];
				continue;
			}
			if (!_wcsicmp(opt, L"kon")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				new_key_file = argv[0];
				new_pass_req = FALSE;
				continue;
			}
			if (!_wcsicmp(opt, L"sc")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				swscanf(argv[0], L"%u,%u", &scrypt_r, &scrypt_p);
				if (scrypt_r < 1) scrypt_r = 1;
				if (scrypt_r > 128) scrypt_r = 128;
				if (scrypt_p < 1) scrypt_p = 1;
				if (scrypt_p > 999) scrypt_p = 999;
				continue;
			}
			if (!_wcsicmp(opt, L"scn")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				swscanf(argv[0], L"%u,%u", &new_scrypt_r, &new_scrypt_p);
				if (new_scrypt_r < 1) new_scrypt_r = 1;
				if (new_scrypt_r > 128) new_scrypt_r = 128;
				if (new_scrypt_p < 1) new_scrypt_p = 1;
				if (new_scrypt_p > 999) new_scrypt_p = 999;
				continue;
			}
			if (!_wcsicmp(opt, L"nm")) {
				arg_mount = FALSE;
				continue;
			}
			if (!_wcsicmp(opt, L"ad")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				swscanf(argv[0], L"%I64u", &timeout);
				if (timeout < 1) timeout = 1;
				timeout *= -600000000;
				ad_timeout = (LARGE_INTEGER*)&timeout;
				continue;
			}
			if (!_wcsicmp(opt, L"ads")) {
				suspend_close = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"t")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				swscanf(argv[0], L"%u", &sys.dwNumberOfProcessors);
				continue;
			}
			if (!_wcsicmp(opt, L"b")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				backup_file = argv[0];
				continue;
			}
			if (!_wcsicmp(opt, L"cw")) {
				close_window = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"pp")) {
				if (argc < 2) goto syntax_error;
				use_prompt = FALSE;
				p1 = argv[1];
				argc--;
				argv++;
				if (!change_pass && !new_key_file) {
					if (argc < 3) goto syntax_error;
					p2 = argv[1];
					p3 = argv[2];
					argc -= 2;
					argv += 2;
				}
				continue;
			}
			if (!_wcsicmp(opt, L"fp")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				format_param = argv[0];
				continue;
			}
			if (!_wcsicmp(opt, L"run")) {
				if (argc < 3) goto syntax_error;
				run_command = VirtualAlloc(NULL, 32768 * sizeof(WCHAR), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
				_snwprintf(run_command, 32767, L"\"%s\" %s", argv[1], argv[2]);
				argc -= 2;
				argv += 2;
				continue;
			}
			if (!_wcsicmp(opt, L"bio")) {
				open_flags = FILE_WRITE_THROUGH;
				continue;
			}
			if (!_wcsicmp(opt, L"v")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				verbose = *argv[0] - '0';
				continue;
			}
			if (!_wcsicmp(opt, L"aim")) {
				force_aim = TRUE;
				continue;
			}
			if (!_wcsicmp(opt, L"font")) {
				if (--argc <= 0) goto syntax_error;
				argv++;
				hDLL = GetModuleHandleA("kernel32");
				if ((GetCurrentConsoleFontEx = GetProcAddress(hDLL, "GetCurrentConsoleFontEx"))) {
					h_console = GetStdHandle(STD_OUTPUT_HANDLE);
					cfi.cbSize = sizeof cfi;
					GetCurrentConsoleFontEx(h_console, FALSE, &cfi);
					SetConsoleFont(h_console, cfi.nFont); // Windows bug: the font name can be uninitialized
					GetCurrentConsoleFontEx(h_console, FALSE, &cfi);
					csbi.cbSize = sizeof csbi;
					GetProcAddress(hDLL, "GetConsoleScreenBufferInfoEx")(h_console, &csbi);
					if ((*argv[0] & ~0x20) == 'D') {
						printf("Arguments to -font must be comma-separated. Possible values are given below.\nUse # to keep current values. Colors are hex digits in BBGGRR format.\n"
							   "For instance, the following will set the font size to 12x16:\n -font 12,16\nTo change the background color to a mild blue:\n -font #,#,#,#,#,#,#,400000\n\n"
							   "width=%d\nheight=%d\nweight=%u\nindex=%u\nfamily=%u\nname=", cfi.dwFontSize.X, cfi.dwFontSize.Y, cfi.FontWeight, (unsigned int)cfi.nFont, cfi.FontFamily);
						_putws(cfi.FaceName);
						printf("foreground=%06X\nbackground=%06X\n", (unsigned int)csbi.ColorTable[csbi.wAttributes & 0xf], (unsigned int)csbi.ColorTable[(csbi.wAttributes & 0xf0) >> 4]);
						ExitProcess(0);
					} else {
						WCHAR *list_str[] = {L"%hd", L"%hd", L"%u", L"%u", L"%u", L"%31[^\n]", L"%x", L"%x"};
						void *list_ptr[] = {&cfi.dwFontSize.X, &cfi.dwFontSize.Y, &cfi.FontWeight, &cfi.nFont, &cfi.FontFamily, cfi.FaceName,
											&csbi.ColorTable[csbi.wAttributes & 0xf], &csbi.ColorTable[(csbi.wAttributes & 0xf0) >> 4]};
						for (i = 0; (tok = wcstok(i ? NULL : argv[0], L",")) && i < _countof(list_str); i++)
							if (tok[0] != '#') swscanf(tok, list_str[i], list_ptr[i]);
						csbi.srWindow.Right++; csbi.srWindow.Bottom++;
						GetProcAddress(hDLL, "SetConsoleScreenBufferInfoEx")(h_console, &csbi);
						GetProcAddress(hDLL, "SetCurrentConsoleFontEx")(h_console, FALSE, &cfi);
					}
				}
				continue;
			}
			if (!_wcsicmp(opt, L"noaesni")) {
				no_aesni = TRUE;
				continue;
			}
		}
		if (argv[0][1] == ':' && !argv[0][2]) {
			if ((unsigned short)((argv[0][0] & ~0x20) - 'A') > 25) {
syntax_error:
				disp_err("Syntax error.");
				ExitProcess(1);
			}
			if (GetLogicalDrives() & 1 << (argv[0][0] - 'A'))
				fwprintf(stderr, L"Warning: %s already in use.\n", argv[0]);
		} else {
			i = GetFileAttributes(argv[0]);
			if (i == INVALID_FILE_ATTRIBUTES || !(i & FILE_ATTRIBUTE_DIRECTORY)) goto invalid_dir;
			if (i & FILE_ATTRIBUTE_REPARSE_POINT)
				fwprintf(stderr, L"Warning: %s already in use.\n", argv[0]);
			else {
				h_reparse = CreateFile(argv[0], GENERIC_WRITE, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, NULL);
				reparse_buf.ReparseTag = 0x80000000;
				reparse_buf.ReparseDataLength = 0;
				if (DeviceIoControl(h_reparse, FSCTL_SET_REPARSE_POINT, &reparse_buf, sizeof reparse_buf, NULL, 0, &dw, NULL)) {
					DeviceIoControl(h_reparse, FSCTL_DELETE_REPARSE_POINT, &reparse_buf, sizeof reparse_buf, NULL, 0, &dw, NULL);
					NtClose(h_reparse);
				} else {
invalid_dir:
					fwprintf(stderr, L"Cannot use %s as mount point.\n", argv[0]);
					ExitProcess(GetLastError());
				}
			}
		}
		mount_point = argv[0];
	} while (--argc > 0);

	if (create_kf) ExitProcess(create_keyfile(key_file));

	aes_encrypt = aes_encrypt_sw;
	aes_decrypt = aes_decrypt_sw;
	if (CPUInfo[2] & 0x2000000 && !no_aesni) {
		out("AES instructions detected.\n");
		aes_encrypt = aes_encrypt_hw;
		aes_decrypt = aes_decrypt_hw;
	}

	// Create threads
	if (sys.dwNumberOfProcessors < 1) sys.dwNumberOfProcessors = 1;
	if (sys.dwNumberOfProcessors > MAX_THREAD) sys.dwNumberOfProcessors = MAX_THREAD;
	out("Uses %u thread%s for encryption/decryption.\n", sys.dwNumberOfProcessors, sys.dwNumberOfProcessors > 1 ? "s" : "");
	i = 0; do {
		if (!(encrypt_event[i] = create_event()) || !(decrypt_event[i] = create_event()) || !(io_crypt_done[i + 1] = create_event())) {
err_create_event:
			disp_err("CreateEvent() failed.");
			ExitProcess(last_err);
		}
		if (!CreateThread(NULL, 0, encrypt_thread, (void*)(size_t)i, 0, NULL) || !CreateThread(NULL, 0, decrypt_thread, (void*)(size_t)i, 0, NULL)) {
			disp_err("CreateThread() failed.");
			ExitProcess(last_err);
		}
	} while (++i < sys.dwNumberOfProcessors);

	if (!(io_crypt_done[0] = create_event()) || !(io_crypt_done[write_item = sys.dwNumberOfProcessors + 1] = CreateEventA(NULL, FALSE, TRUE, NULL))) goto err_create_event;

	keys = VirtualAlloc(NULL, sizeof(precomp_key) * 6, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

	if (bench) {
		benchmark(dec_cipher);
		ExitProcess(0);
	}

	wcscpy(file_name, L"imdisk");
	use_imdisk = start_process(file_name, CREATE_NO_WINDOW, FALSE);
	if (!use_imdisk || force_aim) {
		if ((h_aimapi = LoadLibraryA("aimapi.dll"))) {
			use_imdisk = FALSE;
			buffer_size = AIM_BUFFER_SIZE;
		} else {
			disp_err(force_aim ? "Cannot load aimapi.dll." : "Can load neither imdisk.exe nor aimapi.dll.");
			ExitProcess(last_err);
		}
	}
	if (use_imdisk) {
		if (!(h_cpl = LoadLibraryA("imdisk.cpl"))) {
			disp_err("Cannot load imdisk.cpl.");
			ExitProcess(last_err);
		}
		GetProcAddress(h_cpl, "ImDiskGetVersion")(&imdisk_version, NULL);
		FreeLibrary(h_cpl);
		if (imdisk_version < 0x0176) {
			disp_err("ImDisk 1.7.6 or later required.");
			ExitProcess(1);
		}
		if (!mount_point) {
			if ((drive_letter[0] = _bit_scan_forward(~(GetLogicalDrives() >> 3)) + 'D') > 'Z') {
				disp_err("Cannot find free drive letter.");
				ExitProcess(1);
			}
			mount_point = drive_letter;
		}
		GetFullPathName(L"imdisk.sys", _countof(file_name), file_name, NULL);
		h_scman = OpenSCManager(NULL, NULL, SC_MANAGER_CONNECT | SC_MANAGER_CREATE_SERVICE);
		if ((h_svc = CreateService(h_scman, L"ImDisk", L"ImDisk Virtual Disk Driver", SERVICE_START | DELETE, SERVICE_KERNEL_DRIVER, SERVICE_DEMAND_START, SERVICE_ERROR_IGNORE, file_name, NULL, NULL, NULL, NULL, NULL))) {
			if (!StartService(h_svc, 0, NULL) && verbose >= 2) out("ImDisk: cannot start service (%u).\n", GetLastError());
			DeleteService(h_svc);
			CloseServiceHandle(h_svc);
		} else if (verbose >= 2)
			out("ImDisk: cannot create service (%u).\n", GetLastError());
		CloseServiceHandle(h_scman);
	}

	if (proxy_info.flags && (new_file_size || new_key_file || new_scrypt_r || format_param[0])) {
		disp_err("-r incompatible with -c -cr -kn -kon -scn -fp.");
		ExitProcess(1);
	}

	build_file_name(file_name_ptr);
	if (new_file_size) {
		if (GetFileAttributes(file_name) != INVALID_FILE_ATTRIBUTES) {
			disp_err("Error: a file or folder of this name already exists.");
			ExitProcess(1);
		}
		proxy_info.file_size = new_file_size;
	} else {
		// Opening file or drive
		if (drive_number == -1) {
			if ((i = NtOpenFile(&h, proxy_info.flags ? GENERIC_READ : GENERIC_READ | GENERIC_WRITE, &oa, &iosb, FILE_SHARE_READ, open_flags)) != STATUS_SUCCESS) {
				fwprintf(stderr, L"Cannot open %s.\n", file_name);
				ExitProcess(i);
			}
			date_ok = NtQueryInformationFile(h, &iosb, &fbi, sizeof fbi, FileBasicInformation) == STATUS_SUCCESS;
			GetFileSizeEx(h, (LARGE_INTEGER*)&proxy_info.file_size);
		} else if (use_sig) {
			i = get_max_drive();
			for (drive_number = 0;; drive_number++) {
				if (drive_number > i) {
					disp_err("Cannot find the specified signature.");
					ExitProcess(1);
				}
				uni_str.Length = _snwprintf(file_name, _countof(file_name), L"\\??\\PhysicalDrive%d", drive_number) * sizeof(WCHAR);
				if (NtOpenFile(&h, proxy_info.flags ? GENERIC_READ : GENERIC_READ | GENERIC_WRITE, &oa, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE, open_flags) != STATUS_SUCCESS)
					continue;
				if (DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, dge, sizeof dge_buff, &dw, NULL)) {
					sector_size = dge->Geometry.BytesPerSector;
					proxy_info.file_size = dge->DiskSize.QuadPart;
					if ((dpi->PartitionStyle == PARTITION_STYLE_MBR && !memcmp(sig, &dpi->Mbr.Signature, 4)) || (dpi->PartitionStyle == PARTITION_STYLE_GPT && !memcmp(sig, &dpi->Mbr.Signature, 16))) break;
				}
				NtClose(h);
			}
		} else {
			uni_str.Length = _snwprintf(file_name, _countof(file_name), L"\\??\\PhysicalDrive%d", drive_number) * sizeof(WCHAR);
			if ((i = NtOpenFile(&h, proxy_info.flags ? GENERIC_READ : GENERIC_READ | GENERIC_WRITE, &oa, &iosb, FILE_SHARE_READ | FILE_SHARE_WRITE, open_flags)) != STATUS_SUCCESS) {
				fprintf(stderr, "Cannot open drive %d.\n", drive_number);
				ExitProcess(i);
			}
			if (DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, NULL, 0, dge, sizeof dge_buff, &dw, NULL)) {
				sector_size = dge->Geometry.BytesPerSector;
				proxy_info.file_size = dge->DiskSize.QuadPart;
			}
		}
	}
	if (sector_size < 512 || sector_size > 4096) {
		fprintf(stderr, "\nSector size must be at least 512-bytes and at most 4096-bytes\n(detected: %d)\n", sector_size);
		ExitProcess(1);
	}
	if (verbose >= 2) out("Sector size: %d.\n", sector_size);

	if (!proxy_info.file_size)
		disp_err("Cannot determine size of image/drive.\n");
	total_size = proxy_info.file_size;

	write_buf = VirtualAlloc(NULL, buffer_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	buf = VirtualAlloc(NULL, 4096 * 6 + DEF_BUFFER_SIZE, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	header = (HEADER_STRUCT*)(buf + 4096 * 2);
	password = (WCHAR*)(buf + 4096 * 4);
	prompt_buf = (WCHAR*)(buf + 4096 * 5);
	kf_buf = buf + 4096 * 5 + DEF_BUFFER_SIZE;

	if (!VirtualLock(buf, 4096 * 5) |
		!VirtualLock(keys, sizeof(precomp_key) * 6) |
		!VirtualLock(&thread_header_key, sizeof thread_header_key) |
		!VirtualLock(&tmp_header, sizeof tmp_header) |
		!VirtualLock(kf_buf, 4096))
		disp_err("Warning: cannot lock data into physical memory.\n");
	lock_large_buf(write_buf, buffer_size, 0);

	// Getting offset to the partition
	if (!new_file_size && partition_number >= 1 && partition_number <= 128 && total_size >= 2 * sector_size) {
		mbr = VirtualAlloc(NULL, 34 * sector_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
		raw_physical_read(mbr, 2 * 4096, 0);

		if (mbr[0x01BE + 4] == 0xEE && !memcmp(mbr + sector_size, "EFI PART\0\0\1", 12)) {
			out("GPT detected\n");

			entry_size = *(int*)(mbr + sector_size + 84);
			raw_physical_read(mbr, 34 * sector_size, 0);
			i = (((partition_number - 1) >> 2) + 2) * sector_size + ((partition_number - 1) & 3) * entry_size;
			if (*(__int64*)(mbr + i) | *(__int64*)(mbr + i + 8)) {
				global_offset = *(__int64*)(mbr + i + 32) * sector_size;
				proxy_info.file_size = (*(__int64*)(mbr + i + 40) + 1) * sector_size - global_offset;
			} else if (force_partition) {
				fprintf(stderr, "Partition %i not found.\n", partition_number);
				goto clean;
			}
		}
		else {
			if (*(USHORT*)(mbr + 0x01FE) == 0xAA55 && !((mbr[0x01BE] | mbr[0x01CE] | mbr[0x01DE] | mbr[0x01EE]) & 0x7F)) {
				out("MBR detected.\n");

				if (partition_number >= 5) {
					for (i = 0x01BE; i < 0x01FE; i += 16)
						if (mbr[i + 4] == 0x05 || mbr[i + 4] == 0x0F) {
							offset_ext = global_offset = (__int64)(*(UINT*)(mbr + i + 8)) * sector_size;
							raw_physical_read(mbr, 4096, global_offset);
							for (j = 5; j < partition_number; j++) {
								global_offset = offset_ext + (__int64)(*(UINT*)(mbr + 0x01CE + 8)) * sector_size;
								if (global_offset == offset_ext) {
									fprintf(stderr, "Partition %i not found.\n", partition_number);
									goto clean;
								}
								raw_physical_read(mbr, 4096, global_offset);
							}
							global_offset += (__int64)(*(UINT*)(mbr + 0x01BE + 8)) * sector_size;
							proxy_info.file_size = (__int64)(*(UINT*)(mbr + 0x01BE + 12)) * sector_size;
							break;
						}
					if (i == 0x01FE) {
						disp_err("No extended partition found.");
						goto clean;
					}
				} else {
					global_offset = (__int64)(*(UINT*)(mbr + 0x01AE + partition_number * 16 + 8)) * sector_size;
					proxy_info.file_size = (__int64)(*(UINT*)(mbr + 0x01AE + partition_number * 16 + 12)) * sector_size;
				}

				if (proxy_info.file_size)
					out("Partition %i used.\n", partition_number);
				else {
					if (force_partition) {
						fprintf(stderr, "Partition %i not found.\n", partition_number);
						goto clean;
					} else {
						global_offset = 0;
						proxy_info.file_size = total_size;
					}
				}
			} else
				out("No MBR/GPT detected. Uses entire image.\n");
		}
		VirtualFree(mbr, 0, MEM_RELEASE);
	}

	proxy_info.req_alignment = 1;
	out("Total size: %s bytes.\n", group_digit(total_size));
	out("%s bytes used from offset ", group_digit(proxy_info.file_size));
	out("%s.\n", group_digit(global_offset));

	global_offset += extra_offset;
	if (proxy_info.file_size < 65 * 1024 + 4096) {
		disp_err("Too small volume.");
		goto clean;
	}
	if (extra_offset > proxy_info.file_size - (65 * 1024 + 512)) {
		disp_err("Offset to the encrypted volume too high.");
		goto clean;
	}

	whirlpool_ini();
	keccak_ini();

	if (key_file) {
		out("Loading key file... ");
		if (load_key_file(key_file)) goto clean;
	}

	if (new_volume) {
		volume_offset = (extra_offset + 576 + 4095) & ~4095;
		max_volume_size = proxy_info.file_size - volume_offset;
		suffix = 0;
		if (use_prompt) {
			printf("\n-Enter size of the encrypted volume (65 KB - %I64u KB).\n Use k, m, g, or t as suffix, 0 for the maximum available,\n or a negative value related to the maximum.\n", max_volume_size >> 10);
			fgetws(p1 = prompt_buf, DEF_BUFFER_SIZE / sizeof(WCHAR), stdin);
		}
		swscanf(p1, L"%I64d%c", &size_new_volume, &suffix);
		process_suffix(&size_new_volume, suffix);
		if (size_new_volume <= 0) size_new_volume += max_volume_size;
		if (size_new_volume < 65 * 1024) size_new_volume = 65 * 1024;
		if (size_new_volume > max_volume_size) size_new_volume = max_volume_size;

		i = j = 0;
		if (use_prompt) {
			puts("\n-Select encryption algorithm.\n Use commas to combine up to 3 ciphers\n (e.g. 2,1 decrypts first with Serpent, then with AES)\n1: AES\n2: Serpent\n3: SHACAL-2");
			fgetws(p2 = prompt_buf, DEF_BUFFER_SIZE / sizeof(WCHAR), stdin);
		}
		swscanf(p2, L"%d,%d,%d", &dec_cipher, &i, &j);
		if (dec_cipher < 1 || dec_cipher > 3 || (unsigned int)i > 3 || (unsigned int)j > 3) {
			printf("Unrecognized value. %s selected by default.\n", "AES");
			dec_cipher = 1;
		} else
			dec_cipher += (i << 8) + (j << 16);
		enc_cipher = _bswap(dec_cipher);
		do enc_cipher >>= 8; while (!(enc_cipher & 0xff));

		if (use_prompt) {
			puts("\n-Select hash algorithm.\n1: Whirlpool\n2: Keccak-512");
			fgetws(p3 = prompt_buf, DEF_BUFFER_SIZE / sizeof(WCHAR), stdin);
		}
		swscanf(p3, L"%d", &n_hash);
		if (n_hash < 1 || n_hash > 2) {
			printf("Unrecognized value. %s selected by default.\n", "Whirlpool");
			n_hash = 1;
		}
		n_hash--;

		password[0] = 0;
		if (pass_req)
			for (;;) {
				puts("\nEnter password:");
				if (password_edit(password)) goto clean;
				wcscpy((WCHAR*)buf, password);
				puts("Confirm password:");
				if (password_edit(password)) goto clean;
				if (!wcscmp(password, (WCHAR*)buf)) break;
				puts("Passwords are different. Please retry.");
			}

		if (new_file_size) {
			// Creating file
			build_file_name(file_name_ptr);
			if ((i = NtCreateFile(&h, GENERIC_READ | GENERIC_WRITE, &oa, &iosb, NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_CREATE, FILE_WRITE_THROUGH, NULL, 0)) != STATUS_SUCCESS) {
				disp_err("Error: file cannot be created.");
				last_err = i;
				goto clean;
			}
			date_ok = NtQueryInformationFile(h, &iosb, &fbi, sizeof fbi, FileBasicInformation) == STATUS_SUCCESS;
			if ((i = NtSetInformationFile(h, &iosb, &new_file_size, sizeof new_file_size, FileEndOfFileInformation)) != STATUS_SUCCESS) {
				disp_err("Cannot create a file of the specified size.");
				last_err = i;
				NtClose(h);
				DeleteFile(file_name);
				goto clean;
			}
		}

		out("Creating master keys and salt...\n");
		if (rand_gen(buf, 2048 + 4096, n_hash, scrypt_r, scrypt_p)) goto clean;
		memcpy(tmp_header.ch, buf, 576);
		tmp_header.header.version = 2;
		whirlpool((unsigned char*)tmp_header.header.master_key, sizeof header->master_key, tmp_header.header.hash, 1, 1);
		tmp_header.header.volume_offset = volume_offset;
		tmp_header.header.volume_size = size_new_volume;

		out("Hashing authentication data...\n");
		pass_size = wcslen(password) * sizeof(WCHAR);
		memcpy((char*)password + pass_size, kf_buf, kf_size);
		if (scrypt(n_hash, password, pass_size + kf_size, buf, 64, 32768, scrypt_r, scrypt_p, header_key, sizeof thread_header_key.whirlpool)) goto clean;

		if (rand_init) {
			if (!RtlGenRandom(prompt_buf, DEF_BUFFER_SIZE)) {
				disp_err("RtlGenRandom() failed.");
				goto clean;
			}
			t = 0;
			init_key(buf + 1024);
			VirtualProtect(keys, sizeof(precomp_key) * 6, PAGE_READWRITE, &dw);
			if (new_file_size) {
				total_size = new_file_size;
				offset_ext = 0;
			} else {
				total_size = size_new_volume;
				offset_ext = global_offset + volume_offset - extra_offset;
			}
			rest = total_size & (DEF_BUFFER_SIZE - 1);
			if (drive_number != -1) rest &= ~(sector_size - 1);
			n = total_size / DEF_BUFFER_SIZE;
			for (a = 0; a <= n; a++) {
				ent.data.i = _rdtsc();
				GetCursorPos(&ent.data.curs_pos);
				ptr128 = (__m128i*)keys;
				for (b = 0; b < (sizeof(precomp_key) * 6) / sizeof(__m128i); b++, ptr128++)
					*ptr128 = _mm_add_epi64(*ptr128, ent.i128);
				if (ent.data.i - t > 400000000) {
					out("\rWriting random data... %.3f%%", (float)a * (DEF_BUFFER_SIZE * 100) / total_size);
					t = ent.data.i;
				}
				physical_write(prompt_buf, a < n ? DEF_BUFFER_SIZE : rest, offset_ext);
				offset_ext += DEF_BUFFER_SIZE;
			}
			out("\rWriting random data... 100%%    \n");
		}

		raw_physical_read(header, 2 * 4096, global_offset & ~4095);
		init_key(header_key);
		XTS_EncryptSector(enc_cipher, global_offset, 1, tmp_header.ch + 64);
		i = global_offset % 4096;
		memcpy((char*)header + i, tmp_header.ch, 576);
		memcpy((char*)header + i + 576, buf + 2048, 4095 - (i + 575) % 4096);
		raw_physical_write(header, 2 * 4096, global_offset & ~4095);
		puts("Volume created successfully.");
		XTS_DecryptSector(dec_cipher, global_offset, 1, tmp_header.ch + 64);
	}
	else
	{
		raw_physical_read(buf, 2 * 4096, global_offset & ~4095);
		memcpy(header, buf + (global_offset & 4095), 576);

		if (backup_file) {
			build_file_name(backup_file);
			if ((last_err = NtCreateFile(&h_backup, GENERIC_READ | GENERIC_WRITE | SYNCHRONIZE, &oa, &iosb, NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_OPEN_IF, FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0))
				!= STATUS_SUCCESS) {
				fwprintf(stderr, L"Cannot open %s.\n", file_name);
				goto clean;
			}
			if ((backup_file_exist = (UINT)iosb.Information == FILE_OPENED)) {
				if (proxy_info.flags) {
					disp_err("Cannot restore header in read-only.");
					goto clean;
				}
				if ((last_err = NtReadFile(h_backup, NULL, NULL, NULL, &iosb, header, 576, NULL, NULL)) != STATUS_SUCCESS || (UINT)iosb.Information < 512) {
					disp_err("Error while reading backup file.");
					goto clean;
				}
			}
		}

enter_password:
		dec_cipher = n_hash = 0;
		password[0] = 0;
		if (pass_req) {
			puts(change_pass ? "\nEnter current password:" : "\nEnter password:");
			if (password_edit(password)) goto clean;
			printf("Checking password...");
		} else
			printf("Checking key file...");

		pass_index = wcslen(password) * sizeof(WCHAR);
		memcpy((char*)password + pass_index, kf_buf, kf_size);
		pass_size = pass_index + kf_size;
		memcpy(salt_whirlpool, header->salt, 64);
		memcpy(salt_keccak, header->salt, 64);
		if (sys.dwNumberOfProcessors > 1) thread_handle = CreateThread(NULL, 0, derive_pass_keccak, NULL, 0, NULL);
		scrypt(PRF_WHIRLPOOL, password, pass_size, salt_whirlpool, 64, 32768, scrypt_r, scrypt_p, thread_header_key.whirlpool, sizeof thread_header_key.whirlpool);
		if (sys.dwNumberOfProcessors > 1) {
			NtWaitForSingleObject(thread_handle, FALSE, NULL);
			NtClose(thread_handle);
		}
		do {
			if (dec_cipher == 0x030303) {
				if (++n_hash > 1) {
					if (pass_req) {
						puts(" Error. Please retry.");
						goto enter_password;
					} else {
						puts(" Error.");
						goto clean;
					}
				}
				if (sys.dwNumberOfProcessors == 1) derive_pass_keccak(NULL);
				dec_cipher = 0;
			}
			dec_cipher++;
			if ((dec_cipher & 0xff) == 4) {
				dec_cipher += 0x100 - 3;
				if ((dec_cipher & 0xff00) == 0x400) dec_cipher += 0x10000 - 0x300;
			}
			init_key(n_hash ? thread_header_key.keccak : thread_header_key.whirlpool);
			memcpy(tmp_header.ch, header, 576);
			XTS_DecryptSector(dec_cipher, global_offset, 1, tmp_header.ch + 64);
			whirlpool((unsigned char*)tmp_header.header.master_key, tmp_header.header.version == 2 ? sizeof header->master_key : 6 * 32, buf, 1, 1);
		} while (memcmp(buf, tmp_header.header.hash, WHIRLPOOL_DIGESTSIZE));

		puts(" OK.");
		out("The used hash is scrypt/%s.\nCipher is %s%s%s%s%s.\n", n_hash ? "Keccak-512" : "Whirlpool",
			cipher_name[dec_cipher & 0xff], dec_cipher & 0xff00 ? "/" : "", cipher_name[(dec_cipher >> 8) & 0xff], dec_cipher & 0xff0000 ? "/" : "", cipher_name[dec_cipher >> 16]);

		enc_cipher = _bswap(dec_cipher);
		do enc_cipher >>= 8; while (!(enc_cipher & 0xff));

		if (new_scrypt_r) {
			scrypt_r = new_scrypt_r;
			scrypt_p = new_scrypt_p;
		}

		header_size = tmp_header.header.version == 1 ? 512 : 576;
		if (backup_file) {
			if (backup_file_exist) {
				memcpy((char*)buf + (global_offset & 4095), header, header_size);
				raw_physical_write(buf, 2 * 4096, global_offset & ~4095);
				out("Volume header written successfully.\n");
			} else {
				out("Creating new salt...\n");
				if (rand_gen((unsigned char*)header, 64, n_hash, scrypt_r, scrypt_p)) goto clean;
				out("Encrypting header...\n");
				if (scrypt(n_hash, password, pass_size, header, 64, 32768, scrypt_r, scrypt_p, header_key, sizeof thread_header_key.whirlpool)) goto clean;
				init_key(header_key);
				memcpy((unsigned char*)header + 64, tmp_header.ch + 64, 512);
				XTS_EncryptSector(enc_cipher, global_offset, 1, (unsigned char*)header + 64);
				if ((last_err = NtWriteFile(h_backup, NULL, NULL, NULL, &iosb, header, header_size, NULL, NULL)) != STATUS_SUCCESS || (UINT)iosb.Information != header_size) {
					disp_err("Error while saving volume header.");
					goto clean;
				}
				out("Volume header saved successfully.\n");
			}
			NtClose(h_backup);
		}

		if (new_key_file) {
			if (!_wcsicmp(new_key_file, L"NUL") && new_pass_req) 
				kf_size = 0;
			else {
				out("Loading new key file... ");
				if (load_key_file(new_key_file)) goto clean;
			}
		}

		if (change_pass || new_key_file) {
			if (pass_req && !new_pass_req) pass_index = 0;
			if (change_pass || (!pass_req && new_pass_req)) {
				for (;;) {
					puts("\nEnter new password:");
					if (password_edit(password)) goto clean;
					wcscpy((WCHAR*)buf, password);
					puts("Confirm new password:");
					if (password_edit(password)) goto clean;
					if (!wcscmp(password, (WCHAR*)buf)) break;
					puts("Passwords are different. Please retry.");
				}
				pass_index = wcslen(password) * sizeof(WCHAR);
			}
			if (use_prompt) {
				puts("\n-Select hash algorithm:\n1: Whirlpool\n2: Keccak-512");
				puts("(leave blank for no change)");
				fgetws(p1 = prompt_buf, DEF_BUFFER_SIZE / sizeof(WCHAR), stdin);
			}
			n_hash++;
			swscanf(p1, L"%d", &n_hash);
			if (n_hash < 1 || n_hash > 2) {
				printf("Unrecognized input. %s selected by default.\n", "Whirlpool");
				n_hash = 1;
			}
			n_hash--;
			memcpy((char*)password + pass_index, kf_buf, kf_size);
			pass_size = pass_index + kf_size;
		}
		if (new_scrypt_r || change_pass || new_key_file) {
			out("Creating new salt...\n");
			if (rand_gen(buf, 64, n_hash, scrypt_r, scrypt_p)) goto clean;
			out(change_pass || new_key_file ? "Hashing authentication data...\n" : "Changing scrypt parameters...\n");
			memcpy(tmp_header.header.salt, buf, 64);
			if (scrypt(n_hash, password, pass_size, buf, 64, 32768, scrypt_r, scrypt_p, header_key, sizeof thread_header_key.whirlpool)) goto clean;
			init_key(header_key);
			XTS_EncryptSector(enc_cipher, global_offset, 1, tmp_header.ch + 64);
			raw_physical_read(header, 2 * 4096, global_offset & ~4095);
			memcpy((char*)header + global_offset % 4096, tmp_header.ch, header_size);
			raw_physical_write(header, 2 * 4096, global_offset & ~4095);
			out("Done.\n");
			XTS_DecryptSector(dec_cipher, global_offset, 1, tmp_header.ch + 64);
		}
	}

	init_key(tmp_header.header.master_key);
	global_offset += (tmp_header.header.version == 1 ? tmp_header.header_v1.volume_offset : tmp_header.header.volume_offset) - extra_offset;
	proxy_info.file_size = tmp_header.header.version == 1 ? tmp_header.header_v1.volume_size : tmp_header.header.volume_size;
	out("Encrypted volume of %s bytes ", group_digit(proxy_info.file_size));
	out("at offset %s.\n\n", group_digit(global_offset));
	mount = arg_mount;

clean:
	SecureZeroMemory(buf, 4096 * 6 + DEF_BUFFER_SIZE);
	VirtualFree(buf, 0, MEM_RELEASE);
	SecureZeroMemory(&thread_header_key, sizeof thread_header_key);
	SecureZeroMemory(&tmp_header, sizeof tmp_header);
	pass_size = 0;

	exit_event = CreateEventA(NULL, FALSE, TRUE, NULL);
	clean_ok = create_event();
	if (mount) {
		console_hwnd = GetConsoleWindow();
		SetProcessShutdownParameters(0x100, 0);
		CreateThread(NULL, 0, msg_window, NULL, 0, NULL);
		do_comm();
	}

	VirtualProtect(keys, sizeof(precomp_key) * 6, PAGE_READWRITE, &dw);
	SecureZeroMemory(keys, sizeof(precomp_key) * 6);
	NtWaitForSingleObject(io_crypt_done[write_item], FALSE, NULL);
	NtClose(h);
	SecureZeroMemory(write_buf, buffer_size);
	if (date_ok) {
		build_file_name(file_name_ptr);
		NtOpenFile(&h, FILE_WRITE_ATTRIBUTES | SYNCHRONIZE, &oa, &iosb, FILE_SHARE_READ, FILE_WRITE_THROUGH | FILE_SYNCHRONOUS_IO_NONALERT);
		NtSetInformationFile(h, &iosb, &fbi, sizeof fbi, FileBasicInformation);
		NtClose(h);
	}
	t = -50000000;
	NtSignalAndWaitForSingleObject(clean_ok, exit_event, FALSE, (LARGE_INTEGER*)&t);

	ExitProcess(last_err);
}
