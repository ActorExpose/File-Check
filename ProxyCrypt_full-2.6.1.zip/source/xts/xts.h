#include "..\aes\aes.h"
#include "..\serpent\serpent.h"
#include "..\shacal2\shacal2.h"

#define CIPHER_AES 1
#define CIPHER_SERPENT 2
#define CIPHER_SHACAL2 3

typedef union {aes_key aes; serpent_key serpent; shacal2_key shacal2;} precomp_key;

void XTS_EncryptSector(int cipher, unsigned long long sector, int number_of_sectors, void *buffer);
void XTS_DecryptSector(int cipher, unsigned long long sector, int number_of_sectors, void *buffer);
