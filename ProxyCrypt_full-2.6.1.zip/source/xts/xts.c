#pragma GCC optimize "O3"
#include <intrin.h>
#include "xts.h"

extern int n_cipher;
extern precomp_key *keys;
extern void (*aes_encrypt)(aes_key *key, void *buffer);
extern void (*aes_decrypt)(aes_key *key, void *buffer);

// Mult(T): the 128 bits are left-shifted by 1; if the carry is 1, GF_128_FDBK is xor-ed.
#define Mult(T) \
{	__m128i c = _mm_shuffle_epi32(_mm_srli_epi64(T, 63), _MM_SHUFFLE(1, 0, 3, 2)); \
	T = (_mm_slli_epi64(T, 1) | c) ^ _mm_mul_epu32(c, GF_128_FDBK); }

#define Mult256(T0, T1) \
{	__m128i tmp0 = _mm_shuffle_epi32(_mm_srli_epi64(T0, 63), _MM_SHUFFLE(1, 0, 3, 2)); \
	__m128i tmp1 = _mm_srli_epi64(T1, 63); \
	__m128i c0 = _mm_unpackhi_epi64(tmp1, tmp0); \
	T0 = (_mm_slli_epi64(T0, 1) | c0) ^ _mm_mul_epu32(c0, GF_256_FDBK); \
	T1 = _mm_slli_epi64(T1, 1) | _mm_unpacklo_epi64(tmp0, tmp1); }


void XTS_EncryptSector(int cipher, unsigned long long sector, int number_of_sectors, void *buffer)
{
	void *key_ptr;
	__m128i T[8], *ptr;
	unsigned int i, ki, current_cipher;
	__m128i GF_128_FDBK = _mm_set_epi64x(0, 0x87 - 1);
	__m128i GF_256_FDBK = _mm_set_epi64x(0, 0x425 - 1);

	for (; number_of_sectors; number_of_sectors--, sector++, buffer += 512) {
		ki = n_cipher;
		current_cipher = cipher;
		do {
			ptr = buffer;
			ki -= 2;
			key_ptr = &keys[ki];

			T[0] = _mm_movpi64_epi64((__m64)sector);

			if ((unsigned char)current_cipher == CIPHER_AES) {
				aes_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 16; i++, ptr++) {
					*ptr ^= T[0];
					aes_encrypt(key_ptr, ptr);
					*ptr ^= T[0];
					Mult(T[0]);
				}
			}
			else if ((unsigned char)current_cipher == CIPHER_SERPENT) {
				serpent_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 64; i++, ptr += 4) {
					T[1] = T[0];
					Mult(T[1]);
					T[2] = T[1];
					Mult(T[2]);
					T[3] = T[2];
					Mult(T[3]);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					serpent_encrypt(key_ptr, ptr);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					T[0] = T[3];
					Mult(T[0]);
				}
			}
			else {
				T[1] = _mm_setzero_si128();
				shacal2_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 128; i++, ptr += 8) {
					T[2] = T[0]; T[3] = T[1];
					Mult256(T[2], T[3]);
					T[4] = T[2]; T[5] = T[3];
					Mult256(T[4], T[5]);
					T[6] = T[4]; T[7] = T[5];
					Mult256(T[6], T[7]);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					*(ptr + 4) ^= T[4];
					*(ptr + 5) ^= T[5];
					*(ptr + 6) ^= T[6];
					*(ptr + 7) ^= T[7];
					shacal2_encrypt(key_ptr, ptr);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					*(ptr + 4) ^= T[4];
					*(ptr + 5) ^= T[5];
					*(ptr + 6) ^= T[6];
					*(ptr + 7) ^= T[7];
					T[0] = T[6]; T[1] = T[7];
					Mult256(T[0], T[1]);
				}
			}
		} while (current_cipher >>= 8);
	}
}

void XTS_DecryptSector(int cipher, unsigned long long sector, int number_of_sectors, void *buffer)
{
	void *key_ptr;
	__m128i T[8], *ptr;
	unsigned int i, ki, current_cipher;
	__m128i GF_128_FDBK = _mm_set_epi64x(0, 0x87 - 1);
	__m128i GF_256_FDBK = _mm_set_epi64x(0, 0x425 - 1);

	for (; number_of_sectors; number_of_sectors--, sector++, buffer += 512) {
		ki = 0;
		current_cipher = cipher;
		do {
			ptr = buffer;
			key_ptr = &keys[ki];

			T[0] = _mm_movpi64_epi64((__m64)sector);

			if ((unsigned char)current_cipher == CIPHER_AES) {
				aes_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 16; i++, ptr++) {
					*ptr ^= T[0];
					aes_decrypt(key_ptr, ptr);
					*ptr ^= T[0];
					Mult(T[0]);
				}
			}
			else if ((unsigned char)current_cipher == CIPHER_SERPENT) {
				serpent_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 64; i++, ptr += 4) {
					T[1] = T[0];
					Mult(T[1]);
					T[2] = T[1];
					Mult(T[2]);
					T[3] = T[2];
					Mult(T[3]);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					serpent_decrypt(key_ptr, ptr);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					T[0] = T[3];
					Mult(T[0]);
				}
			}
			else {
				T[1] = _mm_setzero_si128();
				shacal2_encrypt((void*)&keys[ki + 1], T);
				for (i = 0; i < 512 / 128; i++, ptr += 8) {
					T[2] = T[0]; T[3] = T[1];
					Mult256(T[2], T[3]);
					T[4] = T[2]; T[5] = T[3];
					Mult256(T[4], T[5]);
					T[6] = T[4]; T[7] = T[5];
					Mult256(T[6], T[7]);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					*(ptr + 4) ^= T[4];
					*(ptr + 5) ^= T[5];
					*(ptr + 6) ^= T[6];
					*(ptr + 7) ^= T[7];
					shacal2_decrypt(key_ptr, ptr);
					*ptr ^= T[0];
					*(ptr + 1) ^= T[1];
					*(ptr + 2) ^= T[2];
					*(ptr + 3) ^= T[3];
					*(ptr + 4) ^= T[4];
					*(ptr + 5) ^= T[5];
					*(ptr + 6) ^= T[6];
					*(ptr + 7) ^= T[7];
					T[0] = T[6]; T[1] = T[7];
					Mult256(T[0], T[1]);
				}
			}

			ki += 2;
		} while (current_cipher >>= 8);
	}
}
