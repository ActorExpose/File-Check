typedef struct {
	unsigned int ks_enc[60], ks_dec[60];
} aes_key;

void aes_init(aes_key *key, void *key_init);
void aes_encrypt_sw(aes_key *key, void *buffer);
void aes_encrypt_hw(aes_key *key, void *buffer);
void aes_decrypt_sw(aes_key *key, void *buffer);
void aes_decrypt_hw(aes_key *key, void *buffer);
