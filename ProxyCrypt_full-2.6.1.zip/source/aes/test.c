#include <string.h>
#include <stdio.h>
#include "aes.h"

void (*aes_encrypt)(aes_key *key, void *buffer);
void (*aes_decrypt)(aes_key *key, void *buffer);

void display(char *s, unsigned char *buf, int size)
{
	int i;

	printf(s);
	for (i = 0; i < size; i++)
		printf("%02x", buf[i]);
	printf("\n");
}

int main (int argc, char *argv[])
{
	unsigned char k[32] = {0x2b, 0x7e, 0x15, 0x16, 0x28, 0xae, 0xd2, 0xa6, 0xab, 0xf7, 0x15, 0x88, 0x09, 0xcf, 0x4f, 0x3c, 0x76, 0x2e, 0x71, 0x60, 0xf3, 0x8b, 0x4d, 0xa5, 0x6a, 0x78, 0x4d, 0x90, 0x45, 0x19, 0x0c, 0xfe};
	unsigned char buf[16] = {0x32, 0x43, 0xf6, 0xa8, 0x88, 0x5a, 0x30, 0x8d, 0x31, 0x31, 0x98, 0xa2, 0xe0, 0x37, 0x07, 0x34};
	int i;
	aes_key key;

	aes_encrypt = aes_encrypt_sw;
	aes_decrypt = aes_decrypt_sw;

	aes_init(&key, k);

	printf("TEST 1:\n");
	display("txt: ", buf, sizeof buf);
	display("key: ", k, sizeof k);
	aes_encrypt(&key, buf);
	display("enc: ", buf, sizeof buf);
	printf("chk: 1a6e6c2c662e7da6501ffb62bc9e93f3\n");
	aes_decrypt(&key, buf);
	display("dec: ", buf, sizeof buf);

	for (i = 0; i < sizeof buf; i++) buf[i] = i * 16 + i;
	for (i = 0; i < sizeof k; i++) k[i] = i;
	aes_init(&key, k);

	printf("\nTEST 2:\n");
	display("txt: ", buf, sizeof buf);
	display("key: ", k, sizeof k);
	aes_encrypt(&key, buf);
	display("enc: ", buf, sizeof buf);
	printf("chk: 8ea2b7ca516745bfeafc49904b496089\n");
	aes_decrypt(&key, buf);
	display("dec: ", buf, sizeof buf);

	return 0;
}
