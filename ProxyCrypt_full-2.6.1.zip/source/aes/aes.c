#include <intrin.h>
#include "aes.h"
#include "..\config.h"

static unsigned int t_fn[4][256], t_fl[4][256], t_in[4][256], t_il[4][256];

void aes_init(aes_key *key, void *key_init)
{
	unsigned int i, w;
	unsigned int pow[510], log[256], t_rc[7], t_im[256];
	unsigned int *ss = key->ks_enc;
	unsigned char *ssc = (unsigned char*)key->ks_enc;

	i = 0; w = 1;
	do {
		pow[i] = pow[i + 255] = w;
		log[w] = i++;
		w ^= (w << 1) ^ ((w >> 7) * 0x011B);
	} while (w != 1);

	for (i = 0; i < 7; i++) {
		t_rc[i] = w;
		w = pow[log[w] + 0x19];
	}

	for (i = 0; i < 256; i++) {
		w = i ? pow[255 - log[i]] : 0;
		w ^= (w << 1) ^ (w << 2) ^ (w << 3) ^ (w << 4);
		w = ((w ^ (w >> 8)) & 0xff) ^ 0x63;

		t_fn[0][i] = w ? (pow[log[w] + 0x01] << 24) | pow[log[w] + 0x19] | w * 0x00010100 : 0;
		t_fn[3][i] = _rotl(t_fn[2][i] = _rotl(t_fn[1][i] = _rotl(t_fn[0][i], 8), 8), 8);

		t_fl[3][i] = (t_fl[2][i] = (t_fl[1][i] = (t_fl[0][i] = w) << 8) << 8) << 8;

		w = (i << 1) ^ (i << 3) ^ (i << 6);
		w = ((w ^ (w >> 8)) & 0xff) ^ 0x05;
		if (w) w = pow[255 - log[w]];

		t_in[0][i] = t_im[w] = w ? (pow[log[w] + 0x68] << 24) | (pow[log[w] + 0xee] << 16) | (pow[log[w] + 0xc7] << 8) | pow[log[w] + 0xdf] : 0;
		t_in[3][i] = _rotl(t_in[2][i] = _rotl(t_in[1][i] = _rotl(t_in[0][i], 8), 8), 8);

		t_il[3][i] = (t_il[2][i] = (t_il[1][i] = (t_il[0][i] = w) << 8) << 8) << 8;
	}

	for (i = 0; i < 60; i++)
		key->ks_enc[i] = key->ks_dec[56 + (i & 3) - (i & ~7) - (i & 4)] = i < 8 ? ((unsigned int*)key_init)[i] :
			(ss[i & 7] ^= (i & 7) == 0 ? t_fl[0][ssc[29]] ^ t_fl[1][ssc[30]] ^ t_fl[2][ssc[31]] ^ t_fl[3][ssc[28]] ^ t_rc[(i >> 3) - 1] :
						  (i & 7) == 4 ? t_fl[0][ssc[12]] ^ t_fl[1][ssc[13]] ^ t_fl[2][ssc[14]] ^ t_fl[3][ssc[15]] :
						  ss[(i & 7) - 1]);

	memcpy(key->ks_enc, key_init, 32);

	for (i = 4; i < 56; i++)
		key->ks_dec[i] = t_im[key->ks_dec[i] & 0xff] ^ _rotl(t_im[(key->ks_dec[i] >> 8) & 0xff], 8) ^ _rotl(t_im[(key->ks_dec[i] >> 16) & 0xff], 16) ^ _rotl(t_im[key->ks_dec[i] >> 24], 24);
}

__attribute__((optimize(AES_ENC_OPTI)))
void aes_encrypt_sw(aes_key *key, void *buffer)
{
	unsigned int b0[4], b1[3], rnd;
	unsigned int *kp = key->ks_enc;

	b0[0] = ((unsigned int*)buffer)[0] ^ kp[0];
	b0[1] = ((unsigned int*)buffer)[1] ^ kp[1];
	b0[2] = ((unsigned int*)buffer)[2] ^ kp[2];
	b0[3] = ((unsigned int*)buffer)[3] ^ kp[3];

	rnd = 13;
	do {
		kp += 4;
		b1[0] = kp[0] ^ t_fn[0][b0[0] & 0xff] ^ t_fn[1][(b0[1] >> 8) & 0xff] ^ t_fn[2][(b0[2] >> 16) & 0xff] ^ t_fn[3][b0[3] >> 24];
		b1[1] = kp[1] ^ t_fn[0][b0[1] & 0xff] ^ t_fn[1][(b0[2] >> 8) & 0xff] ^ t_fn[2][(b0[3] >> 16) & 0xff] ^ t_fn[3][b0[0] >> 24];
		b1[2] = kp[2] ^ t_fn[0][b0[2] & 0xff] ^ t_fn[1][(b0[3] >> 8) & 0xff] ^ t_fn[2][(b0[0] >> 16) & 0xff] ^ t_fn[3][b0[1] >> 24];
		b0[3] = kp[3] ^ t_fn[0][b0[3] & 0xff] ^ t_fn[1][(b0[0] >> 8) & 0xff] ^ t_fn[2][(b0[1] >> 16) & 0xff] ^ t_fn[3][b0[2] >> 24];
		b0[0] = b1[0]; b0[1] = b1[1]; b0[2] = b1[2];
	} while (--rnd);
	((unsigned int*)buffer)[0] = kp[4] ^ t_fl[0][b0[0] & 0xff] ^ t_fl[1][(b0[1] >> 8) & 0xff] ^ t_fl[2][(b0[2] >> 16) & 0xff] ^ t_fl[3][b0[3] >> 24];
	((unsigned int*)buffer)[1] = kp[5] ^ t_fl[0][b0[1] & 0xff] ^ t_fl[1][(b0[2] >> 8) & 0xff] ^ t_fl[2][(b0[3] >> 16) & 0xff] ^ t_fl[3][b0[0] >> 24];
	((unsigned int*)buffer)[2] = kp[6] ^ t_fl[0][b0[2] & 0xff] ^ t_fl[1][(b0[3] >> 8) & 0xff] ^ t_fl[2][(b0[0] >> 16) & 0xff] ^ t_fl[3][b0[1] >> 24];
	((unsigned int*)buffer)[3] = kp[7] ^ t_fl[0][b0[3] & 0xff] ^ t_fl[1][(b0[0] >> 8) & 0xff] ^ t_fl[2][(b0[1] >> 16) & 0xff] ^ t_fl[3][b0[2] >> 24];
}

__attribute__((__target__("aes"))) __attribute__((optimize("-O3")))
void aes_encrypt_hw(aes_key *key, void *buffer)
{
	__m128i tmp;
	unsigned int rnd;

	tmp = *(__m128i*)buffer ^ ((__m128i*)key->ks_enc)[0];
	for (rnd = 1; rnd < 14; rnd++)
		tmp = _mm_aesenc_si128(tmp, ((__m128i*)key->ks_enc)[rnd]);
	*(__m128i*)buffer = _mm_aesenclast_si128(tmp, ((__m128i*)key->ks_enc)[14]);
}


__attribute__((optimize(AES_DEC_OPTI)))
void aes_decrypt_sw(aes_key *key, void *buffer)
{
	unsigned int b0[4], b1[3], rnd;
	unsigned int *kp = key->ks_dec;

	b0[0] = ((unsigned int*)buffer)[0] ^ kp[0];
	b0[1] = ((unsigned int*)buffer)[1] ^ kp[1];
	b0[2] = ((unsigned int*)buffer)[2] ^ kp[2];
	b0[3] = ((unsigned int*)buffer)[3] ^ kp[3];

	rnd = 13;
	do {
		kp += 4;
		b1[0] = kp[0] ^ t_in[0][b0[0] & 0xff] ^ t_in[1][(b0[3] >> 8) & 0xff] ^ t_in[2][(b0[2] >> 16) & 0xff] ^ t_in[3][b0[1] >> 24];
		b1[1] = kp[1] ^ t_in[0][b0[1] & 0xff] ^ t_in[1][(b0[0] >> 8) & 0xff] ^ t_in[2][(b0[3] >> 16) & 0xff] ^ t_in[3][b0[2] >> 24];
		b1[2] = kp[2] ^ t_in[0][b0[2] & 0xff] ^ t_in[1][(b0[1] >> 8) & 0xff] ^ t_in[2][(b0[0] >> 16) & 0xff] ^ t_in[3][b0[3] >> 24];
		b0[3] = kp[3] ^ t_in[0][b0[3] & 0xff] ^ t_in[1][(b0[2] >> 8) & 0xff] ^ t_in[2][(b0[1] >> 16) & 0xff] ^ t_in[3][b0[0] >> 24];
		b0[0] = b1[0]; b0[1] = b1[1]; b0[2] = b1[2];
	} while (--rnd);
	((unsigned int*)buffer)[0] = kp[4] ^ t_il[0][b0[0] & 0xff] ^ t_il[1][(b0[3] >> 8) & 0xff] ^ t_il[2][(b0[2] >> 16) & 0xff] ^ t_il[3][b0[1] >> 24];
	((unsigned int*)buffer)[1] = kp[5] ^ t_il[0][b0[1] & 0xff] ^ t_il[1][(b0[0] >> 8) & 0xff] ^ t_il[2][(b0[3] >> 16) & 0xff] ^ t_il[3][b0[2] >> 24];
	((unsigned int*)buffer)[2] = kp[6] ^ t_il[0][b0[2] & 0xff] ^ t_il[1][(b0[1] >> 8) & 0xff] ^ t_il[2][(b0[0] >> 16) & 0xff] ^ t_il[3][b0[3] >> 24];
	((unsigned int*)buffer)[3] = kp[7] ^ t_il[0][b0[3] & 0xff] ^ t_il[1][(b0[2] >> 8) & 0xff] ^ t_il[2][(b0[1] >> 16) & 0xff] ^ t_il[3][b0[0] >> 24];
}

__attribute__((__target__("aes"))) __attribute__((optimize("-O3")))
void aes_decrypt_hw(aes_key *key, void *buffer)
{
	__m128i tmp;
	unsigned int rnd;

	tmp = *(__m128i*)buffer ^ ((__m128i*)key->ks_dec)[0];
	for (rnd = 1; rnd < 14; rnd++)
		tmp = _mm_aesdec_si128(tmp, ((__m128i*)key->ks_dec)[rnd]);
	*(__m128i*)buffer = _mm_aesdeclast_si128(tmp, ((__m128i*)key->ks_dec)[14]);
}
