These sources are compiled with Mingw-w64 10.2.1, available here: https://gcc-mcf.lhmouse.com/
64-bit:
https://gcc-mcf.lhmouse.com/mingw-w64-gcc-mcf_20201010_10.2.1_x64_554c631b4f4c3b9d9de8721f04ee2287d6b7ad0d.7z
32-bit:
https://gcc-mcf.lhmouse.com/mingw-w64-gcc-mcf_20201010_10.2.1_x86_3b362c8b23ad5514b005aa15ad0eb55ae76276a1.7z

Source files can be used without any restriction and are provided without any warranty.
