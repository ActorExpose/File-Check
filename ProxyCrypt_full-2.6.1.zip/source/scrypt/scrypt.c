#pragma GCC optimize "O3"
#include <windows.h>
#include <stdio.h>
#include <intrin.h>
#include "..\whirlpool\whirlpool.h"
#include "..\keccak\keccak.h"
#include "..\sha256\sha256.h"
#include "..\misc\misc.h"
#include "scrypt.h"


__attribute__((optimize("-O1")))
void hmac(HASH_PROC hash, int hash_digestsize, int hash_blocksize, unsigned char *ipad, unsigned char *k, int lk, unsigned char *d, int ld, unsigned char *out)
{
	unsigned char *key = ipad + 64, *buf = ipad + 128;
	int i;

	if (lk > hash_blocksize) {
		hash(k, lk, key, 1, 1);
		k = key;
		lk = hash_digestsize;
	}

	__stosb(buf, 0x36, hash_blocksize);
	for (i = 0; i < lk; i++)
		buf[i] ^= k[i];

	hash(buf, hash_blocksize, ipad, 1, 0);
	hash(d, ld, ipad, 0, 1);

	__stosb(buf, 0x5C, hash_blocksize);
	for (i = 0; i < lk; i++)
		buf[i] ^= k[i];

	hash(buf, hash_blocksize, out, 1, 0);
	hash(ipad, hash_digestsize, out, 0, 1);
}

static void derive_key(HASH_PROC hash, int hash_digestsize, int hash_blocksize, unsigned char *ipad, unsigned char *pwd, int pwd_len, unsigned char *salt, int salt_len, unsigned char *dk, int dklen)
{
	int b, l = dklen / hash_digestsize;

	for (b = 1; b <= l; b++) {
		// scrypt needs only the 1st iteration of PBKDF2
		*(unsigned long*)(salt + salt_len) = _bswap(b);
		hmac(hash, hash_digestsize, hash_blocksize, ipad, pwd, pwd_len, salt, salt_len + 4, dk);
		dk += hash_digestsize;
	}
}


static void blkcpy128(__m128i *dest, __m128i *src, unsigned int len)
{
	unsigned int i;

	for (i = 0; i < len; i++)
		dest[i] = src[i];
}

static void blkxor128(__m128i *dest, __m128i *src, unsigned int len)
{
	unsigned int i;

	for (i = 0; i < len; i++)
		dest[i] ^= src[i];
}

__attribute__((optimize("-O2")))
static void salsa20_8(__m128i *B)
{
	__m128i X0, X1, X2, X3, T;
	unsigned char i;

	X0 = B[0];
	X1 = B[1];
	X2 = B[2];
	X3 = B[3];

	for (i = 0; i < 4; i++) {
		T = _mm_add_epi32(X0, X3);
		X1 ^= _mm_slli_epi32(T, 7) ^ _mm_srli_epi32(T, 25);
		T = _mm_add_epi32(X1, X0);
		X2 ^= _mm_slli_epi32(T, 9) ^ _mm_srli_epi32(T, 23);
		T = _mm_add_epi32(X2, X1);
		X3 ^= _mm_slli_epi32(T, 13) ^ _mm_srli_epi32(T, 19);
		T = _mm_add_epi32(X3, X2);
		X0 ^= _mm_slli_epi32(T, 18) ^ _mm_srli_epi32(T, 14);

		X1 = _mm_shuffle_epi32(X1, 0x93); // 32-bit left rotate
		X2 = _mm_shuffle_epi32(X2, 0x4E); // 64-bit swap
		X3 = _mm_shuffle_epi32(X3, 0x39); // 32-bit right rotate

		T = _mm_add_epi32(X0, X1);
		X3 ^= _mm_slli_epi32(T, 7) ^ _mm_srli_epi32(T, 25);
		T = _mm_add_epi32(X3, X0);
		X2 ^= _mm_slli_epi32(T, 9) ^ _mm_srli_epi32(T, 23);
		T = _mm_add_epi32(X2, X3);
		X1 ^= _mm_slli_epi32(T, 13) ^ _mm_srli_epi32(T, 19);
		T = _mm_add_epi32(X1, X2);
		X0 ^= _mm_slli_epi32(T, 18) ^ _mm_srli_epi32(T, 14);

		X1 = _mm_shuffle_epi32(X1, 0x39);
		X2 = _mm_shuffle_epi32(X2, 0x4E);
		X3 = _mm_shuffle_epi32(X3, 0x93);
	}

	B[0] = _mm_add_epi32(B[0], X0);
	B[1] = _mm_add_epi32(B[1], X1);
	B[2] = _mm_add_epi32(B[2], X2);
	B[3] = _mm_add_epi32(B[3], X3);
}

static void blockmix_salsa8(__m128i *Bin, __m128i *Bout, __m128i *X, unsigned int r)
{
	unsigned int i;

	blkcpy128(X, &Bin[8 * r - 4], 4);

	for (i = 0; i < r; i++) {
		blkxor128(X, &Bin[i * 8], 4);
		salsa20_8(X);
		blkcpy128(&Bout[i * 4], X, 4);
		blkxor128(X, &Bin[i * 8 + 4], 4);
		salsa20_8(X);
		blkcpy128(&Bout[(r + i) * 4], X, 4);
	}
}

static unsigned long integerify(void *B, unsigned int r)
{
/*	with N > 32-bit:
	unsigned long *X = B + 128 * r - 64;
	return (((unsigned long long)X[13] << 32) + X[0]);*/

	return *(unsigned long*)(B + 128 * r - 64);
}

static void smix(unsigned char *B, unsigned int r, unsigned long N, void *V, void *XY)
{
	__m128i *Y = XY + 128 * r;
	__m128i *Z = XY + 256 * r;
	unsigned long i, j;

	for (j = 0; j < 32 * r; j += 16)
		for (i = 0; i < 16; i++)
			((unsigned int*)XY)[j + i] = ((unsigned int*)B)[j + (i * 5 & 15)];

	for (i = 0; i < N; i += 2) {
		blkcpy128(V + i * 128 * r, XY, 8 * r);
		blockmix_salsa8(XY, Y, Z, r);
		blkcpy128(V + (i + 1) * 128 * r, Y, 8 * r);
		blockmix_salsa8(Y, XY, Z, r);
	}

	for (i = 0; i < N; i += 2) {
		j = integerify(XY, r) & (N - 1);
		blkxor128(XY, V + j * 128 * r, 8 * r);
		blockmix_salsa8(XY, Y, Z, r);
		j = integerify(Y, r) & (N - 1);
		blkxor128(Y, V + j * 128 * r, 8 * r);
		blockmix_salsa8(Y, XY, Z, r);
	}

	for (j = 0; j < 32 * r; j += 16)
		for (i = 0; i < 16; i++)
			((unsigned int*)B)[j + (i * 5 & 15)] = ((unsigned int*)XY)[j + i];
}


int scrypt(int prf, void *passwd, unsigned int passwdlen, void *salt, unsigned int saltlen, unsigned long N, unsigned int r, unsigned int p, void *result, unsigned int resultlen)
// salt must be 4-byte free at its end, saltlen doesn't include these bytes
// resultlen must be a multiple of 64 bytes
{
	unsigned char *B;
	unsigned int *V, *XY;
	unsigned int i;
	size_t size_B, size_V, size_XY, total_size;

	size_B = 128 * r * p;
	size_V = 128 * r * N;
	size_XY = 256 * r + 64;
	total_size = size_B + 16 + size_V + size_XY;
	if (!(B = VirtualAlloc(NULL, total_size, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE))) {
		fputs("Cannot allocate memory for scrypt.", stderr);
		return 1;
	}
	V = (unsigned int*)(B + size_B + 16);
	XY = (unsigned int*)((char*)V + size_V);

	lock_large_buf(B, total_size, 0);

#ifdef TEST_SHA256
	if (prf == PRF_SHA256)
		derive_key(sha256, SHA256_DIGESTSIZE, SHA256_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, salt, saltlen, B, size_B);
	else
#endif
	if (prf == PRF_WHIRLPOOL)
		derive_key(whirlpool, WHIRLPOOL_DIGESTSIZE, WHIRLPOOL_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, salt, saltlen, B, size_B);
	else
		derive_key(keccak, KECCAK_DIGESTSIZE, KECCAK_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, salt, saltlen, B, size_B);

	for (i = 0; i < p; i++)
		smix(&B[i * 128 * r], r, N, V, XY);

#ifdef TEST_SHA256
	if (prf == PRF_SHA256)
		derive_key(sha256, SHA256_DIGESTSIZE, SHA256_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, B, size_B, result, resultlen);
	else
#endif
	if (prf == PRF_WHIRLPOOL)
		derive_key(whirlpool, WHIRLPOOL_DIGESTSIZE, WHIRLPOOL_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, B, size_B, result, resultlen);
	else
		derive_key(keccak, KECCAK_DIGESTSIZE, KECCAK_BLOCKSIZE, (unsigned char*)XY, passwd, passwdlen, B, size_B, result, resultlen);

	SecureZeroMemory(B, total_size);
	lock_large_buf(B, total_size, 1);

	return 0;
}
