#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "..\sha256\sha256.h"
#include "..\whirlpool\whirlpool.h"
#include "..\keccak\keccak.h"
#include "scrypt.h"

static unsigned char result[64];

void display(int size)
{
	int i;

	printf("Result:   ");
	for (i = 0; i < size; i++) {
		if (i == 32) printf("\n          ");
		printf("%02X", result[i]);
	}
	printf("\n");
}

int wmain()
{
	unsigned char k[131];
	unsigned char buf[64 + 64 + 72];
	DWORD time;
	int i;

	printf("\n- test 1 HMAC-SHA256:\n");
	hmac(sha256, SHA256_DIGESTSIZE, SHA256_BLOCKSIZE, buf, (unsigned char*)"key", 3, (unsigned char*)"The quick brown fox jumps over the lazy dog", 43, result);
	display(32);
	printf("Expected: F7BC83F430538424B13298E6AA6FB143EF4D59A14946175997479DBC2D1A3CD8\n");

	printf("\n- test 2 HMAC-SHA256:\n");
	for (i = 0; i < 80; i++) k[i] = 0xAA;
	hmac(sha256, SHA256_DIGESTSIZE, SHA256_BLOCKSIZE, buf, k, 80, (unsigned char*)"Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data", 73, result);
	display(32);
	printf("Expected: 6355AC22E890D0A3C8481A5CA4825BC884D3E7A1FF98A2FC2AC7D8E064C3B2E6\n");


	whirlpool_ini();
	keccak_ini();

	printf("\n\n- test 1 HMAC-Whirlpool:\n");
	hmac(whirlpool, WHIRLPOOL_DIGESTSIZE, WHIRLPOOL_BLOCKSIZE, buf, (unsigned char*)"Salt", 4, NULL, 0, result);
	display(64);
	printf("Expected: B3AF4D80B3796DFBB24D6488AE04052119B9C27C4556D7757D55C5F9FB556689\n          92502BBB04BBC7C8AF8E1ABCB318A264D042C7982A9EEEDB7C330581AC2857ED\n");

	printf("\n- test 2 HMAC-Whirlpool:\n");
	hmac(whirlpool, WHIRLPOOL_DIGESTSIZE, WHIRLPOOL_BLOCKSIZE, buf, (unsigned char*)"Salt", 4, (unsigned char*)"abcd", 4, result);
	display(64);
	printf("Expected: 76A6E9A05704C83B36C9BCB8F60AE647005913A4655AF0BABEBBC9B6D394A452\n          5D3B4AB1839419D57B6E8519C99A93DDB9E182F3305F5422DC2F95134C01D451\n");

	printf("\n- test 3 HMAC-Whirlpool:\n");
	hmac(whirlpool, WHIRLPOOL_DIGESTSIZE, WHIRLPOOL_BLOCKSIZE, buf, (unsigned char*)"12345678901234567890123456789012345678901234567890123456789012345678901234567890", 80, (unsigned char*)"abcd", 4, result);
	display(64);
	printf("Expected: 0BC6B9A18397ADED0C40F550EB4CC7CFF8C998AFC17FBB850FC1E88A4625915D\n          BC7B506B6455B92092B04D8E2050BD586B91F89901FC716A67B4E597253B3B5C\n");


	printf("\n\n- test 1 HMAC-Keccak:\n");
	for (i = 0; i < 20; i++) k[i] = 0x0B;
	hmac(keccak, KECCAK_DIGESTSIZE, KECCAK_BLOCKSIZE, buf, k, 20, (unsigned char*)"Hi There", 8, result);
	display(64);
	printf("Expected: 8852C63BE8CFC21541A4EE5E5A9A852FC2F7A9ADEC2FF3A13718AB4ED81AAEA0\n          B87B7EB397323548E261A64E7FC75198F6663A11B22CD957F7C8EC858A1C7755\n");

	printf("\n- test 2 HMAC-Keccak:\n");
	hmac(keccak, KECCAK_DIGESTSIZE, KECCAK_BLOCKSIZE, buf, (unsigned char*)"Jefe", 4, (unsigned char*)"what do ya want for nothing?", 28, result);
	display(64);
	printf("Expected: C2962E5BBE1238007852F79D814DBBECD4682E6F097D37A363587C03BFA2EB08\n          59D8D9C701E04CECECFD3DD7BFD438F20B8B648E01BF8C11D26824B96CEBBDCB\n");

	printf("\n- test 3 HMAC-Keccak:\n");
	for (i = 0; i < 131; i++) k[i] = 0xAA;
	hmac(keccak, KECCAK_DIGESTSIZE, KECCAK_BLOCKSIZE, buf, k, 131, (unsigned char*)
		 "\x54\x68\x69\x73\x20\x69\x73\x20\x61\x20\x74\x65\x73\x74\x20\x75\x73\x69\x6E\x67\x20\x61\x20\x6C\x61\x72\x67\x65\x72\x20\x74\x68\x61\x6E\x20\x62\x6C\x6F\x63\x6B\x2D\x73\x69\x7A\x65\x20\x6B\x65\x79\x20"
		 "\x61\x6E\x64\x20\x61\x20\x6C\x61\x72\x67\x65\x72\x20\x74\x68\x61\x6E\x20\x62\x6C\x6F\x63\x6B\x2D\x73\x69\x7A\x65\x20\x64\x61\x74\x61\x2E\x20\x54\x68\x65\x20\x6B\x65\x79\x20\x6E\x65\x65\x64\x73\x20\x74"
		 "\x6F\x20\x62\x65\x20\x68\x61\x73\x68\x65\x64\x20\x62\x65\x66\x6F\x72\x65\x20\x62\x65\x69\x6E\x67\x20\x75\x73\x65\x64\x20\x62\x79\x20\x74\x68\x65\x20\x48\x4D\x41\x43\x20\x61\x6C\x67\x6F\x72\x69\x74\x68"
		 "\x6D\x2E", 152, result);
	display(64);
	printf("Expected: 2C6B9748D35C4C8DB0B4407DD2ED2381F133BDBD1DFAA69E30051EB6BADFCCA6\n          4299B88AE05FDBD3DD3DD7FE627E42E39E48B0FE8C7E1E85F2DBD52C2D753572\n");


	printf("\n\n- test scrypt-Whirlpool:\n");
	time = GetTickCount();
	strcpy((char*)k, "salt");
	scrypt(PRF_WHIRLPOOL, (unsigned char*)"test", 4, k, 4, 32768, 16, 8, result, sizeof result);
	display(64);
	printf("Expected: DE04C0F30525B972CCBE68966FFE85C15A9AD846F0F65DABC1FCCDBB6113B2C7\n          6C097067639249C0C5519E748CD688D88804DA79BDB52A8A55312E45701AE979\n");
	printf("(time for scrypt-Whirlpool: %lu ms)\n", GetTickCount() - time);

	printf("\n- test scrypt-Keccak:\n");
	time = GetTickCount();
	scrypt(PRF_KECCAK, (unsigned char*)"test", 4, k, 4, 32768, 16, 8, result, sizeof result);
	display(64);
	printf("Expected: 4F721A7DDC043EBC1E9FF5C3CB1705D21F3536A5C1646B29683BDCC13AB17DF1\n          6E1A3F1E057A7E030907D195AAB028060E20D4AFB269C69B819F161FF21D9DC1\n");
	printf("(time for scrypt-Keccak: %lu ms)\n", GetTickCount() - time);

	printf("\n- test scrypt-SHA256:\n");
	strcpy((char*)k, "NaCl");
	scrypt(PRF_SHA256, (unsigned char*)"password", 8, k, 4, 1024, 8, 16, result, sizeof result);
	display(64);
	printf("Expected: FDBABE1C9D3472007856E7190D01E9FE7C6AD7CBC8237830E77376634B373162\n          2EAF30D92E22A3886FF109279D9830DAC727AFB94A83EE6D8360CBDFA2CC0640\n");

	return 0;
}
