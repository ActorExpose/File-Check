#define PRF_SHA256 -1
#define PRF_WHIRLPOOL 0
#define PRF_KECCAK 1

typedef void (*HASH_PROC)(void *in, unsigned long inlen, void *out, _Bool init, _Bool finalize);

void hmac(HASH_PROC hash, int hash_digestsize, int hash_blocksize, unsigned char *ipad, unsigned char *k, int lk, unsigned char *d, int ld, unsigned char *out);

int scrypt(int prf, void *passwd, unsigned int passwdlen, void *salt, unsigned int saltlen, unsigned long N, unsigned int r, unsigned int p, void *result, unsigned int resultlen);
// salt must be 4 byte free at its end, saltlen doesn't include these bytes