#if !defined _WIN64 && !defined __AVX__
#define AES_ENC_OPTI "-O3"
#define AES_DEC_OPTI "-O1"
#define SERPENT_ENC_OPTI "-O1"
#define SERPENT_DEC_OPTI "-O1"
#define SHACAL2_ENC_OPTI "-O2"
#define SHACAL2_DEC_OPTI "-O1"
#endif
#if !defined _WIN64 && defined __AVX__
#define AES_ENC_OPTI "-O3"
#define AES_DEC_OPTI "-O1"
#define SERPENT_ENC_OPTI "-O1"
#define SERPENT_DEC_OPTI "-O1"
#define SHACAL2_ENC_OPTI "-O1"
#define SHACAL2_DEC_OPTI "-O2"
#endif
#if defined _WIN64 && !defined __AVX__
#define AES_ENC_OPTI "-O2"
#define AES_DEC_OPTI "-O2"
#define SERPENT_ENC_OPTI "-O1"
#define SERPENT_DEC_OPTI "-O1"
#define SHACAL2_ENC_OPTI "-O1"
#define SHACAL2_DEC_OPTI "-O3"
#endif
#if defined _WIN64 && defined __AVX__
#define AES_ENC_OPTI "-O2"
#define AES_DEC_OPTI "-O3"
#define SERPENT_ENC_OPTI "-O1"
#define SERPENT_DEC_OPTI "-O1"
#define SHACAL2_ENC_OPTI "-O1"
#define SHACAL2_DEC_OPTI "-O1"
#endif
