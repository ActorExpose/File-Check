#include <intrin.h>

typedef struct {
	__m128i subkeys[33][4];
} serpent_key;

void serpent_init(serpent_key *key, void *init_key);
void serpent_encrypt(serpent_key *key, void *buffer);
void serpent_decrypt(serpent_key *key, void *buffer);
