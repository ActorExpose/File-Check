#include <intrin.h>
#include "serpent.h"
#include "..\config.h"

#define RND0(a, b, c, d, w, x, y, z) \
	x = b | c; \
	w = (a ^ b) & x; \
	z = (a | d) ^ b ^ c; \
	y = w ^ (d & (c | z)); \
	a ^= d; \
	w = ~(a ^ x ^ (w & y)); \
	x = c ^ d ^ w ^ (b & a)

#define InvRND0(a, b, c, d, w, x, y, z) \
	t1 = c ^ d; \
	z = b | c; \
	w = (a | b) ^ t1; \
	x = (z & (b ^ d)) ^ (a | (c & t1)); \
	y = ~w; \
	z ^= d | y; \
	t1 = x ^ (a | w); \
	w = a ^ c ^ (z | (w & t1)); \
	z ^= t1

#define RND1(a, b, c, d, w, x, y, z) \
	x = a | d; \
	y = c ^ d; \
	z = (x & y) ^ (b | (d & (a ^ c))); \
	w = a | ~b; \
	y ^= w; \
	x ^= (b & d) ^ y ^ z; \
	w = c ^ (w & (z | x)); \
	z = ~z

#define InvRND1(a, b, c, d, w, x, y, z) \
	t1 = a ^ b; \
	y = a & c; \
	z = c ^ (b | d); \
	w = t1 & (a | z); \
	x = (z | y) ^ (d & (b ^ w)); \
	y = ~((d | y) ^ w); \
	w ^= (a | y) ^ c ^ x; \
	z ^= t1

#define RND2(a, b, c, d, w, x, y, z) \
	y = a ^ b; \
	t1 = a | c; \
	z = d ^ t1; \
	w = y ^ z; \
	x = c ^ w; \
	z ^= b | x; \
	x = (y | z) ^ (t1 & (b ^ x)); \
	y = (a | d) ^ b ^ z ^ x; \
	z = ~z

#define InvRND2(a, b, c, d, w, x, y, z) \
	t1 = c ^ d; \
	w = a ^ d ^ (b | t1); \
	x = a | c; \
	y = ~d | (a & c); \
	z = (b & x) ^ y; \
	x = (x & t1) ^ (b & (d | w)); \
	y ^= w ^ x ^ (c & z)

#define RND3(a, b, c, d, w, x, y, z) \
	y = b | (a & d); \
	z = c | (a & b); \
	t1 = a | d; \
	x = (a ^ c) & t1; \
	w = d ^ x; \
	x ^= y; \
	y = z ^ t1 ^ (d & y); \
	z ^= b ^ w; \
	w = (a | w) ^ (b & (d | z))

#define InvRND3(a, b, c, d, w, x, y, z) \
	t1 = c | d; \
	t2 = a | d; \
	y = c ^ t2; \
	z = a ^ d; \
	w = (b & t1) ^ y; \
	x = b ^ ((a ^ y) & (w | z)); \
	y = z ^ ((b ^ t2) & y); \
	z ^= t1 ^ (b | (a & y))

#define RND4(a, b, c, d, w, x, y, z) \
	t1 = a ^ (b | c); \
	x = d | t1; \
	w = d & (a | b); \
	z = t1 ^ w; \
	d ^= b; \
	y = z & d; \
	w = ~(c ^ w ^ (d & x)); \
	b &= c; \
	x = (a & x) ^ (b | (d ^ y)); \
	y ^= b | t1

#define InvRND4(a, b, c, d, w, x, y, z) \
	t1 = b | d; \
	t2 = a & t1; \
	z = b ^ (c | d); \
	b = a & z; \
	x = c ^ d ^ b; \
	y = x | ~t2; \
	w = a ^ z ^ y; \
	y ^= t1 ^ (c | (a ^ b)); \
	z ^= t2 ^ d

#define RND5(a, b, c, d, w, x, y, z) \
	t1 = b ^ d; \
	t2 = a & t1; \
	z = a ^ t1; \
	a = t2 ^ c ^ (b | d); \
	w = ~a; \
	y = d | w; \
	x = z ^ y; \
	y = (b | a) ^ (z | (d ^ y)); \
	z = (t2 | w) ^ t1 ^ (b | z)

#define InvRND5(a, b, c, d, w, x, y, z) \
	y = a & d; \
	z = c ^ y; \
	w = a ^ d ^ (b & z); \
	x = y ^ w ^ (b | (a & c)); \
	y = b ^ d ^ z ^ (w | x); \
	z ^= ~b | (a & w)

#define RND6(a, b, c, d, w, x, y, z) \
	w = a ^ d; \
	z = w & (b | c); \
	x = ~((a & d) ^ b ^ c); \
	y = ~((a | c) ^ z ^ (b & x)); \
	w = a ^ b ^ y ^ (x & w); \
	z ^= c ^ (b | d)

#define InvRND6(a, b, c, d, w, x, y, z) \
	t1 = a ^ c; \
	t2 = d | (b & t1); \
	y = ~c; \
	z = a & (b | y); \
	w = ~(z ^ t2); \
	x = b ^ d ^ (a | y); \
	y = (d | y) ^ t1 ^ (b & w); \
	z ^= a ^ x ^ (t1 & t2)

#define RND7(a, b, c, d, w, x, y, z) \
	t1 = a & c; \
	y = b | t1; \
	t2 = ~d; \
	z = (a & t2) ^ c ^ y; \
	w = a & b; \
	x = (d | w) ^ a ^ (c | z); \
	w ^= c ^ (t2 | (t1 ^ x)); \
	y = a ^ ((y & z) | (b ^ x))

#define InvRND7(a, b, c, d, w, x, y, z) \
	z = d & (a | b); \
	w = b ^ z; \
	y = a & b; \
	z ^= c | y; \
	x = a ^ (w | ~(d ^ z)); \
	w ^= c ^ (d | x); \
	y = (c & (a | d)) ^ (y | (b ^ d))

#define transform(x0, x1, x2, x3, y0, y1, y2, y3) \
	y0 = _mm_slli_epi32(x0, 13) | _mm_srli_epi32(x0, 32 - 13); \
	y2 = _mm_slli_epi32(x2, 3) | _mm_srli_epi32(x2, 32 - 3); \
	y1 = x1 ^ y0 ^ y2; \
	y1 = _mm_slli_epi32(y1, 1) | _mm_srli_epi32(y1, 32 - 1); \
	y3 = x3 ^ y2 ^ _mm_slli_epi32(y0, 3); \
	y3 = _mm_slli_epi32(y3, 7) | _mm_srli_epi32(y3, 32 - 7); \
	y0 ^= y1 ^ y3; \
	y0 = _mm_slli_epi32(y0, 5) | _mm_srli_epi32(y0, 32 - 5); \
	y2 ^= _mm_slli_epi32(y1, 7) ^ y3; \
	y2 = _mm_slli_epi32(y2, 22) | _mm_srli_epi32(y2, 32 - 22)

#define inv_transform(x0, x1, x2, x3, y0, y1, y2, y3) \
	y0 = (_mm_srli_epi32(x0, 5) | _mm_slli_epi32(x0, 32 - 5)) ^ x1 ^ x3; \
	y2 = (_mm_srli_epi32(x2, 22) | _mm_slli_epi32(x2, 32 - 22)) ^ _mm_slli_epi32(x1, 7) ^ x3; \
	y3 = (_mm_srli_epi32(x3, 7) | _mm_slli_epi32(x3, 32 - 7)) ^ _mm_slli_epi32(y0, 3) ^ y2; \
	y1 = (_mm_srli_epi32(x1, 1) | _mm_slli_epi32(x1, 32 - 1)) ^ y0 ^ y2; \
	y2 = _mm_srli_epi32(y2, 3) | _mm_slli_epi32(y2, 32 - 3); \
	y0 = _mm_srli_epi32(y0, 13) | _mm_slli_epi32(y0, 32 - 13)

#define keying(x0, x1, x2, x3, subkey) x0 ^= subkey[0]; x1 ^= subkey[1]; x2 ^= subkey[2]; x3 ^= subkey[3]

void serpent_init(serpent_key *key, void *key_init)
{
	unsigned long k[132 * 2], *w = &k[132];
	unsigned long t1, t2;
	int i, j;
	__m128i *subkeys = key->subkeys[0];

	memcpy(w, key_init, 32);
	for (i = 0; i < 132; i++) {
		j = i;
		if (i >= 8) j -= 8;
		w[j + 8] = w[i] = _rotl(w[j] ^ w[j + 3] ^ w[j + 5] ^ w[j + 7] ^ 0x9e3779b9 ^ i, 11);
	}

	for (i = 0;; i += 32) {
		RND3(w[i +  0], w[i +  1], w[i +  2], w[i +  3], k[i +  0], k[i +  1], k[i +  2], k[i +  3]);
		if (i == 128) break;
		RND2(w[i +  4], w[i +  5], w[i +  6], w[i +  7], k[i +  4], k[i +  5], k[i +  6], k[i +  7]);
		RND1(w[i +  8], w[i +  9], w[i + 10], w[i + 11], k[i +  8], k[i +  9], k[i + 10], k[i + 11]);
		RND0(w[i + 12], w[i + 13], w[i + 14], w[i + 15], k[i + 12], k[i + 13], k[i + 14], k[i + 15]);
		RND7(w[i + 16], w[i + 17], w[i + 18], w[i + 19], k[i + 16], k[i + 17], k[i + 18], k[i + 19]);
		RND6(w[i + 20], w[i + 21], w[i + 22], w[i + 23], k[i + 20], k[i + 21], k[i + 22], k[i + 23]);
		RND5(w[i + 24], w[i + 25], w[i + 26], w[i + 27], k[i + 24], k[i + 25], k[i + 26], k[i + 27]);
		RND4(w[i + 28], w[i + 29], w[i + 30], w[i + 31], k[i + 28], k[i + 29], k[i + 30], k[i + 31]);
	}

	for (i = 0; i < 33 * 4; i++)
		subkeys[i] = _mm_set1_epi32(k[i]);

	t1 = t2 = 0;
	__stosb((unsigned char*)k, 0, sizeof k);
}

__attribute__((optimize(SERPENT_ENC_OPTI)))
void serpent_encrypt(serpent_key *key, void *buffer)
{
	__m128i x0, x1, x2, x3;
	__m128i y0, y1, y2, y3;
	__m128i t1, t2;
	int i;

	y0 = ((__m128i*)buffer)[0]; 
	y1 = ((__m128i*)buffer)[1];
	y2 = ((__m128i*)buffer)[2];
	y3 = ((__m128i*)buffer)[3];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	x0 = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	x1 = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	x2 = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	x3 = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));

	for (i = 0;; i += 8) {
		keying(x0, x1, x2, x3, key->subkeys[i + 0]);
		RND0(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 1]);
		RND1(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 2]);
		RND2(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 3]);
		RND3(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 4]);
		RND4(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 5]);
		RND5(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 6]);
		RND6(x0, x1, x2, x3, y0, y1, y2, y3);
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
		keying(x0, x1, x2, x3, key->subkeys[i + 7]);
		RND7(x0, x1, x2, x3, y0, y1, y2, y3);
		if (i == 24) break;
		transform(y0, y1, y2, y3, x0, x1, x2, x3);
	}
	keying(y0, y1, y2, y3, key->subkeys[32]);

	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	((__m128*)buffer)[0] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[1] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	((__m128*)buffer)[2] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[3] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
}

__attribute__((optimize(SERPENT_DEC_OPTI)))
void serpent_decrypt(serpent_key *key, void *buffer)
{
	__m128i x0, x1, x2, x3;
	__m128i y0, y1, y2, y3;
	__m128i t1, t2;
	int i;

	y0 = ((__m128i*)buffer)[0]; 
	y1 = ((__m128i*)buffer)[1];
	y2 = ((__m128i*)buffer)[2];
	y3 = ((__m128i*)buffer)[3];
	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	x0 = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	x1 = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	x2 = _mm_castps_si128(_mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2)));
	x3 = _mm_castps_si128(_mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1)));

	keying(x0, x1, x2, x3, key->subkeys[32]);
	for (i = 31;; i -= 8) {
		InvRND7(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 0]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND6(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 1]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND5(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 2]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND4(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 3]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND3(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 4]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND2(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 5]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND1(x0, x1, x2, x3, y0, y1, y2, y3);
		keying(y0, y1, y2, y3, key->subkeys[i - 6]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
		InvRND0(x0, x1, x2, x3, y0, y1, y2, y3);
		if (i == 7) break;
		keying(y0, y1, y2, y3, key->subkeys[i - 7]);
		inv_transform(y0, y1, y2, y3, x0, x1, x2, x3);
	}
	keying(y0, y1, y2, y3, key->subkeys[ 0]);

	t1 = _mm_unpacklo_epi32(y0, y1);
	t2 = _mm_unpacklo_epi32(y2, y3);
	((__m128*)buffer)[0] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[1] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
	t1 = _mm_unpackhi_epi32(y0, y1);
	t2 = _mm_unpackhi_epi32(y2, y3);
	((__m128*)buffer)[2] = _mm_movelh_ps(_mm_castsi128_ps(t1), _mm_castsi128_ps(t2));
	((__m128*)buffer)[3] = _mm_movehl_ps(_mm_castsi128_ps(t2), _mm_castsi128_ps(t1));
}
