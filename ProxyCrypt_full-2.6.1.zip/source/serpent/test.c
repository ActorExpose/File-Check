#include <string.h>
#include <stdio.h>
#include "serpent.h"

char *convert_to_string(int len, unsigned char *val, char *str)
{
	int i;
	char *strptr = str;

	for (i = len / 8 - 1; i >= 0; i--) {
		sprintf(strptr, "%02X", val[i]);
		strptr += 2;
	}
	return str;
}

int main(int argc, char *argv[])
{
	unsigned char x[64] = {};
	unsigned char key_init[32] = {};
	serpent_key key;
	char tmpstr[80];
	__int64 t;
	int i;

	key_init[31] = 0x80;
	serpent_init(&key, key_init);
	printf("-test 1-\n");
	printf("Plaintext            = %s\n", convert_to_string(128, x, tmpstr));
	printf("Key                  = %s\n", convert_to_string(256, key_init, tmpstr));
	serpent_encrypt(&key, x);
	printf("Ciphertext           = %s\nExpected             = ABED96E766BF28CBC0EBD21A82EF0819\n", convert_to_string(128, x, tmpstr));
	serpent_decrypt(&key, x);
	printf("Decrypted-plaintext  = %s\n", convert_to_string(128, x, tmpstr));

	key_init[31] = 0; key_init[0] = 0x40;
	serpent_init(&key, key_init);
	printf("-test 2-\n");
	printf("Plaintext            = %s\n", convert_to_string(128, x + 16, tmpstr));
	printf("Key                  = %s\n", convert_to_string(256, key_init, tmpstr));
	serpent_encrypt(&key, x);
	printf("Ciphertext           = %s\nExpected             = 5991506D96F9F27DFF74015705D4E1EA\n", convert_to_string(128, x + 16, tmpstr));
	serpent_decrypt(&key, x);
	printf("Decrypted-plaintext  = %s\n", convert_to_string(128, x + 16, tmpstr));

	x[6 + 32] = 0x08; x[15 + 48] = 0x02;
	key_init[0] = 0;
	serpent_init(&key, key_init);
	printf("-test 3-\n");
	printf("Plaintext 1          = %s\n", convert_to_string(128, x + 32, tmpstr));
	printf("Plaintext 2          = %s\n", convert_to_string(128, x + 48, tmpstr));
	printf("Key                  = %s\n", convert_to_string(256, key_init, tmpstr));
	serpent_encrypt(&key, x);
	printf("Ciphertext 1         = %s\nExpected 1           = FF5A2A042BF19F4AD8F63C32A50B3059\n", convert_to_string(128, x + 32, tmpstr));
	printf("Ciphertext 2         = %s\nExpected 2           = 0A3E7E267FBEF117CE63FCB3F0092CBC\n", convert_to_string(128, x + 48, tmpstr));
	serpent_decrypt(&key, x);
	printf("Decrypted-plaintext 1= %s\n", convert_to_string(128, x + 32, tmpstr));
	printf("Decrypted-plaintext 2= %s\n", convert_to_string(128, x + 48, tmpstr));

	t = _rdtsc();
	for (i = 0; i < 1000000; i++)
		serpent_decrypt(&key, x);
	printf("\ntime = %I64d\n", _rdtsc() - t);

	return 0;
}
