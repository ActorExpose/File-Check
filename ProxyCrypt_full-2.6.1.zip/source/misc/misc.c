#include <windows.h>
#include <winternl.h>
#include <ntstatus.h>
#include <stdio.h>
#include <conio.h>
#include <intrin.h>
#include "..\scrypt\scrypt.h"
#include "misc.h"

#define RtlGenRandom SystemFunction036
__declspec(dllimport) BOOLEAN __stdcall RtlGenRandom(PVOID RandomBuffer, ULONG RandomBufferLength);
NTSYSCALLAPI NTSTATUS NTAPI NtQueryPerformanceCounter(_Out_ PLARGE_INTEGER PerformanceCounter, _Out_opt_ PLARGE_INTEGER PerformanceFrequency);
NTSYSCALLAPI NTSTATUS NTAPI NtCreateSemaphore(OUT PHANDLE SemaphoreHandle, IN ACCESS_MASK DesiredAccess, IN POBJECT_ATTRIBUTES ObjectAttributes OPTIONAL, IN ULONG InitialCount, IN ULONG MaximumCount);
NTSYSCALLAPI NTSTATUS NTAPI NtReleaseSemaphore(IN HANDLE SemaphoreHandle, IN ULONG ReleaseCount, OUT PULONG PreviousCount OPTIONAL);

extern _Bool show_pass, pass_alternate;
static BYTE *key_status;
static char *key_ok;
static DWORD main_thread_id;
static HANDLE hConsole, console_window;
static CONSOLE_SCREEN_BUFFER_INFO console_info;
static CONSOLE_CURSOR_INFO cursor;
static DWORD cursor_size;
static WCHAR *password, *out_pass, *msg_buf;
static HANDLE sema, h_mutex = NULL;
static unsigned int count_new, count_ok;


void lock_large_buf(void *buf, SIZE_T size, _Bool release)
{
	HANDLE current_process = GetCurrentProcess();
	SIZE_T min_working_set, max_working_set, size2;

	if (!h_mutex) h_mutex = CreateMutex(NULL, FALSE, NULL);
	NtWaitForSingleObject(h_mutex, FALSE, NULL);

	if (release) VirtualFree(buf, 0, MEM_RELEASE);
	GetProcessWorkingSetSize(current_process, &min_working_set, &max_working_set);

	if (release) {
		min_working_set -= size;
		max_working_set -= size;
	} else {
		size2 = size + (size >> 8);
		min_working_set += size2;
		max_working_set += size2;
	}

	if (!SetProcessWorkingSetSize(current_process, min_working_set, max_working_set))
		fprintf(stderr, "Warning: cannot %s working set size (%u).\n", release ? "reduce" : "increase", (unsigned int)GetLastError());
	else if (!release && !VirtualLock(buf, size))
		fprintf(stderr, "Warning: cannot lock large buffer into physical memory. (%u)\n", (unsigned int)GetLastError());

	ReleaseMutex(h_mutex);
}


int rand_gen(unsigned char *buf, int size, int prf, unsigned int scrypt_r, unsigned int scrypt_p)
{
	unsigned char *pool;
	struct {__int64 rdtsc; POINT curs_pos; LARGE_INTEGER perf; DWORD thread_id; DWORD tick;} entropy;
	int i;

	pool = VirtualAlloc(NULL, size + 4, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);

	if (!RtlGenRandom(pool, size)) {
		fprintf(stderr, "RtlGenRandom() failed.\n");
		return 1;
	}
	entropy.rdtsc = _rdtsc();
	GetCursorPos(&entropy.curs_pos);
	NtQueryPerformanceCounter(&entropy.perf, NULL);
	entropy.thread_id = GetCurrentThreadId();
	entropy.tick = GetTickCount();

	for (i = 0; i < sizeof(entropy) / sizeof(int); i++)
		((int*)pool)[i] += ((int*)&entropy)[i];

	i = size / 2;
	if (scrypt(prf, pool, i, pool + i, i, 32768, scrypt_r, scrypt_p, buf, size)) return 1;

	SecureZeroMemory(pool, size + 4);
	VirtualFree(pool, 0, MEM_RELEASE);

	return 0;
}


static LRESULT __stdcall LowLevelKeyboardProc(int code, WPARAM wParam, LPARAM lParam)
{
	int i_new_msg, new_char = 0;
	DWORD vk_code = ((KBDLLHOOKSTRUCT*)lParam)->vkCode;

	switch (wParam) {
		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
			key_status[vk_code] |= 0x80;
			switch (vk_code) {
				case VK_LSHIFT: case VK_RSHIFT:
					key_status[VK_SHIFT] |= 0x80;
					break;
				case VK_LCONTROL: case VK_RCONTROL:
					key_status[VK_CONTROL] |= 0x80;
					break;
				case VK_LMENU: case VK_RMENU:
					key_status[VK_MENU] |= 0x80;
					break;
				case VK_CAPITAL: case VK_NUMLOCK: case VK_SCROLL:
					key_status[vk_code] ^= 0x01;
			}
			if (console_window != GetForegroundWindow() || (vk_code == VK_TAB && ((key_status[VK_CONTROL] | key_status[VK_MENU]) & 0x80))) {
				key_ok[vk_code] = 0;
				break;
			}
			if (count_new - count_ok > 512 - 66) {
				key_ok[vk_code] = 1;
				break;
			}
			i_new_msg = count_new & 511;
			// msg_buf: [virtual key code][number of characters][characters]
			msg_buf[i_new_msg++] = vk_code;
			new_char = ToUnicode(vk_code, ((KBDLLHOOKSTRUCT*)lParam)->scanCode, key_status, &msg_buf[i_new_msg + 1], 64, 0);
			key_ok[vk_code] = new_char;
			count_new += (msg_buf[i_new_msg] = max(new_char, 0)) + 2;
			NtReleaseSemaphore(sema, 1, NULL);
			break;

		case WM_KEYUP:
		case WM_SYSKEYUP:
			key_status[vk_code] &= 0x7f;
			switch (vk_code) {
				case VK_LSHIFT: case VK_RSHIFT:
					key_status[VK_SHIFT] &= 0x7f;
					break;
				case VK_LCONTROL: case VK_RCONTROL:
					key_status[VK_CONTROL] &= 0x7f;
					break;
				case VK_LMENU: case VK_RMENU:
					key_status[VK_MENU] &= 0x7f;
			}
	}

	return key_ok[vk_code] ? TRUE : CallNextHookEx(NULL, code, wParam, lParam);
}

static void disp_pass(int i)
{
	CONSOLE_SCREEN_BUFFER_INFO curs_pos;
	DWORD c_written;
	WCHAR c_tmp;
	int j;

	for (j = 0; password[j]; j++) out_pass[j] = show_pass ? password[j] : '*';
	*(unsigned int*)(out_pass + j) = (' ' << 16) + ' ';
	j += 2;
	out_pass[j] = 0;

	WriteConsoleOutputCharacter(hConsole, out_pass, j, console_info.dwCursorPosition, &c_written);
	if (c_written < j) {
		SetConsoleCursorPosition(hConsole, console_info.dwCursorPosition);
		_cwprintf(L"%s", out_pass);
		console_info.dwCursorPosition.Y--;
	}

	c_tmp = out_pass[i];
	out_pass[i] = 0;
	SetConsoleCursorPosition(hConsole, console_info.dwCursorPosition);
	_cwprintf(L"%s", out_pass);
	out_pass[i] = c_tmp;
	SetConsoleCursorInfo(hConsole, &cursor);
	// prevent cursor disappearance with left and right keys
	GetConsoleScreenBufferInfo(hConsole, &curs_pos);
	SetConsoleCursorPosition(hConsole, curs_pos.dwCursorPosition);
}

static DWORD __stdcall pass_thread(LPVOID lpParam)
{
	BYTE insert = TRUE;
	WCHAR keycode = 0, i_msg_inc;
	DWORD result;
	HANDLE h_input[2];
	INPUT_RECORD ir;
	int i, j, n, i_msg, new_char;

	h_input[0] = sema;
	h_input[1] = GetStdHandle(STD_INPUT_HANDLE);
	GetConsoleScreenBufferInfo(hConsole, &console_info);
	i = n = 0;
	do {
		if (WaitForMultipleObjects(2, h_input, FALSE, INFINITE) == WAIT_OBJECT_0 + 1) {
			ReadConsoleInput(h_input[1], &ir, 1, &result);
			continue;
		}
		i_msg = count_ok & 511;
		keycode = msg_buf[i_msg++];
		count_ok += (i_msg_inc = msg_buf[i_msg++]) + 2;
		switch (keycode) {
			case VK_RETURN: case VK_ESCAPE:
				show_pass = TRUE;
				cursor.dwSize = cursor_size;
			case VK_TAB:
				show_pass = !show_pass;
				FillConsoleOutputCharacter(hConsole, ' ', -1, console_info.dwCursorPosition, &result);
				break;
			case VK_BACK:
				if (i) {
					for (j = i; j < n; j++) password[j - 1] = password[j];
					password[--n] = 0;
					i--;
				}
				break;
			case VK_LEFT:
				if (i) i--;
				break;
			case VK_RIGHT:
				if (i < n) i++;
				break;
			case VK_INSERT:
				cursor.dwSize = (insert = !insert) ? cursor_size : 100;
				break;
			case VK_DELETE:
				for (j = i; j < n; j++) password[j] = password[j + 1];
				if (i < n) n--;
				break;
			case VK_HOME:
				i = 0;
				break;
			case VK_END:
				i = n;
				break;
			default:
				if (insert) {
					new_char = min(i_msg_inc, 250 - n);
					for (j = n - 1; j >= i; j--) password[j + new_char] = password[j];
					n += new_char;
				} else {
					new_char = min(i_msg_inc, 250 - i);
					if (i + new_char > n) n = i + new_char;
				}
				for (j = 0; j < new_char; j++) password[i++] = msg_buf[i_msg + j];
		}
		disp_pass(i);
	} while (keycode != VK_RETURN && keycode != VK_ESCAPE);

	_cwprintf(L"%s", out_pass + i);
	PostThreadMessage(main_thread_id, WM_APP, keycode, 0);

	return 0;
}

int password_edit(WCHAR *pass_buf) {
	HHOOK hook;
	MSG msg;
	HKEY reg_key;
	_Bool insert = TRUE;
	WCHAR c, prev_c = 0, c_overwritten = 0;
	DWORD prev_time = 0, n, c_written, console_mode;
	BOOL mode_ok;
	HANDLE hConsole_in;
	int i, j;

	password = pass_buf;
	out_pass = pass_buf + 256;
	key_status = (BYTE*)(pass_buf + 512);
	key_ok = (char*)(pass_buf + 768);
	msg_buf = pass_buf + 1024;
	ZeroMemory(pass_buf, 2048);
	hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	GetConsoleCursorInfo(hConsole, &cursor);
	if (RegOpenKeyExA(HKEY_CURRENT_USER, "Console", 0, KEY_QUERY_VALUE, &reg_key) == ERROR_SUCCESS) {
		n = sizeof cursor.dwSize;
		RegQueryValueExA(reg_key, "CursorSize", NULL, NULL, (void*)&cursor.dwSize, &n);
		RegCloseKey(reg_key);
		SetConsoleCursorInfo(hConsole, &cursor);
	}
	cursor_size = cursor.dwSize;

	if (!pass_alternate) {
		count_new = count_ok = 0;
		console_window = GetConsoleWindow();
		main_thread_id = GetCurrentThreadId();
		GetKeyState(0);
		GetKeyboardState(key_status);
		if (NtCreateSemaphore(&sema, SEMAPHORE_ALL_ACCESS, NULL, 0, 1000) != STATUS_SUCCESS)
			fprintf(stderr, "NtCreateSemaphore() failed.\n");
		else if (!(hook = SetWindowsHookEx(WH_KEYBOARD_LL, LowLevelKeyboardProc, GetModuleHandle(NULL), 0)))
			fprintf(stderr, "SetWindowsHookEx() failed.\n");
		else {
			hConsole_in = GetStdHandle(STD_INPUT_HANDLE);
			if ((mode_ok = GetConsoleMode(hConsole_in, &console_mode)))
				SetConsoleMode(hConsole_in, console_mode & ~ENABLE_QUICK_EDIT_MODE);
			CreateThread(NULL, 0, pass_thread, NULL, 0, NULL);
			GetMessage(&msg, NULL, 0, 0);
			UnhookWindowsHookEx(hook);
			NtClose(sema);
			if (mode_ok) SetConsoleMode(hConsole_in, console_mode);
			if (msg.wParam == VK_ESCAPE) {
				_putch('\n');
				return TRUE;
			}
			if (password[0]) {
				_putch('\n');
				return FALSE;
			}
		}
		_cprintf("\rAlternate input method activated.\n");
		pass_alternate = TRUE;
	}

	GetConsoleScreenBufferInfo(hConsole, &console_info);
	i = n = 0;
	do {
		c = _getwch();
		if (c == '\r' || c == 27) {
			show_pass = FALSE;
			FillConsoleOutputCharacter(hConsole, ' ', -1, console_info.dwCursorPosition, &c_written);
			cursor.dwSize = cursor_size;
		}
		else if (!c) {
			_getwch();
			continue;
		}
		else if (c == '\t') {
			show_pass = !show_pass;
			FillConsoleOutputCharacter(hConsole, ' ', -1, console_info.dwCursorPosition, &c_written);
		}
		else if (c == '\b') {
			if (i) {
				for (j = i; j < n; j++) password[j - 1] = password[j];
				password[--n] = 0;
				i--;
			}
		}
		else if (prev_c == 224 && c != 224 && GetTickCount() - prev_time < 100) {
			if (n < 250) {
				if (insert) {
					for (j = --i; j < n; j++) password[j] = password[j + 1];
					n--;
				} else {
					if (!c_overwritten) n--;
					password[--i] = c_overwritten;
				}
			}
			switch (c) {
				case 75: // backward
					if (i) i--;
					break;
				case 77: // forward
					if (i < n) i++;
					break;
				case 82: // insert
					cursor.dwSize = (insert = !insert) ? cursor_size : 100;
					break;
				case 83: // delete
					for (j = i; j < n; j++) password[j] = password[j + 1];
					if (i < n) n--;
					break;
				case 71: // home
					i = 0;
					break;
				case 79: // end
					i = n;
			}
		} else if (n < 250) {
			if (insert) {
				for (j = n; j > i; j--) password[j] = password[j - 1];
				n++;
			} else {
				c_overwritten = password[i];
				if (i == n) n++;
			}
			password[i++] = c;
		}
		disp_pass(i);
		prev_c = c;
		prev_time = GetTickCount();
	} while (c != '\r' && c != 27);

	_cwprintf(L"%s\n", out_pass + i);

	return c == 27;
}
