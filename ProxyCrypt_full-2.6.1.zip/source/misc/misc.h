void lock_large_buf(void *buf, SIZE_T size, _Bool release);

int rand_gen(unsigned char *buf, int size, int prf, unsigned int scrypt_r, unsigned int scrypt_p);

int password_edit(WCHAR *pass_buf);
