#include <stdio.h>
#include <intrin.h>
#include "keccak.h"

static unsigned char hash[64];
static unsigned char data1[1] = {0xCC};
static unsigned char data2[7] = {0x11, 0x97, 0x13, 0xCC, 0x83, 0xEE, 0xEF};

void display()
{
	int i;

	printf("Hash:     ");
	for (i = 0; i < 64; i++) {
		if (i == 32) printf("\n          ");
		printf("%02X", hash[i]);
	}
}

int main()
{
	__int64 time;
	int i;

	keccak_ini();

	printf("-test 1-\n");
	keccak(NULL, 0, hash, 1, 1);
	display();
	printf("\nExpected: 0EAB42DE4C3CEB9235FC91ACFFE746B29C29A8C366B7C60E4E67C466F36A4304\n          C00FA9CAF9D87976BA469BCBE06713B435F091EF2769FB160CDAB33D3670680E\n\n");

	printf("-test 2-\n");
	keccak(data1, sizeof data1, hash, 1, 1);
	display();
	printf("\nExpected: 8630C13CBD066EA74BBE7FE468FEC1DEE10EDC1254FB4C1B7C5FD69B646E4416\n          0B8CE01D05A0908CA790DFB080F4B513BC3B6225ECE7A810371441A5AC666EB9\n\n");

	printf("-test 3-\n");
	keccak(data2, sizeof data2, hash, 1, 1);
	display();
	printf("\nExpected: D1116786A3C1EA46A8F22D82ABB4C5D06DC0691B2E747AC9726D0B290E6959F7\n          B23428519A656B237695E56403855EC4C98DB0CF87F31B6CEABF2B9B8589B713\n\n");

	time = _rdtsc();
	for (i = 0; i < 200000; i++)
		keccak(data2, sizeof data2, hash, 1, 1);
	time = _rdtsc() - time;
	printf("time: %I64u\n", time);

	return 0;
}
