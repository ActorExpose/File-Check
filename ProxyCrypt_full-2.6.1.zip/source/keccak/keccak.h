#define KECCAK_DIGESTSIZE 64
#define KECCAK_BLOCKSIZE 72

void keccak_ini();
void keccak(void *in, unsigned long inlen, void *out, _Bool init, _Bool finalize);
