#include <string.h>
#include "keccak.h"

#define ROL(x, n) (((x) << (n)) ^ ((x) >> (32 - (n))))

unsigned int RoundConstants[22] = {
	0x00000001, 0x00008082, 0x0000808a, 0x80008000, 0x0000808b, 0x80000001, 0x80008081, 0x00008009, 0x0000008a, 0x00000088, 0x80008009,
	0x8000000a, 0x8000808b, 0x0000008b, 0x00008089, 0x00008003, 0x00008002, 0x00000080, 0x0000800a, 0x8000000a, 0x80008081, 0x00008080
};
unsigned int RotationConstants[25] = {1, 3, 6, 10, 15, 21, 28, 36 % 32, 45 % 32, 55 % 32, 2, 14, 27, 41 % 32, 56 % 32, 8, 25, 43 % 32, 62 % 32, 18, 39 % 32, 61 % 32, 20, 44 % 32};
unsigned int PiLane[25] = {10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1};
unsigned int Mod5[10] = {0, 1, 2, 3, 4, 0, 1, 2, 3, 4};

void KeccakF(unsigned int *state, unsigned int *in)
{
	unsigned int x, y, temp;
	unsigned int BC[5];
	int laneCount;

	for (x = 0; x < 16; x++)
		state[x] ^= in[x];

	for (laneCount = 0; laneCount < 22; laneCount++) {
		for (x = 0; x < 5; x++)
			BC[x] = state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20];

		for (x = 0; x < 5; x++) {
			temp = BC[Mod5[x + 4]] ^ ROL(BC[Mod5[x + 1]], 1);
			for (y = 0; y < 25; y += 5)
				state[x + y] ^= temp;
		}

		temp = state[1];
		for (x = 0; x < 24; x++) {
			BC[0] = state[PiLane[x]];
			state[PiLane[x]] = ROL(temp, RotationConstants[x]);
			temp = BC[0];
		}

		for (y = 0; y < 25; y += 5) {
			BC[0] = state[y];
			BC[1] = state[y + 1];
			BC[2] = state[y + 2];
			BC[3] = state[y + 3];
			BC[4] = state[y + 4];
			for (x = 0; x < 5; x++)
				state[x + y] = BC[x] ^ (~BC[Mod5[x + 1]] & BC[Mod5[x + 2]]);
		}

		state[0] ^= RoundConstants[laneCount];
	}
}

void crypto_hash(void *in, unsigned long inlen, void *out, unsigned char init, unsigned char finalize)
{
	unsigned int state[25];

	memset(state, 0, sizeof state);

	while (inlen >= 64) {
		KeccakF(state, in);
		inlen -= 64;
		in += 64;
	}

	memcpy(out, in, inlen);
	out[inlen++] = 1;
	memset(out + inlen, 0, 64 - inlen);
	out[63] |= 0x80;
	KeccakF(state, out);

	memcpy(out, state, 64);
}
