#include <intrin.h>

#define ROL(x, n) (((x) << (n)) ^ ((x) >> (64 - (n))))

static unsigned long long state[25 + 10];

static unsigned long long RoundConstants[24] = {};
static unsigned char RotationConstants[24] = {1, 3, 6, 10, 15, 21, 28, 36, 45, 55, 2, 14, 27, 41, 56, 8, 25, 43, 62, 18, 39, 61, 20, 44};
static unsigned char PiLane[24] = {10, 7, 11, 17, 18, 3, 5, 16, 8, 21, 24, 4, 15, 23, 19, 13, 12, 2, 20, 14, 22, 9, 6, 1};

void keccak_ini()
{
	unsigned short c = 1;
	int i, j;

	for (i = 0; i < 24; i++)
		for (j = 0; j < 7; j++) {
			if (c & 1) RoundConstants[i] |= 1ULL << ((1 << j) - 1);
			if ((c <<= 1) & 0x100) c ^= 0x71;
		}
}

static void KeccakF(unsigned long long *in)
{
	unsigned int laneCount, x;
	unsigned long long temp, prev_state, temp2;
	unsigned long long *BC = &state[25];

	for (x = 0; x < 9; x++)
		state[x] ^= in[x];

	for (laneCount = 0; laneCount < 24; laneCount++) {
		for (x = 0; x < 5; x++)
			BC[x + 5] = BC[x] = state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20];

		for (x = 0; x < 5; x++) {
			temp = BC[x + 4] ^ ROL(BC[x + 1], 1);
			state[x + 0] ^= temp;
			state[x + 5] ^= temp;
			state[x + 10] ^= temp;
			state[x + 15] ^= temp;
			state[x + 20] ^= temp;
		}

		prev_state = state[1];
		for (x = 0; x < 24; x++) {
			temp = state[PiLane[x]];
			state[PiLane[x]] = ROL(prev_state, RotationConstants[x]);
			prev_state = temp;
		}

		for (x = 0; x < 25; x += 5) {
			temp = state[x];
			temp2 = state[x + 1];
			_mm_storeu_si128((__m128i*)&state[x + 0], _mm_loadu_si128((__m128i*)&state[x + 0]) ^ _mm_andnot_si128(_mm_loadu_si128((__m128i*)&state[x + 1]), _mm_loadu_si128((__m128i*)&state[x + 2])));
			_mm_storeu_si128((__m128i*)&state[x + 2], _mm_loadu_si128((__m128i*)&state[x + 2]) ^ _mm_andnot_si128(_mm_loadu_si128((__m128i*)&state[x + 3]), _mm_set_epi64x(temp, state[x + 4])));
			state[x + 4] ^= ~temp & temp2;
		}

		state[0] ^= RoundConstants[laneCount];
	}
}

void keccak(void *in, unsigned long inlen, void *out, _Bool init, _Bool finalize)
{
	unsigned char temp[72];

	if (init)
		memset(state, 0, sizeof state);

	while (inlen >= 72) {
		KeccakF(in);
		inlen -= 72;
		in += 72;
	}

	if (finalize) {
		memcpy(temp, in, inlen);
		temp[inlen++] = 1;
		memset(temp + inlen, 0, 72 - inlen);
		temp[71] |= 0x80;
		KeccakF((unsigned long long*)temp);
		memcpy(out, state, 64);
		__stosb(temp, 0, sizeof temp);
		__stosb((unsigned char*)state, 0, sizeof state);
	}
}
