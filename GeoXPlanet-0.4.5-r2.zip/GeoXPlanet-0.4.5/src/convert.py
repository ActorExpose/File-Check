###############################################################################
## convert class
##
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This class file contains various functions needed for converting
## hex ip addresses and port numbers (such as /proc/net/tcp)
## into decimal format
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.3
#		General optimizations - rocket357
#
# Version 0.1
#		Initial Release - rocket357
#

class convert:
		
	hexChars=['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F']
	
	def ipEncode(self,ipString):
		"""convert.ipEncode(ipString)
		
		This function accepts an ipv4 string (i.e. 192.168.0.1) and 
		encodes it in the format used by the MaxMind GeoCityLite 
		database."""
		encodedIP = 0
		multiplier = 3
		for octet in ipString.split('.'):
			place = 0
			octetValue = 0
			for digit in octet[::-1]:
				octetValue += self.hexChars.index(digit)*(10**place)
				place += 1
			encodedIP += (256**multiplier)*octetValue
			multiplier -= 1
		return encodedIP
		
	def ipDecode(self,ipHex):
		"""convert.ipDecode(ipHex)
		
		This function accepts a /proc/net/tcp format ip address (hex) 
		and converts it to decimal notation.  It calls the helper function hexDecode."""
		ipString = ''
		for octet in range(8,0,-2):
			ipString = ipString + '.' + self.hexDecode(ipHex[octet-2:octet])
		return ipString.lstrip('.')
	
	def hexDecode(self,input):
		"""convert.hexDecode(input)
		
		This function converts arbitrary length hexidecimal numbers to 
		decimal format."""
		multiplier = len(input) - 1
		total = 0
		for char in input:
			base = 16 ** multiplier
			total = total + (self.hexChars.index(char) * base)
			multiplier = multiplier - 1
		return "%s" % total