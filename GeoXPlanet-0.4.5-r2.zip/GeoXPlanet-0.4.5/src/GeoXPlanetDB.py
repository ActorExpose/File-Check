###############################################################################
## GeoDatabase.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This class handles database abstraction for the GeoXPlanet project.  
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.3.5
#		Modified print statements to make it match controller.py statements - rocket357
#
# Version 0.3
#		Removed pygresql as a potential database adaptor until later - rocket357
#
# Version 0.2
#		Modified to make use of GeoXPlanet.conf - rocket357
#
# Version 0.1
#		Initial Release - rocket357
#

import ConfigParser
import os, sys

class Database:
	db_type = ""
	connected = False
	dbmod = None
	conn = None
	cursor = None
	host = None
	name = None
	user = None
	passwd = None
	
	def __init__(self):
		"""Database.__init__()
		
		Initializes the Database class and configures the class to connect to the
		database of choice."""
		
		# first let's grab the config from the conf file
		config = ConfigParser.ConfigParser()
		fname = open(os.path.join(os.environ["HOME"],".geoxplanet","GeoXPlanet.conf"),"r")
		config.readfp(fname)
		fname.close()
		self.db_type = config.get("Database", "databaseType")
		self.host = config.get("Database","dbHost")
		self.name = config.get("Database","dbName")
		self.user = config.get("Database","dbUser")
		self.passwd = config.get("Database","dbPassword")
		
		adaptor = config.get("Database", "preferreddbmodule")
		
		try:
			#print "Entering try block"
			exec("import %s as dbmod" % adaptor)
			self.dbmod = dbmod
			#print "Exiting try block"
		except:
			return False
					
		print "	Attempting to connect to ",
		
		self.connected = self.connect(self.host, self.name, self.user, self.passwd)
		
		if self.connected:
			print "Success!"
		else:
			print "Connection failed!"
		
	def connect(self, host, dbname, user, password):
		"""Database.connect(host, dbname, user, password)
		
		Returns True if connection to the database is successful with supplied credentials.  
		Connection is persistent."""
		#try:
		print self.db_type + " database...",
		if self.db_type == 'PostgreSQL':
			self.conn = self.dbmod.connect("host=%s dbname=%s user=%s password=%s" % (self.host, self.name, self.user, self.passwd))
		elif self.db_type == 'MySQL':
			self.conn = self.dbmod.connect(host="%s" % self.host, user="%s" % self.user, passwd="%s" % self.passwd, db="%s" % self.name)
		elif self.db_type == 'SQLite3':
			self.conn = self.dbmod.connect(sys.path[0] + os.sep + self.name)
			self.conn.row_factory = self.dbmod.Row
			self.conn.text_factory = self.dbmod.OptimizedUnicode
		elif self.db_type == 'MSSQL':
			self.conn = self.dbmod.connect(host="%s" % self.host, user="%s" % self.user, password="%s" % self.passwd, database="%s" % self.name)
		#print self.conn
		self.cursor = self.conn.cursor()
		return True
		#except Exception, inst:
		#	print inst
		#	return False
	
	def lookup(self,encodedIP):
		"""Database.lookup(encodedIP)
		
		The main 'public' function of the Database class.  Takes the given encodedIP and
		pulls the lat/long records from the MaxMind database.  Returns the coords in list format."""
		try:
			if not self.cursor:
				print "Resetting cursor!"
				self.cursor = self.conn.cursor()
			self.cursor.execute("""
			SELECT l.latitude, l.longitude FROM IpBlocks b, IpLocations l
				WHERE l.locId = b.locId AND b.startIpNum <= %s AND b.endIpNum >= %s
				""" % (encodedIP, encodedIP))
			result = self.cursor.fetchall()
			#print "Result: %s" % result
			if len(result) > 0:
				return result[0] # Should only be one record
			else:
				return ['0','0']
		except Exception, inst:
			return ['0','0']

	def lookupSet(self,ipSet):
		"""Database.lookupSet(ipSet)
		
		The main 'public' function of the Database class.  Takes the given encodedIPSet and
		pulls the lat/long records from the MaxMind database.  Returns the coords in list format."""
		
		try:
			if self.cursor:
				# TODO!  Test this query against other databases
				self.cursor.execute("""
			SELECT l.latitude, l.longitude FROM IpBlocks b, IpLocations l
				WHERE l.locId = b.locId AND b.startIpNum <= %s AND b.endIpNum >= %s
				""" % (encodedIP, encodedIP))
				if self.cursor.rowcount > 0:
					result = self.cursor.fetchall()
					if result is not None:
						return result # Should only be one record
		except Exception, inst:
			return ['0','0']

	def isConnected(self):
		"""Database.isConnected()
		
		Returns True if connection to the database was successful"""
		if self.conn:
			return True
		else:
			return False