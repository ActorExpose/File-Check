###############################################################################
## hostlookup.py
## Author: FraGGod - original code
## Author: rocket357 - code refactoring for speed purposes
## rocket357@users.sourceforge.net
##
## This script contains code originally contributed by FraGGod.
##
## This script is intended to "fork off" hostname lookups in parallel to speed up execution.
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.4.5
#		Moved FraGGod's code to it's own thread for speed purposes - rocket357
#
# Version 0.4.4-r2
#		Idea & code contributed to project to have reverse DNS lookups - FraGGod
#

from threading import Thread
import os, re, sys, socket

class hostlookup(Thread):
	ipStr = ''
	running = False
	hostname = ''
	
	def __init__(self, ipStr):
		Thread.__init__(self)
		self.ipStr = ipStr
		
	def run(self):
		self.running = True
		try:
			self.hostname = socket.gethostbyaddr(self.ipStr)[0]
		except:
			self.hostname = self.ipStr
		self.running = False
		
	def getHostname(self):
		return self.hostname
		
	def isRunning(self):
		return self.running 