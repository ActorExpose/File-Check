###############################################################################
## trace.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This script is intended to generate arcs to map the traceroute from localhost to a given ip address.
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.3.7
#		Added to project - rocket357
#

from threading import Thread
import os, re, sys, socket

class Trace(Thread):
	useScapy = False
	ipRegex = None
	arcStr = ''
	ipStr = ''
	ipPort = ''
	running = False
	
	def __init__(self, ipStr, ipPort):
		Thread.__init__(self)
		self.arcStr = ''
		self.ipRegex = re.compile("([0-9]*\.[0-9]*\.[0-9]*\.[0-9]*)")
		self.ipStr = ipStr
		self.ipPort = int(ipPort)
		
	def run(self):
		self.running = True
		if sys.platform == 'win32' or sys.platform == 'Mic':
			result = os.popen("tracert %s" % self.ipStr)
		else:
			result = os.popen("traceroute %s 2>>/dev/null | grep \"([0-9]*.[0-9]*.[0-9]*.[0-9]*) \"" % self.ipStr)
		result = result.readlines()
		print "TRACE:  %s COMPLETE" % self.ipStr
		#print result
		for line in result:
			#print line
			ipMatch = self.ipRegex.search(line)
			if ipMatch is not None and ipMatch.group(1).split('.')[0] != '192':
				addy = ipMatch.group(1)
				#print "TRACE:  tracepoint %s found" % addy
				self.arcStr += "%s " % addy
		self.arcStr += "%s" % self.ipStr
		self.running = False
		
	def getList(self):
		return self.arcStr.split(' ')
		
	def isRunning(self):
		return self.running 