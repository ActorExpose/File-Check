###############################################################################
## controller.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This script is intended to generate an xearth/xplanet compatible "marker file"
## so xearth/xplanet can plot machines that the localhost machine is connected
## to.  
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.4.5
#		Forked FraGGod's code off into it's own thread for speed - rocket357
#		Brought some sanity to the file path stuff - rocket357
#
# Version 0.4.4-r2
#		Added reverse DNS lookups for hostname titles - FraGGod
#		Added projection radius value adjustment - FraGGod
#		Added more colors for some common ports - FraGGod
#
# Version 0.3.8
#		Added options to show nations, coasts, and states - rocket357
#		Added options to auto-generate the xplanet.conf file - rocket357
#		Added code from download_clouds.py ver. 1.1
#			(C) 2004 Michal Pasternak <michal@pasternak.w.lub.pl>
#			for downloading cloud files - rocket357
#
# Version 0.3.7
#		Added trace option (STILL EXPERIMENTAL!!) - rocket357
#		Restructured online lookups (threaded) - rocket357
#		Now pulling the GeoXPlanet dir via sys.path[0] - rocket357
#		Added DEBUG option - rocket357
#		Modified calls to ipRecord for new structure - rocket357
#
# Version 0.3.6
#		Optimized public ip lookup/online lat-long lookup - rocket357
#		Modified regex's for lat/long online lookups - rocket357
#		Error handling for homeLAT and homeLONG lookup - rocket357
#		Added trace function skeleton for future implementation - rocket357
#		Added sys.exit(1) for exceptions that occur in the main loop - rocket357
#		Added checks for Windows for future use - rocket357
#
# Version 0.3.5
#		Fixed a bug in localhost public ip lookup - rocket357
#		Restructured code for readability - rocket357
#		Put in print statements during init - rocket357
#		Coded section to handle launching XPlanet with -num_times 1 - rocket357
#		Added code to handle setting the background in kde/gnome/fluxbox - rocket357
#		Removed useless config file options - rocket357
#		Added check to run XPlanet only if connection list changed - rocket357
#
# Version 0.3.4
#		Added localhost public ip lookup - rocket357
#		Fixed bug that was causing GeoXPlanet to hang on non-gnome systems - rocket357
#		Added statement to inform user that GeoXPlanet is waiting for connections - rocket357
#		Added check to ensure xplanet isn't running already - rocket357
#		Added TODO's for Windows systems to track requirements - rocket357
#		Restructured into classfile for bytecode optimizations - rocket357
#
# Version 0.3.3
#		Added code to launch xplanet/xearth - rocket357
#		Added config option code for xplanet/xearth - rocket357
#		Added port-based color coding - rocket357
#
# Version 0.3.2
#		Added port titles - rocket357
#		Random colors working now - rocket357
#		arcs working now - rocket357
#
# Version 0.3
#		Added option to use netstat instead of /proc/net/tcp - rocket357
#		netstat code for *nix systems - infovein (Thanks!)
#		WinXP specific stuff - rocket357
#
# Version 0.2
#		Added GeoXPlanet.conf - rocket357
#
# Version 0.1
#		Initial Release - rocket357
#

###############################################################################
# IMPORT REQUIREMENTS
###############################################################################
import sys, os, re 			# system, operating system, and regular expressions
import urllib, time, copy	# URL grabbing library, time library for the sleep() call
from convert import convert 		# custom class for converting hex -> decimal -> MaxMind
from ipRecord import ipRecord 		# keeps track of connections!
from GeoXPlanetDB import Database	# DB access module
import ConfigParser			# For reading the config file
import traceback
#import socket # For reverse DNS lookups - code forked off into thread v.0.4.5 - rocket357
from onlineLookup import onlineLookup
from clouds import clouds as cloudClass
from hostlookup import hostlookup
if sys.platform == 'win32' or sys.platform == 'Mic':
	import ctypes

class GeoXPlanet:

	# BOOLEANS
	DEBUG = False
	useTrace = False
	dirtyList = True
	useNetstat = False
	useTitles = False
	useDatabase = False
	useColors = False
	useArcs = False
	useXEarth = False
	xplanetIsRunning = False
	waitWarning = True
	useScapy = False
	showNations = False
	showCoast = False
	showStates = False
	showClouds = False
	GUI = False
	xinerama = False
	traceTemp = False

	# NUMERIC VARIABLES
	delay = 0.0
	homeLAT= 0.0
	homeLONG= 0.0
	suffix = 0
	latitude = 0
	longitude = 0
	symbolsize = 0
	radius = 45
	numConnections = 0
	numDisplays = 0
	
	# FILENAMES/DIRECTORIES
	GeoXPlanetDir = ""
	Delimiter = ""
	connectionFileName = ""
	markerFileName = ""
	markerFileName_NoCities = ""
	outputFileName = ""
	xplanetConfigFile = ""
	xplanetExe = ''
	arcFileName = ""

	# OTHER STRINGS
	userDesktop = ""
	hostportRegex = ""
	latRegex = ""
	lonRegex = ""
	netstatCommand = ""
	projection = ""
	geometry = ""
	titleType = ""
	platform = ""
	defaultColor = ""
	homeName= ""
	geoipAddy = ""
	nationColor = ""
	coastColor = ""
	stateColor = ""
	
	#OBJECTS
	locationDict = {}
	locationCache = {}
	traceDict = {}
	traceCache = {}
	colorList = []
	displayDict = {}
	database = None
	traceroute = None
	converter = None
	lookup = None
	cloudChecker = None
	
	def __init__(self, configFile):
		
		config = ConfigParser.ConfigParser()
		fname = open(configFile,"r")
		config.readfp(fname)
		fname.close()
		
		self.xplanetExe = config.get("General", "xplanetExe")
		print "Location of xplanet executable: %s" % self.xplanetExe
		
		if config.get("General","DEBUG").strip() == 'True':
			self.DEBUG = True
		
		print "Detecting environment settings..."
		
		if self.DEBUG:
			print ""
			print "Environment Variables:"
			print ""
			for key in os.environ.keys():
				print "	%s:	%s" % (key, os.environ[key])
			print ""
			print ""
			
		print "	Detecting Operating System:       ",
		self.platform = sys.platform[:3]
		print sys.platform
		
		print "	Detecting Desktop Environment:    ",
		if self.platform != 'win' and self.platform != 'Mic':
			self.userDesktop = config.get("General","DESKTOP").strip()
			if self.userDesktop == 'fluxbox':
				self.useFluxbox = True
			elif self.userDesktop == 'kde':
				self.useKde = True
			elif self.userDesktop == 'gnome':
				self.useGnome = True
			else:
				print "\n	Please set DESKTOP=<your desktop> in %s%sGeoXPlanet.conf (Under \"General\")" % (sys.path[0], os.sep)
				print "	Acceptable values are 'gnome', 'kde', and 'fluxbox' (more to come)"
				sys.exit(1)
		else:
			self.userDesktop = 'windows'
		
		print self.userDesktop
		

		
		print "	Detecting GeoXPlanet directory:   ",
		self.GeoXPlanetDir = sys.path[0][:-4]
		print self.GeoXPlanetDir
		
		print "Done detecting environment settings"
		
		print "Reading the config file options...",
		
		
		# GENERAL CONFIG OPTIONS
			
		if self.platform == 'lin':
			# Linux users have the choice between /proc/net/tcp and netstat
			netstat = config.get("General","useNetstat")
		else:
			netstat = 'True' # other platforms require netstat

		if netstat == 'True': 
			self.useNetstat = True
			if self.platform != 'win' and self.platform != 'Mic':
				self.netstatCommand = "netstat -na 2>>/dev/null | grep ESTABLISHED"
			else:
				self.netstatCommand = "netstat -an"
		else: 
			self.connectionFileName = "/proc/net/tcp"
			self.useNetstat = False
			
		
		self.defaultColor = config.get("General", "defaultColor")
			
		self.hostportRegex = re.compile("([0-9A-F]{8}):([0-9A-F]{4})[ ]*([0-9A-F]{2})")
		self.latRegex = re.compile("Latitude:([ 0-9\.\-]*)")
		self.lonRegex = re.compile("Longitude:([ 0-9\.\-]*)")

		try:
			self.delay = float(config.get("General","delay"))
		except Exception:
			print "\n\tWARNING: Invalid delay setting in GeoXPlanet.conf (under \"General\")"
			print "\t\tUsing the default delay (15.0 seconds)"
			self.delay = 15.0
			
		self.markerFileName = "markerFile.txt"

		self.suffix = 0


		# XPLANET CONFIG OPTIONS
		self.outputFileName = "GeoXPlanet"
		self.xplanetConfig = "xplanet.conf.example"

		# DISPLAY CONFIG OPTIONS
		self.displayDict = {}
		if config.get("Display", "Xinerama") == 'True':
			self.xinerama = True
		try:
			self.numDisplays = int(config.get("Display","NumberOfDisplays"))
		except Exception, inst:
			self.numDisplays = 1
		
		for index in range(0, self.numDisplays):
			self.displayDict["Monitor_%i_geometry" % index] = config.get("Display", "Monitor_%i_geometry" % index)
			self.displayDict["Monitor_%i_arcs" % index] = (config.get("Display", "Monitor_%i_arcs" % index) == "True")
			if self.displayDict["Monitor_%i_arcs" % index]:
				arcComment = ''
			else:
				arcComment = '#'
			self.displayDict["Monitor_%i_trace" % index] = (config.get("Display", "Monitor_%i_trace" % index) == "True")
			self.displayDict["Monitor_%i_projection" % index] = config.get("Display", "Monitor_%i_projection" % index)
			self.displayDict["Monitor_%i_radius" % index] = config.get("Display", "Monitor_%i_radius" % index)
			self.displayDict["Monitor_%i_titles" % index] = (config.get("Display", "Monitor_%i_titles" % index) == "True")
			self.displayDict["Monitor_%i_titleType" % index] = config.get("Display", "Monitor_%i_titleType" % index)
			self.displayDict["Monitor_%i_colors" % index] = (config.get("Display", "Monitor_%i_colors" % index) == "True")
			self.displayDict["Monitor_%i_symbolsize" % index] = config.get("Display", "Monitor_%i_symbolsize" % index)
			self.displayDict["Monitor_%i_showNations" % index] = (config.get("Display", "Monitor_%i_showNations" % index) == "True")
			self.displayDict["Monitor_%i_showCoast" % index] = (config.get("Display", "Monitor_%i_showCoast" % index) == "True")
			self.displayDict["Monitor_%i_showStates" % index] = (config.get("Display", "Monitor_%i_showStates" % index) == "True")
			self.displayDict["Monitor_%i_showClouds" % index] = (config.get("Display", "Monitor_%i_showClouds" % index) == "True")
			if self.displayDict["Monitor_%i_showClouds" % index]:
				cloudComment = ""
				self.cloudChecker = cloudClass()
				self.showClouds = True
			else:
				cloudComment = "#"
			self.displayDict["Monitor_%i_nationColor" % index] = config.get("Display", "Monitor_%i_nationColor" % index)
			self.displayDict["Monitor_%i_coastColor" % index] = config.get("Display", "Monitor_%i_coastColor" % index)
			self.displayDict["Monitor_%i_stateColor" % index] = config.get("Display", "Monitor_%i_stateColor" % index)
			self.displayDict["Monitor_%i_latitude" % index] = config.get("Display", "Monitor_%i_latitude" % index)
			self.displayDict["Monitor_%i_longitude" % index] = config.get("Display", "Monitor_%i_longitude" % index)
			self.displayDict["Monitor_%i_xplanetConfig" % index] = "%s%sMonitor_%i_xplanet.conf" % (self.GeoXPlanetDir, os.sep, index)
			conf = open(self.displayDict["Monitor_%i_xplanetConfig" % index], 'w')
			self.displayDict["Monitor_%i_markerFile" % index] = "Monitor_%i_markerFile.txt" % index
			self.displayDict["Monitor_%i_arcFile" % index]  = "Monitor_%i_arcFile.txt" % index
			conf.write("""
[default]
marker_color=red
shade=30
text_color={255,0,0}
twilight=6
[earth]
\"Earth\"
image=earth.jpg
night_map=night.jpg
color={28, 82, 110}
marker_file=%s
%sarc_file=%s
marker_fontsize=10
%scloud_map=clouds_2048.jpg
""" % (
self.displayDict["Monitor_%i_markerFile" % index], 
arcComment, self.displayDict["Monitor_%i_arcFile" % index], 
cloudComment))
			conf.close()
		
		self.displayDict["DESKTOP"] = config.get("General", "DESKTOP")
		
		for index in range(0, self.numDisplays):
			if self.displayDict["Monitor_%i_trace" % index]:
				self.traceTemp = True
				from trace import Trace as traceroute
				self.traceroute = traceroute
				break
		
		# colorList: Interesting port numbers...Add or remove them as you need.
		# Taken from http://www.iana.org/assignments/port-numbers, revised in 0.4.4-r2
		self.colorList = {
				'21':'0xffffff', # ftp
				'22':'0xffff00', # ssh
				'23':'0x00ffff', # telnet
				'53':'0x99ff00', # dns
				'79':'0x0099ff', # finger
				# web surfing
				'80':'0x9900ff', # http
				'443':'0x9900ff', # https
				'3128':'0x9900ff', # http proxy
				# mail stuff
				'25':'0xff00ff', # smtp
				'110':'0xff9900', # pop3
				'995':'0xff9900', # pop3 over SSL/TLS
				# Samba stuff
				'137':'0x00ff99', # NetBIOS name
				'138':'0x00ff99', # NetBIOS Datagram
				'139':'0x00ff99', # NetBIOS Session
				'445':'0x00ff99', # Microsoft-DS
				# instant messenger port nums: add as needed!
				'1863':'0x009999', # MSN
				'5050':'0x009999', # Yahoo - NOT from iana!
				'5190':'0x009999', # AIM
				'5222':'0x009999', # XMPP (Jabber, GMail chat)
				'5223':'0x009999', # XMPP with old-fashioned SSL (GMail XMPP, for instance)
				# others
				'161':'0xff0099', # SNMP
				'873':'0x999900', # rsync
				'6667':'0x990099' # IRC
				}
				
				
		# DATABASE CONFIG OPTIONS
		useDB = config.get("Database","useDatabase")
		if useDB == 'True':
			self.useDatabase = True
			print ""
			self.database = Database()
			if not self.database.isConnected(): # connection failed?
				self.useDatabase = False
		else:
			self.useDatabase = False
	
		self.converter = convert()
		self.locationDict = {}
		self.locationCache = {}
		
		self.homeLAT = config.get("General","homeLAT")
		self.homeLONG = config.get("General","homeLON")
		
		print "Done reading the config file"
		
		self.numConnections = 0
		self.waitWarning = False
		print ""
	
	def getActiveConnections(self):
		activeConnections = []
		traceDict = {}
		if self.useNetstat:
			connectionList = os.popen(self.netstatCommand).readlines()
			for connection in connectionList:
				if 'ESTABLISHED' in connection:
					if self.DEBUG:
						print connection
					if self.platform == 'win' or self.platform == 'Mic':
						ipAddy = connection.split()[2].split(':')[0]
						ipPort = connection.split()[2].split(':')[1]
					else:
						ipAddy = connection.split()[4].split(':')[0]
						ipPort = connection.split()[4].split(':')[1]
					if not ipAddy.find('127.0.0.1') == 0 and not ipAddy.find('10') == 0 and not ipAddy.find('192.168') == 0 and not ipAddy == '':				
						activeConnections.append("%s,%s" % (ipAddy,ipPort))
						self.waitWarning = False
						if self.traceTemp and ipAddy not in self.traceDict.keys():
							self.trace(ipAddy, ipPort)
		else:
			connectionList = open(self.connectionFileName, 'r')
			for connection in connectionList:
				connection = connection[20:] # cut off the localhost stuff
				
				# now let's match the info (in hex): host:port state
				hostMatch = self.hostportRegex.search(connection)
					
				# if we got a match, process it, else loop back to next connection
				if hostMatch is not None and hostMatch.group(1) != '00000000':
					
					# the regex match should have three groups...
					ipAddy = hostMatch.group(1)
					ipPort = hostMatch.group(2)
					ipState = hostMatch.group(3)
				
					# let's only bother with active, non-local connections
					if ipState == '01' and not ipAddy.endswith('007F') and not ipAddy.endswith('0A') and not ipAddy.endswith('A8C0') and not ipAddy == '':
						ip = self.converter.ipDecode(ipAddy)
						activeConnections.append("%s,%s" % (ip,self.converter.hexDecode(ipPort)))
						self.waitWarning = False
						
						if self.traceTemp and ip not in self.traceDict.keys():
							self.trace(ip, self.converter.hexDecode(ipPort))
			
			connectionList.close()
			
		return activeConnections
	
	def lookupIP(self, ipStr, ipPort):
		if ipStr in self.locationCache.keys():
			return self.locationCache[ipStr]
		
		if self.useDatabase is True:
			latlonList = self.database.lookup(self.converter.ipEncode(ipStr))
			lat = latlonList[0]
			long = latlonList[1]
		else:
			try:
				# grab the page and match it against the lat/long regex.
				page = urllib.urlopen("http://api.hostip.info/get_html.php?ip=%s&position=true" % ipStr)
				result = page.read()
				
				latMatch = self.latRegex.search(result)
				lonMatch = self.lonRegex.search(result)
				
				# did we match the lat/long?  Grab the values!
				if latMatch is not None and lonMatch is not None:
					lat = latMatch.group(1)
					long = lonMatch.group(1)
				# no match...let's set them to 0.0 for now
				else:
					# TODO:  Error handling here?
					lat = 0.0
					long = 0.0
				
				if lat.strip() == '':
					lat = 0.0
				if long.strip() == '':
					long = 0.0
			except Exception, inst:
				lat = 0.0
				long = 0.0
				
		colors = False
		for index in range(0, self.numDisplays):
			if self.displayDict["Monitor_%i_colors" % index]:
				colors = True
		if colors and ipPort in self.colorList.keys():
			color = self.colorList[ipPort]
		else:
			color = self.defaultColor
			
		ipHost = hostlookup(ipStr) # create a new thread to run rDNS in parallel
		ipHost.start() # fire the thread off
		
		# let's create a new record for this ip and location...
		# the record will have the location (ip addy) as the key,
		# and a list of lat/long for the value.  Cache it as well...
		# ...as well as port and DNS name :P
		self.locationDict[ipStr] = ipRecord(ipStr, color, ipPort,ipHost)
		self.locationDict[ipStr].addIP(lat, long, color, ipPort,ipHost)
		self.locationCache[ipStr] = ipRecord(ipStr, color, ipPort,ipHost)
		self.locationCache[ipStr].addIP(lat,long, color, ipPort,ipHost)
	
	def processList(self, ipList):
		for ip in ipList[:]:
					
			# this is a mess...I'll clean it up in a later release =\
			IpAndPort = ip.split(',')
			del ipList[ipList.index(ip)]
			ip = IpAndPort[0]
			port = IpAndPort[1]
			
			ipList.append(ip)
				
			# if the ip isn't in the Dictionary, add it
			if ip not in self.locationDict.keys():
				self.dirtyList = True
				# let's check the cache first...
				if ip not in self.locationCache.keys():
					print "Performing GEO/rDNS lookup on %s" % ip
					self.lookupIP(ip, port)
				# it's already in the cache...pull the info
				else:
					print "Adding %s from cache!" % ip
					self.locationDict[ip] = self.locationCache[ip]
						
		# now we need to drop old connections
		for ipStr in self.locationDict.keys()[:]:
			# if the dictionary has an ip that isn't in the 
			# active connection list, then drop it
			if ipStr not in ipList:
				self.dirtyList = True
				print "deleting %s" % ipStr
				del self.locationDict[ipStr]
	
	def trace(self, ip, port):
		print "Starting Trace on %s" % ip
		if ip not in self.traceCache.keys():
			#print "TRACE:  %s : %s" % (ip, port)
			current = self.traceroute(ip, port)
			self.traceDict[ip] = current
			self.traceCache[ip] = current
			current.start()
		else:
			#print "TRACE:	Adding trace record %s from cache" % ip
			self.traceDict[ip] = self.traceCache[ip]
	
	def generateFiles(self):
		#print "generating files..."
		for index in range(0, self.numDisplays):
			try:
				#	self.displayDict["Monitor_%i_markerFile" % index] = "Monitor_%i_markerFile.txt" % index
				markerFile = open(os.path.join(os.environ["HOME"],".geoxplanet","markers","Monitor_%i_markerFile.txt" % index), 'w')
				
			# oops...failure here makes the script kinda useless...
			except Exception, inst:
				if self.DEBUG:
					print inst
				else:
					print "Unable to open the marker file:  Cannot continue!"
					print "If you need assistance, please set DEBUG=True in GeoXPlanet.conf"
					print "and re-run the script.  Mail the output to rocket357@users.sourceforge.net"
				sys.exit(1)
				
			# now process arcs...
			try:
				if self.displayDict["Monitor_%i_arcs" % index]:
					#	self.displayDict["Monitor_%i_arcFile" % index] = "Monitor_%i_arcFile.txt" % index
					arcFile = open(os.path.join(os.environ["HOME"],".geoxplanet","arcs","Monitor_%i_arcFile.txt" % index), 'w')
					if self.displayDict["Monitor_%i_showCoast" % index]:
						#print "writing coast arcs"
						arcFile.write("0 0 0 0 color=%s\n" % self.displayDict["Monitor_%i_coastColor" % index])
						coastFile = open(os.path.join(self.GeoXPlanetDir,"arcFiles","coast_c"), 'r')
						arcFile.writelines(coastFile.readlines())
						coastFile.close()
					if self.displayDict["Monitor_%i_showStates" % index]:
						#print "writing state arcs"
						arcFile.write("0 0 0 0 color=%s\n" % self.displayDict["Monitor_%i_stateColor" % index])
						stateFile = open(os.path.join(self.GeoXPlanetDir,"arcFiles","states_c"), 'r')
						arcFile.writelines(stateFile.readlines())
						stateFile.close()
					if self.displayDict["Monitor_%i_showNations" % index]:
						#print "writing nation arcs"
						arcFile.write("0 0 0 0 color=%s\n" % self.displayDict["Monitor_%i_nationColor" % index])
						nationFile = open(os.path.join(self.GeoXPlanetDir,"arcFiles","boundaries_c"), 'r')
						arcFile.writelines(nationFile.readlines())
						nationFile.close()
			except Exception, inst:
				if self.DEBUG:
					traceback.print_exc(file=sys.stdout)
				print "Unable to open the arc file:  Disabling arcs for now."
				os.popen("echo ' ' > %s" % os.path.join(os.environ["HOME"],".geoxplanet","arcs","Monitor_%i_arcFile.txt" % index))
				self.useArcs = False
				
			# let's grab all this info and prepare to write the marker/arc files...
			#print self.traceDict.keys()
			for location in self.locationDict.keys():
				name = location
				
				# grab the list of items out of ipRecord instances...
				thisIP = self.locationDict[location].getIP()
				lat = thisIP[0]
				long = thisIP[1]
				color = thisIP[2]
				port = thisIP[3]
				
				if thisIP[4].isRunning():
					host = name
				else:
					host = thisIP[4].getHostname()
				
				# if the lat and long both = 0.0, that means we didn't get a match (or find a record in the db)
				if lat != 0.0 and long != 0.0:
					
					# now generate the marker file based on our settings...
					if self.displayDict["Monitor_%i_titles" % index]:
						if self.displayDict["Monitor_%i_titleType" % index] == 'ip': 
							mark = name
						elif self.displayDict["Monitor_%i_titleType" % index] == 'host': 
							mark = host
						else: 
							mark = port
					# blank titles here...
					else: mark = ' '

					markerFile.write("%s %s \"%s\" color=%s symbolsize=%s\n" % (lat, long, mark,color, self.displayDict["Monitor_%i_symbolsize" % index]))
					
				if self.displayDict["Monitor_%i_trace" % index]:
					#print "TRACE:  target = %s" % name
					#print self.traceDict
					try:
						if self.traceDict[name].isRunning():
							arcFile.write("%s %s %s %s color=%s\n" % (self.homeLAT, self.homeLONG, lat, long, color))
						else:
							#print "TRACE:  target = %s" % name
							if name in self.locationCache.keys():
								oldLatLong = [self.homeLAT,self.homeLONG]
								currentLatLong = [self.homeLAT,self.homeLONG]
								for hop in self.traceDict[name].getList():
									#print "	hop: \"%s\"" % hop
									if currentLatLong is not None and oldLatLong is not None:
										arcFile.write("%s %s %s %s color=%s\n" % (oldLatLong[0], oldLatLong[1], currentLatLong[0], currentLatLong[1], color))
										markerFile.write("%s %s color=0xFF0000 symbolsize=4\n" % (currentLatLong[0], currentLatLong[1]))
										oldLatLong = copy.copy(currentLatLong)
									if hop.strip() is not '' and hop.strip() in self.locationCache.keys():
										#print "TRACE:  Adding tracepoint \"%s\" from cache" % hop
										currentLatLong = self.locationCache[hop.strip()].getIP()
										#print currentLatLong
									else:
										if hop.strip() is not '':
											#print "TRACE:  Looking up tracepoint \"%s\"" % hop
											currentLatLong = self.lookupIP(hop.strip(), 0)
											#print "currentLatLong:  %s" % currentLatLong
											if currentLatLong is None:
												pass
												#print "TRACE:	Lookup on %s failed" % hop
											else:
												self.dirtyList = True
												self.locationCache[hop.strip()] = ipRecord(hop.strip(), '0x555555', 0)
												self.locationCache[hop.strip()].addIP(currentLatLong[0], currentLatLong[1], '0x555555', 0)
												#print self.locationCache[hop.strip()]
								markerFile.write("%s %s color=0xFF0000 symbolsize=4\n" % (currentLatLong[0], currentLatLong[1]))
								arcFile.write("%s %s %s %s color=%s\n" % (oldLatLong[0], oldLatLong[1], currentLatLong[0], currentLatLong[1], color))
					except Exception, inst:
						pass
				elif self.displayDict["Monitor_%i_arcs" % index]:
					arcFile.write("%s %s %s %s color=%s\n" % (self.homeLAT, self.homeLONG, lat, long, color))
			# Home will always be plotted!
			markerFile.write("%s %s \"%s\" align=above color=0xffffff symbolsize=%s\n" % (self.homeLAT, self.homeLONG, self.homeName, self.displayDict["Monitor_%i_symbolsize" % index]))
						
			# and we need to close a few files...
			markerFile.close()
			if self.useArcs:
				arcFile.close()
	
	def runXPlanet(self):
		# generate the image
		self.suffix = (self.suffix + 1) % 2
		tmpDir = os.path.join(os.environ["HOME"],".geoxplanet")			

		if self.platform == 'win' or self.platform == 'Mic':
			extension = 'bmp'
		else:
			extension = 'jpg'
		
		for index in range(0, self.numDisplays):
			imageFile = "%s%s.%s" % (os.path.join(os.environ["HOME"],".geoxplanet","images",("Monitor_%i_Output" % index)), self.suffix, extension)
			print "Generating image file: %s" % imageFile

			xplanetCommand = "%s -num_times 1 -searchdir %s -tmpdir %s -marker_file %s " % (self.xplanetExe, tmpDir, tmpDir, self.displayDict["Monitor_%i_markerFile" % index])

			if self.displayDict["Monitor_%i_projection" % index] != 'None':
				xplanetCommand = xplanetCommand + "-projection %s " % self.displayDict["Monitor_%i_projection" % index]
			if self.displayDict["Monitor_%i_radius" % index] != 'None':
				xplanetCommand = xplanetCommand + "-radius %s " % self.displayDict["Monitor_%i_radius" % index]
			if self.displayDict["Monitor_%i_arcs" % index] != '':
				xplanetCommand = xplanetCommand + "-arc_file %s " % self.displayDict["Monitor_%i_arcFile" % index]
			if self.displayDict["Monitor_%i_latitude" % index] != '' and self.displayDict["Monitor_%i_longitude" % index] != '':
				xplanetCommand = xplanetCommand + "-latitude %s -longitude %s " % (self.displayDict["Monitor_%i_latitude" % index], self.displayDict["Monitor_%i_longitude" % index]) 
			xplanetCommand = xplanetCommand + "-geometry %s -config %s -output %s " % (self.displayDict["Monitor_%i_geometry" % index], self.displayDict["Monitor_%i_xplanetConfig" % index], imageFile)
			
			if self.DEBUG:
				print "XPLANET COMMAND:"
				print xplanetCommand

			(stdin, stdout, stderr) = os.popen3(xplanetCommand)
			errors = stderr.readlines()
			for error in errors:
				print "XPLANET ERROR: %s" % error			
		
		print "Setting wallpaper!"
		# Now let's set the background image...
		if self.platform != 'win' and self.platform != 'Mic':
			if self.xinerama:
				os.popen("convert %s%s.%s %s%s.%s +append %s%s.%s" % (
				(os.path.join(tmpDir,"images","Monitor_0_Output")), self.suffix, extension, 
				(os.path.join(tmpDir,"images","Monitor_1_Output")), self.suffix, extension, 
				(os.path.join(tmpDir,"images","Output")), self.suffix, extension))
			else:
				os.popen("mv %s%s.%s %s%s.%s" % (
				(os.path.join(tmpDir,"images","Monitor_0_Output")), self.suffix, extension, 
				(os.path.join(tmpDir,"images","Output")), self.suffix, extension))
			command = ""
			if self.displayDict["DESKTOP"] == 'gnome':
				command = "gconftool-2 -t str -s /desktop/gnome/background/picture_filename"
			if self.displayDict["DESKTOP"] == 'kde': #TODO does this work for KDE4?  Answer: NO...KDE4 uses D-Bus, not dcop...
				command = "dcop kdesktop KBackgroundIface setWallpaper"
			if self.displayDict["DESKTOP"] == 'fluxbox':
				command = "fbsetbg"
			if self.displayDict["DESKTOP"] == 'enlightenment':
				command = ""
			if self.displayDict["DESKTOP"] == 'xfce':
				command = "echo -e \"# xfce backdrop list\n%s\">$HOME/.config/xfce4/desktop/backdrops.list && xfdesktop --reload"
			
			#print "%s %s%stemp%simages%s%s%s.png" % (command, self.GeoXPlanetDir, os.sep, os.sep,os.sep,("Monitor_%i_Output" % index), self.suffix)
			(stdin, stdout, stderr) = os.popen3("%s %s%s.%s" % (command, os.path.join(tmpDir,"images","Output"), self.suffix, extension))
		
		else: # this is a windows system!
			bmp = ctypes.c_char_p( "%s%s.%s" % (os.path.join(tmpDir,"images","Monitor_0_Output"), self.suffix, extension))
			ctypes.windll.user32.SystemParametersInfoA( 20, 0, bmp, 3 )
			
	def run(self, GUI):
		self.GUI = GUI
		if GUI:
			pass
			# TODO Taskbar notification icon?
		else:
			pass
			# TODO run normally
		firstPass = True
		if self.showClouds:
			cloudFile = os.path.join(os.environ["HOME"],".geoxplanet","images","clouds_2048.jpg")
			#print "Cloud File: %s" % cloudFile
		
		while True: # loop until the script is shut down...
			if self.DEBUG: # let the script bomb on error to get a full trace...
				self.dirtyList = False
				self.processList(self.getActiveConnections())
				self.generateFiles()
				if self.showClouds:
					try:
						print cloudFile
						s = os.stat(cloudFile)
						mtime = s.st_mtime
						found = True
					except Exception, inst:
						traceback.print_exc(file=sys.stdout)
						mtime = 0
						found = False
					print '%s > %s ??' % ((time.time() - mtime), (3 * 3600))
					if time.time() - mtime > 3 * 3600:
						self.cloudChecker.downloadClouds()
						self.dirtyList = True
						
				# if the list of connections has changed or it's the first loop through...
				if self.dirtyList or firstPass:
					self.runXPlanet()
					firstPass = False
				
				# print out a message to let the user know the script is in a wait status
				if self.waitWarning:
					print "Waiting for connections..."
					self.waitWarning = False
				
			else:
				try:
					self.dirtyList = False
					self.processList(self.getActiveConnections())
					self.generateFiles()
					if self.showClouds:
						try:
							#print cloudFile
							s = os.stat(cloudFile)
							mtime = s.st_mtime
							#print time.time() - mtime
							found = True
						except Exception, inst:
							traceback.print_exc(file=sys.stdout)
							mtime = 0
							found = False
						if time.time() - mtime > 3 * 3600:
							self.cloudChecker.downloadClouds()
							self.dirtyList = True
						
					# if the list of connections has changed or it's the first loop through...
					if self.dirtyList or firstPass:
						self.runXPlanet()
						firstPass = False
				
					# print out a message to let the user know the script is in a wait status
					if self.waitWarning:
						print "Waiting for connections..."
						self.waitWarning = False
				
				# DOH!  Something went wrong...
				except Exception, inst:
					if self.DEBUG:
						version = self.GeoXPlanetDir.find("GeoXPlanet")
						print "Version: %s" % self.GeoXPlanetDir[version+10:]
						traceback.print_exc(file=sys.stdout)
					else:
						print "An error has occurred: \"%s\"" % inst
						print "If you need assistance, please set DEBUG=True in GeoXPlanet.conf"
						print "and re-run the script.  Mail the output to rocket357@users.sourceforge.net"
					sys.exit(1)
				
			# And let's wait a few seconds before updating again
			time.sleep(self.delay)
