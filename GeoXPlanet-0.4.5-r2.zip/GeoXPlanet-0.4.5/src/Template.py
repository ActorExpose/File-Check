#!/usr/bin/env python

#
# Templates for GeoXPlanet
#
# Author: rocket357 AT users DOT sourceforge DOT net
#

import pygtk
pygtk.require('2.0')
import gtk

class Template:
	
	def Layout(self):
		pass
