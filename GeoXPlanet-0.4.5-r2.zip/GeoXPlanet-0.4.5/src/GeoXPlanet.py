#!/usr/bin/env python

###############################################################################
## GeoXPlanet.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This script launches the GeoXPlanet project. 
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.4.5
#		Took Markus' advice and put config stuff in .geoxplanet - rocket357
#
# Version 0.3.8
#		Added list of GPL'd code/files that are included with the project 
#			from outside of the GeoXPlanet project - rocket357
#
# Version 0.3.7
#		Added __name__ check - rocket357
#
# Version 0.3.4
#		Moved main body of code into controller.py - rocket357
#

import sys, os, time, shutil, ConfigParser
from controller import GeoXPlanet

print """
GeoXPlanet contains GPL code/files from the following sources:

clouds.py and controller.py now contain code from:
download_clouds.py ver. 1.1
Taken from: 
http://xplanet.sourceforge.net//Extras/download_clouds.py
(C) 2004 Michal Pasternak <michal@pasternak.w.lub.pl>
This file has been modified by rocket357 for use in GeoXPlanet.

arcFiles directory: (boundaries_c, coast_c, and states_c)
Taken from: 
http://xplanet.sourceforge.net/Extras/boundaries_c.gz
http://xplanet.sourceforge.net/Extras/coast_c.gz
http://xplanet.sourceforge.net/Extras/states_c.gz
These files are only used when GeoXPlanet.conf is set
with any of the following set to "True":
showNations, showCoast, and showStates

These files are, to the best of the author's knowledge,
GPL'd source.  If you know that this is not the case, please
contact: rocket357 (at) users (dot) sourceforge (dot) net
so the files can be removed from distribution.
"""

#time.sleep(15)

configFile = os.path.join(os.environ["HOME"],".geoxplanet","GeoXPlanet.conf")
GUI = False

# yikes this is UGLY!
currVersion = sys.path[0].split(os.sep)[-2:-1][0].split('-')[-1:][0]

print "Current GeoXPlanet version:  %s" % currVersion
configVersionOK = False

try:
	print "Looking for the GeoXPlanet.conf file:"
	print "	%s..." % (configFile)
	config = open("%s" % (configFile))
	print "Found the config file!"
	configParser = ConfigParser.ConfigParser()
	configParser.readfp(config)
	try:
		version = configParser.get("General","VERSION")
		configVersionOK = (version == currVersion)
	except Exception, inst:
		print "It appears you are using a config file from before GeoXPlanet version %s" % currVersion
		print "I will attempt to auto-detect if this configuration file is compatible with"
		print "	GeoXPlanet-%s..." % currVersion,
		try:
			versionDetect = configParser.read("Display","Monitor_0_geometry") # GeoXPlanet-0.4.2+
			print "Yes"
			configVersionOK = True
		except Exception, inst:
			print "No"
			configVersionOK = False
			raise Exception # the current config file isn't compatible with this version of GeoXPlanet...let's kick off the configGUI
except Exception, inst:
	if not os.path.exists(os.path.join(os.environ["HOME"], ".geoxplanet")) or not os.path.isdir(os.path.join(os.environ["HOME"], ".geoxplanet")):
		print "Moving temp files (images, config files, etc...) from "
		print "the GeoXPlanet directory to %s" % os.path.join(os.environ["HOME"],".geoxplanet")
		shutil.move(os.path.join(sys.path[0][:-4],"temp"), os.path.join(os.environ["HOME"],".geoxplanet"))
	from configGUI import configGUI
	config = configGUI()
	config.show()
	GUI = True

if __name__ == '__main__':
	program = GeoXPlanet(configFile)
	program.run(GUI)
	