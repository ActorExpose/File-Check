#
# download_clouds.py ver. 1.1
#
# Download coulds map for xplanet from a random mirror, optionally
# save the one to archive directory.
#
# Usage:
#   python download_clouds.py - to save the output as clouds_2048.jpg
#   python download_coulds.py output.jpg - to save the output as output.jpg
#
# (C) 2004 Michal Pasternak <michal@pasternak.w.lub.pl>
#
# This file is in public domain.

# THIS FILE HAS BEEN MODIFIED FROM IT'S ORIGINAL VERSION!!!
# CHANGELOG
#
# Version 0.4.5
#		Basic rework...made file operations more "pythonic" - rocket357
#		Removed useless print statements - rocket357
#
# Version 0.3.8
#		Added to project - rocket357
#		Changed to a class file for use in GeoXPlanet - rocket357
#		Removed option to archive old cloud image files - rocket357
#		Moved mtime checks to controller.py - rocket357

import random, urllib, sys, stat, time, os, shutil

class clouds:
	# Variables
	maxRetries = 3
	imageDir = "%s%s" % (os.path.join(os.environ["HOME"],".geoxplanet","images"), os.sep)
	defaultOutputFile = "clouds_2048.jpg"
	mirrors = [    "http://www.ruwenzori.net/earth/clouds_2048.jpg",
			       "http://xplanet.arculeo.com/clouds_2048.jpg",
			       "http://xplanet.dyndns.org/clouds/clouds_2048.jpg",
			       "http://userpage.fu-berlin.de/~jml/clouds_2048.jpg",
			       "http://rcswww.urz.tu-dresden.de/~es179238/clouds_2048.jpg",
			       "http://home.megapass.co.kr/~ysy00/cloud_data/clouds_2048.jpg",
			       "http://home.megapass.co.kr/~holywatr/cloud_data/clouds_2048.jpg",
			       "http://user.chol.com/~winxplanet/cloud_data/clouds_2048.jpg",
			       "http://home.megapass.co.kr/~gitto88/cloud_data/clouds_2048.jpg",
			       "http://giga.colozone.nl/clouds_2048.jpg",
			       "http://www.wizabit.eclipse.co.uk/xplanet/files/mirror/clouds_2048.jpg",
			       "http://www.wizabit.eclipse.co.uk/xplanet/files/local/clouds_2048.jpg",
			       "http://xplanet.explore-the-world.net/clouds_2048.jpg" ]
	platform = sys.platform[:3]

	def downloadClouds(self):	
		print "Downloading update for cloud file..."
		if os.path.exists(os.path.join(self.imageDir, self.defaultOutputFile)):
			try: # Windows raises an exception if file is in use...doh?
				unlink(os.path.join(self.imageDir, self.defaultOutputFile))
			except: # Should only occur on Windows
				pass 
				
		for a in range(self.maxRetries):
			try:
				url = self.mirrors [ random.randint(0, len(self.mirrors)-1) ]
				urllib.urlretrieve(url, self.defaultOutputFile)
				shutil.move(os.path.join(sys.path[0],"clouds_2048.jpg"), os.path.join(os.environ["HOME"],".geoxplanet","images",self.defaultOutputFile))
				print "Done!"
				return
			except Exception, inst:
				pass
			pass
