###############################################################################
## route.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This script is intended to generate a reusable "route record" so traces don't have to be run over and over
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.3.7
#		Added to Project - rocket357

class route:
	
	numNodes = 0
	route = {}
	
	def addNode(self, ipStr, lat, long):
		self.route[numNodes] = [ipStr, lat, long]
		self.numNodes += 1
		
	def getRoute(self):
		return self.route