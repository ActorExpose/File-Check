###############################################################################
## onlineLookup.py
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This script is intended to parallelize online lookups to speed up the process
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

from threading import Thread
import os, re, sys
import urllib

class onlineLookup(Thread):
	
	ipStr = ''
	lat = 0.0
	long = 0.0
	latRegex = ''
	lonRegex = ''
	
	def __init__(self, ipStr):
		Thread.__init__(self)
		self.ipStr = ipStr
		self.latRegex = re.compile("Latitude:([ 0-9\.\-]*)")
		self.lonRegex = re.compile("Longitude:([ 0-9\.\-]*)")

	def run(self):
		page = urllib.urlopen("http://api.hostip.info/get_html.php?ip=%s&position=true" % self.ipStr)
		result = page.read()
		latMatch = self.latRegex.search(result)
		lonMatch = self.lonRegex.search(result)
		
		# did we match the lat/long?  Grab the values!
		if latMatch is not None and lonMatch is not None:
			lat = latMatch.group(1).strip()
			long = lonMatch.group(1).strip()
		# no match...let's set them to 0.0 for now
		else:
			# TODO:  Error handling here?
			lat = 0.0
			long = 0.0
		if self.DEBUG:
			print "IP Address: %s" % ipStr
			print "Lat: %s	Long: %s" % (lat, long)
		if not (lat > 5.0 and lat < -5.0 and long > 5.0 and long < -5.0):
			self.lat = lat
			self.long = long
		else:
			self.lat = None
			self.long = None
			
	def getLocation(self):
		return [self.lat, self.long]