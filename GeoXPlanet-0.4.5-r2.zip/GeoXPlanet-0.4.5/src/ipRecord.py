###############################################################################
## convert class
##
## Author: rocket357
## rocket357@users.sourceforge.net
##
## This class file contains various functions needed for tracking the
## ip addresses and port numbers for xearth.py
##
## This script is GPL'd.  To view the license, see:
##
## http://www.gnu.org/licenses/gpl.txt
###############################################################################

# CHANGELOG
#
# Version 0.4.4-r2
#		Added host recording for reverse DNS lookups - FraGGod
#
# Version 0.3.7
#		Massive restructure to accomodate threaded lookups - rocket357
#
# Version 0.3.2
#		Added port to list - rocket357
#
# Version 0.1
#		Initial Release - rocket357
#

from threading import Thread
import os, re, sys
import urllib

class ipRecord(Thread):
	record = None
	color = ''
	port = ''
	
	def __init__(self, ipStr, color, port,host):
		Thread.__init__(self)
		self.ipStr = ipStr
		self.latRegex = re.compile("Latitude:([ 0-9\.\-]*)")
		self.lonRegex = re.compile("Longitude:([ 0-9\.\-]*)")
		self.port = port
		self.host = host
		self.color = color

	def run(self):
		page = urllib.urlopen("http://api.hostip.info/get_html.php?ip=%s&position=true" % self.ipStr)
		result = page.read()
		latMatch = self.latRegex.search(result)
		lonMatch = self.lonRegex.search(result)
		
		# did we match the lat/long?  Grab the values!
		if latMatch is not None and lonMatch is not None:
			lat = latMatch.group(1).strip()
			long = lonMatch.group(1).strip()
		# no match...let's set them to 0.0 for now
		else:
			# TODO:  Error handling here?
			lat = 0.0
			long = 0.0
		
		# Check to make sure we're still sane...
		if lat is not '' and long is not '' and not (lat > 5.0 and lat < -5.0 and long > 5.0 and long < -5.0):
			self.record = [lat, long, self.color, self.port]
		else:
			self.record = None

	def addIP(self, lat, long, color, port,host):
		self.record = [lat, long, color, port,host]
		return self.record
	
	def getIP(self):
		return self.record
