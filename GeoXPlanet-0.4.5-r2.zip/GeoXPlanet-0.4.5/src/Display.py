#!/usr/bin/env python

###############################################################################
## Display.py
##
## Display data structure for GeoXPlanet
##
## Author: rocket357 AT users DOT sourceforge DOT net
##
###############################################################################

# CHANGELOG
#
# Version 0.4.4-r2
#		Added projection radius value adjustment to GUI - FraGGod
#		Added more choice to Marker Title combobox - FraGGod
#
# Version 0.4.2?
#		Added to project - rocket357

import pygtk
pygtk.require('2.0')
import gtk

class Display(gtk.ScrolledWindow):
	
	configDict = {}
	index = "Monitor_"
	template = None
	resolution = None
	projection = None
	radius = None
	latitude = None
	longitude = None
	trace = None
	arcs = None
	titles = None
	titleType = None
	colors = None
	symbolsize = None
	showNations = None
	showCoast = None
	showStates = None
	nationColor = None
	coastColor = None
	stateColor = None
	showClouds = None
	
	def showDisplay(self, configDict, index):
		self.configDict = configDict
		self.index = self.index + str(index) + '_'
		#print self.index
				
		tbl = gtk.Table(10,4,False)
		
		templateLbl = gtk.Label("XPlanet Template")
		templateLbl.show()
		
		self.template = gtk.combo_box_entry_new_text()
		self.template.append_text("Full Screen")
		self.template.append_text("90% size - centered")
		self.template.append_text("Quarters")
		self.template.append_text("rocket357")
		self.template.set_active(0)
		self.template.show()
		
		resolutionLbl = gtk.Label("Monitor Resolution")
		resolutionLbl.show()
		
		self.resolution = gtk.combo_box_entry_new_text()
		self.resolution.append_text("640x480")
		self.resolution.append_text("800x600")
		self.resolution.append_text("1024x768")
		self.resolution.append_text("1152x864")
		self.resolution.append_text("1152x900")
		self.resolution.append_text("1280x768")
		self.resolution.append_text("1280x800")
		self.resolution.append_text("1280x864")
		self.resolution.append_text("1280x960")
		self.resolution.append_text("1280x1024")
		self.resolution.append_text("1366x768")
		self.resolution.append_text("1440x900")
		self.resolution.append_text("1440x960")
		self.resolution.append_text("1440x1050")
		self.resolution.append_text("1600x1024")
		self.resolution.append_text("1600x1200")
		self.resolution.append_text("1680x1050")
		self.resolution.append_text("1920x1200")
		self.resolution.append_text("2048x1536")
		self.resolution.set_active(0)
		self.resolution.show()
		
		traceLbl = gtk.Label("Use Traceroute")
		traceLbl.show()
		self.trace = gtk.CheckButton("requires arcs!")
		self.trace.connect("toggled", self.callback)
		self.trace.set_sensitive(False)
		self.trace.show()
		
		projectionLbl = gtk.Label("Projection")
		projectionLbl.show()
		self.projection = gtk.combo_box_entry_new_text()
		#ancient, azimuthal, bonne, gnomonic, hemisphere, lambert, mercator, 
		#mollweide, orthographic, peters, polyconic, rectangular, or tsc
		self.projection.append_text("None")
		self.projection.append_text("ancient")
		self.projection.append_text("azimuthal")
		self.projection.append_text("bonne")
		self.projection.append_text("gnomonic")
		self.projection.append_text("hemisphere")
		self.projection.append_text("lambert")
		self.projection.append_text("mercator")
		self.projection.append_text("mollweide")
		self.projection.append_text("orthographic")
		self.projection.append_text("peters")
		self.projection.append_text("polyconic")
		self.projection.append_text("rectangular")
		self.projection.append_text("tsc")
		self.projection.set_active(0)
		self.projection.connect("changed", self.callback)
		self.projection.show()
		
		radiusLbl = gtk.Label("Projection radius, %")
		radiusLbl.show()
		self.radius = gtk.Entry()
		self.radius.set_text("45")
		self.radius.connect("activate", self.callback)
		self.radius.show()

		latitudeLbl = gtk.Label("Viewpoint Latitude")
		latitudeLbl.show()
		self.latitude = gtk.Entry()
		self.latitude.set_text("0.0")
		self.latitude.connect("activate", self.callback)
		self.latitude.show()
		
		longitudeLbl = gtk.Label("Viewpoint Longitude")
		longitudeLbl.show()
		self.longitude = gtk.Entry()
		self.longitude.set_text("0.0")
		self.longitude.connect("activate", self.callback)
		self.longitude.show()
		
		arcsLbl = gtk.Label("Show Arcs")
		arcsLbl.show()
		self.arcs = gtk.CheckButton("(required for traceroute)")
		self.arcs.connect("toggled", self.callback)
		self.arcs.show()
		
		titlesLbl = gtk.Label("Show endpoint Titles")
		titlesLbl.show()
		self.titles = gtk.CheckButton("")
		self.titles.connect("toggled", self.callback)
		self.titles.show()
		
		titleTypeLbl = gtk.Label("Title Type")
		titleTypeLbl.show()
		self.titleType = gtk.combo_box_entry_new_text()
		self.titleType.set_sensitive(False)
		self.titleType.append_text("port")
		self.titleType.append_text("ip")
		self.titleType.append_text("host")
		self.titleType.set_active(0)
		self.titleType.connect("changed", self.callback)
		self.titleType.show()
		
		colorsLbl = gtk.Label("Use Protocol Colors")
		colorsLbl.show()
		self.colors = gtk.CheckButton("")
		self.colors.connect("toggled", self.callback)
		self.colors.show()
		
		symbolsizeLbl = gtk.Label("Marker size, in pixels")
		symbolsizeLbl.show()
		self.symbolsize = gtk.Adjustment(7,1,10,1,1)
		self.symbolsize.connect("value_changed", self.callback)
		symbolScale = gtk.HScale(self.symbolsize)
		symbolScale.set_draw_value(True)
		symbolScale.show()
		
		showNationsLbl = gtk.Label("Show nation outlines")
		showNationsLbl.show()
		self.showNations = gtk.CheckButton("")
		self.showNations.connect("toggled", self.callback)
		self.showNations.show()
		
		nationColorLbl = gtk.Label("Color for Nation outlines")
		nationColorLbl.show()
		self.nationColor = gtk.ColorButton(gtk.gdk.color_parse("#777777"))
		self.nationColor.set_sensitive(False)
		self.nationColor.set_use_alpha(False)
		self.nationColor.connect("color-set", self.colorCallback)
		self.nationColor.show()
		
		showCoastLbl = gtk.Label("Show coast outlines")
		showCoastLbl.show()
		self.showCoast = gtk.CheckButton("")
		self.showCoast.connect("toggled", self.callback)
		self.showCoast.show()
		
		coastColorLbl = gtk.Label("Color for Coast outlines")
		coastColorLbl.show()
		self.coastColor = gtk.ColorButton(gtk.gdk.color_parse("#002277"))
		self.coastColor.set_sensitive(False)
		self.coastColor.set_use_alpha(False)
		self.coastColor.connect("color-set", self.colorCallback)
		self.coastColor.show()
		
		showStatesLbl = gtk.Label("Show States")
		showStatesLbl.show()
		self.showStates = gtk.CheckButton("(North America only)")
		self.showStates.connect("toggled", self.callback)
		self.showStates.show()
		
		stateColorLbl = gtk.Label("Color for State outlines")
		stateColorLbl.show()
		self.stateColor = gtk.ColorButton(gtk.gdk.color_parse("#005500"))
		self.stateColor.set_sensitive(False)
		self.stateColor.set_use_alpha(False)
		self.stateColor.connect("color-set", self.colorCallback)
		self.stateColor.show()
		
		showCloudsLbl = gtk.Label("Show Cloud Overlay")
		showCloudsLbl.show()
		self.showClouds = gtk.CheckButton("(updated every 3 hours)")
		self.showClouds.connect("toggled", self.callback)
		self.showClouds.show()
		
		self.configDict[self.index + "projection"] = "%s" % (self.projection.get_active_text())
		self.configDict[self.index + "radius"] = "%s" % (self.radius.get_text())
		self.configDict[self.index + "latitude"] = "%s" % (self.latitude.get_text())
		self.configDict[self.index + "longitude"] = "%s" % (self.longitude.get_text())
		self.configDict[self.index + "trace"] = "%s" % (self.trace.get_active())
		self.configDict[self.index + "arcs"] = "%s" % (self.arcs.get_active())
		self.configDict[self.index + "titles"] = "%s" % (self.titles.get_active())
		self.configDict[self.index + "titleType"] = "%s" % (self.titleType.get_active_text())
		self.configDict[self.index + "colors"] = "%s" % (self.colors.get_active())
		self.configDict[self.index + "symbolsize"] = "%s" % (self.symbolsize.get_value())
		self.configDict[self.index + "showNations"] = "%s" % (self.showNations.get_active())
		self.configDict[self.index + "showCoast"] = "%s" % (self.showCoast.get_active())
		self.configDict[self.index + "showStates"] = "%s" % (self.showStates.get_active())
		self.configDict[self.index + "nationColor"] = "0x777777"
		self.configDict[self.index + "coastColor"] = "0x002277"
		self.configDict[self.index + "stateColor"] = "0x004400"
		self.configDict[self.index + "showClouds"] = "%s" % (self.showClouds.get_active())
				
		tbl.attach(templateLbl, 0,1,0,1)
		tbl.attach(self.template, 1,2,0,1)
		tbl.attach(resolutionLbl, 0,1,1,2)
		tbl.attach(self.resolution, 1,2,1,2)
		tbl.attach(projectionLbl, 0,1,2,3)
		tbl.attach(self.projection, 1,2,2,3)
		tbl.attach(radiusLbl, 0,1,4,5)
		tbl.attach(self.radius, 1,2,4,5)
		tbl.attach(showCloudsLbl, 0,1,5,6)
		tbl.attach(self.showClouds, 1,2,5,6)
		tbl.attach(arcsLbl, 0,1,6,7)
		tbl.attach(self.arcs, 1,2,6,7)
		tbl.attach(traceLbl, 0,1,7,8)
		tbl.attach(self.trace, 1,2,7,8)
		tbl.attach(titlesLbl, 0,1,8,9)
		tbl.attach(self.titles, 1,2,8,9)
		tbl.attach(titleTypeLbl, 0,1,9,10)
		tbl.attach(self.titleType, 1,2,9,10)
		tbl.attach(colorsLbl, 0,1,10,11)
		tbl.attach(self.colors, 1,2,10,11)
		tbl.attach(symbolsizeLbl, 0,1,11,12)
		tbl.attach(symbolScale, 1,2,11,12)
		tbl.attach(showNationsLbl, 0,1,12,13)
		tbl.attach(self.showNations, 1,2,12,13)
		tbl.attach(nationColorLbl, 0,1,13,14)
		tbl.attach(self.nationColor, 1,2,13,14)
		tbl.attach(showCoastLbl, 0,1,14,15)
		tbl.attach(self.showCoast, 1,2,14,15)
		tbl.attach(coastColorLbl, 0,1,15,16)
		tbl.attach(self.coastColor, 1,2,15,16)
		tbl.attach(showStatesLbl, 0,1,16,17)
		tbl.attach(self.showStates, 1,2,16,17)
		tbl.attach(stateColorLbl, 0,1,17,18)
		tbl.attach(self.stateColor, 1,2,17,18)
		tbl.attach(latitudeLbl, 0,1,18,19)
		tbl.attach(self.latitude, 1,2,18,19)
		tbl.attach(longitudeLbl, 0,1,19,20)
		tbl.attach(self.longitude, 1,2,19,20)
		tbl.show()
		
		self.add_with_viewport(tbl)
		self.show()
		
	def setResolution(self, resolution):
		self.configDict[self.index + "geometry"] = resolution
		self.resolution.append_text(resolution + " (autodetected)")
		self.resolution.set_active(19)
		self.resolution.set_sensitive(False)
		
	def callback(self, widget, data=None):
		
		# let's maintain some sanity here...
		self.trace.set_sensitive(self.arcs.get_active())
		self.titleType.set_sensitive(self.titles.get_active())
		self.nationColor.set_sensitive(self.showNations.get_active())
		self.coastColor.set_sensitive(self.showCoast.get_active())
		self.stateColor.set_sensitive(self.showStates.get_active())
		
		# then build out the data structure to hold the config...
		self.configDict[self.index + "geometry"] = "%s" % self.resolution.get_active_text().split(' ')[0]
		self.configDict[self.index + "projection"] = "%s" % (self.projection.get_active_text())
		self.configDict[self.index + "radius"] = "%s" % (self.radius.get_text())
		self.configDict[self.index + "latitude"] = "%s" % (self.latitude.get_text())
		self.configDict[self.index + "longitude"] = "%s" % (self.longitude.get_text())
		self.configDict[self.index + "trace"] = "%s" % (self.trace.get_active())
		self.configDict[self.index + "arcs"] = "%s" % (self.arcs.get_active())
		self.configDict[self.index + "titles"] = "%s" % (self.titles.get_active())
		self.configDict[self.index + "titleType"] = "%s" % (self.titleType.get_active_text())
		self.configDict[self.index + "colors"] = "%s" % (self.colors.get_active())
		self.configDict[self.index + "symbolsize"] = "%s" % (self.symbolsize.get_value())
		self.configDict[self.index + "showNations"] = "%s" % (self.showNations.get_active())
		self.configDict[self.index + "showCoast"] = "%s" % (self.showCoast.get_active())
		self.configDict[self.index + "showStates"] = "%s" % (self.showStates.get_active())
		self.configDict[self.index + "showClouds"] = "%s" % (self.showClouds.get_active())
	
	def colorCallback(self, widget, data=None):
		if widget == self.nationColor:
			color = self.nationColor.get_color().to_string()[1:]
			#print color
			self.configDict[self.index + "nationColor"] = "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
			#print  "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
		elif widget == self.coastColor:
			color = self.coastColor.get_color().to_string()[1:]
			#print color
			self.configDict[self.index + "coastColor"] = "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
			#print  "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
		elif widget == self.stateColor:
			color = self.stateColor.get_color().to_string()[1:]
			#print color
			self.configDict[self.index + "stateColor"] = "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
			#print  "0x%s%s%s" % (color[0:2], color[4:6], color[8:10])
