The file earth.jpg is from
http://visibleearth.nasa.gov/cgi-bin/viewrecord?11612

The file night.jpg is a rescaled version of 
http://visibleearth.nasa.gov/cgi-bin/viewrecord?5826

These images are not copyrighted.  From
http://visibleearth.nasa.gov/help.html:

Unless otherwise noted, all images and animations made available
through Visible Earth are generally not copyrighted. You may use NASA
imagery, video and audio material for educational or informational
purposes, including photo collections, textbooks, public exhibits, and
Internet web pages.  This general permission does not include the NASA
insignia logo (the blue "meatball" insignia).

The file hubble.png was cropped and scaled from
http://spaceflight.nasa.gov/gallery/images/shuttle/sts-103/lores/s103e5031.jpg

The file iss.png was cropped and scaled from 
http://spaceflight.nasa.gov/gallery/images/shuttle/sts-104/lores/s104e5027.jpg

The file shuttle.png was cropped and scaled from
http://spaceflight.nasa.gov/gallery/images/shuttle/sts-105/lores/iss002e9729.jpg

Guidelines regarding use of these images (pretty much the same as for
the Visible Earth images) can be found on http://www.jsc.nasa.gov/policies.html.

The file smile.png is converted from smile.gif, distributed with the
tik Instant Messenger application (http://tik.sourceforge.net).

The files sublunar.png and subsolar.png were contributed by Barthel
aus Pennswald <kknerrsr@ptdprolog.net>. 

The file sun.jpg is a 1024x512 file with uniform RGB values of (255,255,166).
