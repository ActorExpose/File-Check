Put JPL digital ephemeris files (DE200, DE405, or DE406) here to use
for computing planetary positions.  Xplanet uses Bill Gray's code
(http://www.projectpluto.com/jpl_eph.htm), which reads both big and
little endian binary files.  The ephemeris files found at
ftp://ssd.jpl.nasa.gov/pub/eph/export/unix are big endian files, but
you do not need to do any additional byte-swapping to use them.
