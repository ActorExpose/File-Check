The FreeMonoBold font is from http://www.nongnu.org/freefont and is
released under the GPL.
