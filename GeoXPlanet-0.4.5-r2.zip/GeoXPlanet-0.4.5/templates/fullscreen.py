#!/usr/bin/env python

class fullscreen(BaseTemplate):
	