#!/usr/bin/env python

import os

class BaseTemplate:
	def __init__(self):
		xplanet = os.popen("which xplanet")